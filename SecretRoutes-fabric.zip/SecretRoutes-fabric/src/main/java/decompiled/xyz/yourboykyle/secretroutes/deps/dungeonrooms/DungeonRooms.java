/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.util.ResourceLocation
 *  net.minecraftforge.common.MinecraftForge
 *  net.minecraftforge.fml.common.Mod$EventHandler
 *  net.minecraftforge.fml.common.event.FMLInitializationEvent
 *  net.minecraftforge.fml.common.event.FMLPreInitializationEvent
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 *  net.minecraftforge.fml.common.gameevent.TickEvent$ClientTickEvent
 *  net.minecraftforge.fml.common.gameevent.TickEvent$Phase
 *  org.apache.logging.log4j.Level
 *  org.apache.logging.log4j.LogManager
 */
package xyz.yourboykyle.secretroutes.deps.dungeonrooms;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.dungeons.catacombs.DungeonManager;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.dungeons.catacombs.RoomDetection;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.dungeons.catacombs.Waypoints;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.utils.Utils;

public class DungeonRooms {
    Minecraft mc = Minecraft.func_71410_x();
    public static JsonObject roomsJson;
    public static JsonObject waypointsJson;
    public static HashMap<String, HashMap<String, long[]>> ROOM_DATA;
    static int tickAmount;

    public void preInit(FMLPreInitializationEvent event) {
        Utils.setLogLevel(LogManager.getLogger(DungeonRooms.class), Level.INFO);
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        long time1 = System.currentTimeMillis();
        List<Path> paths = Utils.getAllPaths("catacombs");
        ExecutorService executor = Executors.newFixedThreadPool(4);
        Future<HashMap> future1x1 = executor.submit(() -> Utils.pathsToRoomData("1x1", paths));
        Future<HashMap> future1x2 = executor.submit(() -> Utils.pathsToRoomData("1x2", paths));
        Future<HashMap> future1x3 = executor.submit(() -> Utils.pathsToRoomData("1x3", paths));
        Future<HashMap> future1x4 = executor.submit(() -> Utils.pathsToRoomData("1x4", paths));
        Future<HashMap> future2x2 = executor.submit(() -> Utils.pathsToRoomData("2x2", paths));
        Future<HashMap> futureLShape = executor.submit(() -> Utils.pathsToRoomData("L-shape", paths));
        Future<HashMap> futurePuzzle = executor.submit(() -> Utils.pathsToRoomData("Puzzle", paths));
        Future<HashMap> futureTrap = executor.submit(() -> Utils.pathsToRoomData("Trap", paths));
        MinecraftForge.EVENT_BUS.register((Object)this);
        MinecraftForge.EVENT_BUS.register((Object)new DungeonManager());
        MinecraftForge.EVENT_BUS.register((Object)new RoomDetection());
        MinecraftForge.EVENT_BUS.register((Object)new Waypoints());
        try (BufferedReader roomsReader = new BufferedReader(new InputStreamReader(this.mc.func_110442_L().func_110536_a(new ResourceLocation("roomdetection", "dungeonrooms.json")).func_110527_b()));
             BufferedReader waypointsReader = new BufferedReader(new InputStreamReader(this.mc.func_110442_L().func_110536_a(new ResourceLocation("roomdetection", "secretlocations.json")).func_110527_b()));){
            Gson gson = new Gson();
            roomsJson = gson.fromJson((Reader)roomsReader, JsonObject.class);
            waypointsJson = gson.fromJson((Reader)waypointsReader, JsonObject.class);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        try {
            long time2 = System.currentTimeMillis();
            ROOM_DATA.put("1x1", future1x1.get());
            long time3 = System.currentTimeMillis();
            ROOM_DATA.put("1x2", future1x2.get());
            ROOM_DATA.put("1x3", future1x3.get());
            ROOM_DATA.put("1x4", future1x4.get());
            ROOM_DATA.put("2x2", future2x2.get());
            ROOM_DATA.put("L-shape", futureLShape.get());
            ROOM_DATA.put("Puzzle", futurePuzzle.get());
            ROOM_DATA.put("Trap", futureTrap.get());
            long l = System.currentTimeMillis();
        }
        catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        executor.shutdown();
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.START) {
            return;
        }
        EntityPlayerSP player = this.mc.field_71439_g;
        if (++tickAmount % 20 == 0 && player != null) {
            Utils.checkForSkyblock();
            Utils.checkForCatacombs();
            tickAmount = 0;
        }
    }

    static {
        ROOM_DATA = new HashMap();
        tickAmount = 1;
    }
}

