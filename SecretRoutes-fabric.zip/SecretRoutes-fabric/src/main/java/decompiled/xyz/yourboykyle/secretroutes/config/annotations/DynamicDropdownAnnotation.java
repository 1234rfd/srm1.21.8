/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  cc.polyfrost.oneconfig.config.annotations.CustomOption
 */
package xyz.yourboykyle.secretroutes.config.annotations;

import cc.polyfrost.oneconfig.config.annotations.CustomOption;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(value=RetentionPolicy.RUNTIME)
@Target(value={ElementType.FIELD})
@CustomOption(id="myOption")
public @interface DynamicDropdownAnnotation {
    public String name();

    public String[] options() default {};
}

