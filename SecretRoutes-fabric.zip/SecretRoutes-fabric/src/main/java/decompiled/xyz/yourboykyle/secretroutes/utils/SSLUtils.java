/*
 * Decompiled with CFR 0.152.
 */
package xyz.yourboykyle.secretroutes.utils;

import java.security.KeyStore;
import java.security.KeyStoreException;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;
import xyz.yourboykyle.secretroutes.deps.libautoupdate.UpdateUtils;
import xyz.yourboykyle.secretroutes.utils.ChatUtils;
import xyz.yourboykyle.secretroutes.utils.LogUtils;

public class SSLUtils {
    static SSLContext context = null;

    public static void makeSSLCertificate() {
        block6: {
            try {
                if (context != null) break block6;
                KeyStore keyStore = null;
                try {
                    keyStore = KeyStore.getInstance("JKS");
                }
                catch (KeyStoreException e) {
                    LogUtils.error(e);
                }
                if (keyStore != null) {
                    keyStore.load(SSLUtils.class.getResourceAsStream("/srmkeystore.jks"), "changeit".toCharArray());
                } else {
                    ChatUtils.sendChatMessage("[\u00a73SRM\u00a7f] \u00a7cSomething went wrong wth ssl. Send the log file in the \u00a71#support\u00a7c channel in the discord with a screenshot of this message.");
                }
                KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
                TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
                kmf.init(keyStore, null);
                tmf.init(keyStore);
                SSLContext ctx = SSLContext.getInstance("TLS");
                ctx.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);
                context = ctx;
            }
            catch (Exception e) {
                LogUtils.error(e);
            }
        }
    }

    public static void setSSlCertificate() {
        try {
            SSLUtils.makeSSLCertificate();
            UpdateUtils.patchConnection(connection -> {
                if (connection instanceof HttpsURLConnection) {
                    ((HttpsURLConnection)connection).setSSLSocketFactory(context.getSocketFactory());
                }
            });
        }
        catch (Exception e) {
            ChatUtils.sendChatMessage("[\u00a73SRM\u00a7f] \u00a7cSomething went wrong wth ssl. Send the log file in the \u00a71#support\u00a7f channel in the discord with a screenshot of this message.");
            LogUtils.error(e);
        }
    }

    public static SSLSocketFactory getSSLSocketFactory() {
        if (context == null) {
            SSLUtils.makeSSLCertificate();
        }
        return context.getSocketFactory();
    }
}

