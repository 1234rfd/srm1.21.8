SecretRoutes - Fabric project (generated from your decompiled sources)

What I included:
- Decompiled .java files copied into src/main/java (preserves packages)
- A Fabric client entrypoint: xyz.yourboykyle.secretroutes.MainFabric
- fabric.mod.json and mixin config
- Basic build.gradle, settings.gradle, gradle.properties

Important next steps:
1. Install Gradle and set up Fabric Loom as per Fabric docs.
2. Update build.gradle versions for fabric-loom, mappings, and fabric-api to match current releases if necessary.
3. Fix imports/method calls that changed between MC 1.8.9 and 1.21.8 (Yarn mappings). Expect many compile errors initially.
4. I recommend running the 'genIntelliJRuns' (or equivalent) Gradle tasks from fabric-loom to run a dev client.
5. I can continue converting specific classes (ConfigUtils, HUD classes, mixins) on request.

If you want, tell me which classes to prioritize and I will port them to Fabric-compatible implementations next.
