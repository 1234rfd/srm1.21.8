/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.client.event.RenderGameOverlayEvent$Text
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package xyz.yourboykyle.secretroutes.events;

import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import xyz.yourboykyle.secretroutes.config.SRMConfig;
import xyz.yourboykyle.secretroutes.utils.GuiUitls;
import xyz.yourboykyle.secretroutes.utils.SecretRoutesRenderUtils;
import xyz.yourboykyle.secretroutes.utils.SecretUtils;

public class OnGuiRender {
    public static Long spawnNotifTime = null;

    @SubscribeEvent
    public void onGuiRender(RenderGameOverlayEvent.Text event) {
        if (SecretUtils.removeBannerTime != null && System.currentTimeMillis() < SecretUtils.removeBannerTime) {
            GuiUitls.displayText("\u00a7bSet waypoint at lever", 0.0f, -100.0f, 2.0f);
        }
        if (spawnNotifTime != null || SRMConfig.renderBlood.booleanValue()) {
            if (SRMConfig.renderBlood.booleanValue() || System.currentTimeMillis() < spawnNotifTime) {
                GuiUitls.displayText(SecretRoutesRenderUtils.getTextColor(SRMConfig.bloodReadyColor) + SRMConfig.bloodReadyText, SRMConfig.bloodX, SRMConfig.bloodY, SRMConfig.bloodScale);
            } else {
                spawnNotifTime = null;
            }
        }
    }
}

