/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.BlockPos
 */
package xyz.yourboykyle.secretroutes.utils;

import net.minecraft.util.BlockPos;
import xyz.yourboykyle.secretroutes.utils.ChatUtils;

public class BlockUtils {
    public static String blockPos(BlockPos pos) {
        if (pos == null) {
            return ":::";
        }
        return pos.func_177958_n() + ":" + pos.func_177956_o() + ":" + pos.func_177952_p();
    }

    public static BlockPos blockPos(String pos) {
        try {
            String[] parts = pos.split(":");
            return new BlockPos(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]), Integer.parseInt(parts[2]));
        }
        catch (NumberFormatException e) {
            ChatUtils.sendChatMessage("NMumber format exception, null.");
            return null;
        }
    }

    public static boolean compareBlocks(BlockPos pos1, BlockPos pos2, int dist) {
        return pos1.func_177958_n() >= pos2.func_177958_n() - dist && pos1.func_177958_n() <= pos2.func_177958_n() + dist && pos1.func_177956_o() >= pos2.func_177956_o() - dist && pos1.func_177956_o() <= pos2.func_177956_o() + dist && pos1.func_177952_p() >= pos2.func_177952_p() - dist && pos1.func_177952_p() <= pos2.func_177952_p() + dist;
    }

    public static double blockDistance(BlockPos pos1, BlockPos pos2) {
        if (pos1 == null || pos2 == null) {
            return 2.147483647E9;
        }
        float xdiff = Math.abs(pos1.func_177958_n() - pos2.func_177958_n());
        float ydiff = Math.abs(pos1.func_177956_o() - pos2.func_177956_o());
        float zdiff = Math.abs(pos1.func_177952_p() - pos2.func_177952_p());
        return Math.pow(Math.pow(xdiff, 2.0) + Math.pow(ydiff, 2.0) + Math.pow(zdiff, 2.0), 0.5);
    }

    public static double blockDistance(BlockPos pos1, String pos2) {
        BlockPos pos2Block = BlockUtils.blockPos(pos2);
        if (pos2Block == null) {
            return 2.147483647E9;
        }
        return BlockUtils.blockDistance(pos1, pos2Block);
    }
}

