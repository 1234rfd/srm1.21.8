/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  cc.polyfrost.oneconfig.config.core.OneColor
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.gui.FontRenderer
 *  net.minecraft.client.multiplayer.WorldClient
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.Tessellator
 *  net.minecraft.client.renderer.WorldRenderer
 *  net.minecraft.client.renderer.entity.RenderManager
 *  net.minecraft.client.renderer.vertex.DefaultVertexFormats
 *  net.minecraft.entity.Entity
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumParticleTypes
 *  net.minecraft.util.ResourceLocation
 *  org.lwjgl.opengl.GL11
 */
package xyz.yourboykyle.secretroutes.utils;

import cc.polyfrost.oneconfig.config.core.OneColor;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;
import xyz.yourboykyle.secretroutes.utils.Constants;
import xyz.yourboykyle.secretroutes.utils.multistorage.Triple;

public class RenderUtils {
    private static final ResourceLocation beaconBeam = new ResourceLocation("textures/entity/beacon_beam.png");

    public static void drawBoxAtBlock(double x, double y, double z, OneColor color, double width, double height, double alpha) {
        GL11.glPushMatrix();
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)3042);
        GL11.glLineWidth((float)3.0f);
        GlStateManager.func_179090_x();
        GlStateManager.func_179097_i();
        GlStateManager.func_179132_a((boolean)false);
        GL11.glTranslated((double)x, (double)y, (double)z);
        GL11.glColor4f((float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)((float)alpha));
        GL11.glBegin((int)3);
        GL11.glVertex3d((double)width, (double)height, (double)width);
        GL11.glVertex3d((double)width, (double)height, (double)0.0);
        GL11.glVertex3d((double)0.0, (double)height, (double)0.0);
        GL11.glVertex3d((double)0.0, (double)height, (double)width);
        GL11.glVertex3d((double)width, (double)height, (double)width);
        GL11.glVertex3d((double)width, (double)0.0, (double)width);
        GL11.glVertex3d((double)width, (double)0.0, (double)0.0);
        GL11.glVertex3d((double)0.0, (double)0.0, (double)0.0);
        GL11.glVertex3d((double)0.0, (double)0.0, (double)width);
        GL11.glVertex3d((double)0.0, (double)0.0, (double)0.0);
        GL11.glVertex3d((double)0.0, (double)height, (double)0.0);
        GL11.glVertex3d((double)0.0, (double)0.0, (double)0.0);
        GL11.glVertex3d((double)width, (double)0.0, (double)0.0);
        GL11.glVertex3d((double)width, (double)height, (double)0.0);
        GL11.glVertex3d((double)width, (double)0.0, (double)0.0);
        GL11.glVertex3d((double)width, (double)0.0, (double)width);
        GL11.glVertex3d((double)0.0, (double)0.0, (double)width);
        GL11.glVertex3d((double)0.0, (double)height, (double)width);
        GL11.glVertex3d((double)width, (double)height, (double)width);
        GL11.glEnd();
        GlStateManager.func_179132_a((boolean)true);
        GlStateManager.func_179126_j();
        GlStateManager.func_179098_w();
        GL11.glDisable((int)3042);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)0.0f);
        GL11.glPopMatrix();
    }

    public static void spawnParticleAtLocation(BlockPos loc, BlockPos offset, EnumParticleTypes particle) {
        WorldClient world = Minecraft.func_71410_x().field_71441_e;
        if (world != null) {
            double x = (double)loc.func_177958_n() + 0.5;
            double y = (double)loc.func_177956_o() + 0.5;
            double z = (double)loc.func_177952_p() + 0.5;
            double offsetX = offset.func_177958_n();
            double offsetY = offset.func_177956_o();
            double offsetZ = offset.func_177952_p();
            world.func_175688_a(particle, x, y, z, offsetX, offsetY, offsetZ, new int[0]);
        }
    }

    public static void drawLineParticles(BlockPos loc1, BlockPos loc2, EnumParticleTypes particle) {
        double distanceX = loc2.func_177958_n() - loc1.func_177958_n();
        double distanceY = loc2.func_177956_o() - loc1.func_177956_o();
        double distanceZ = loc2.func_177952_p() - loc1.func_177952_p();
        double maxDistance = Math.max(Math.abs(distanceX), Math.abs(distanceZ));
        int maxPoints = (int)Math.ceil(maxDistance * 1.0);
        double deltaX = distanceX / (double)maxPoints;
        double deltaY = distanceY / (double)maxPoints;
        double deltaZ = distanceZ / (double)maxPoints;
        double x = loc1.func_177958_n();
        double y = loc1.func_177956_o();
        double z = loc1.func_177952_p();
        for (int i = 0; i <= maxPoints; ++i) {
            RenderUtils.spawnParticleAtLocation(new BlockPos(x, y, z), new BlockPos(0, 0, 0), particle);
            x += deltaX;
            y += deltaY;
            z += deltaZ;
        }
    }

    public static void drawLineMultipleParticles(EnumParticleTypes particle, List<BlockPos> locations) {
        if (locations == null) {
            return;
        }
        if (locations.size() >= 2) {
            BlockPos lastLoc = null;
            for (BlockPos loc : locations) {
                if (lastLoc == null) {
                    lastLoc = loc;
                    continue;
                }
                RenderUtils.drawLineParticles(lastLoc, loc, particle);
                lastLoc = loc;
            }
        }
    }

    public static void drawMultipleNormalLines(List<Triple<Double, Double, Double>> locations, float partialTicks, OneColor color, int width) {
        if (locations == null) {
            return;
        }
        if (locations.size() >= 2) {
            Triple<Double, Double, Double> lastLoc = null;
            for (Triple<Double, Double, Double> loc : locations) {
                if (lastLoc == null) {
                    lastLoc = loc;
                    continue;
                }
                RenderUtils.drawNormalLine((Double)lastLoc.getOne(), (Double)lastLoc.getTwo(), lastLoc.getThree(), (Double)loc.getOne(), (Double)loc.getTwo(), loc.getThree(), color, partialTicks, true, width);
                lastLoc = loc;
            }
        }
    }

    public static void drawNormalLine(double x1, double y1, double z1, BlockPos pos, OneColor color, float partialTicks, boolean depth, int width) {
        RenderUtils.drawNormalLine(x1, y1, z1, pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p(), color, partialTicks, depth, width);
    }

    public static void drawNormalLine(double x1, double y1, double z1, double x2, double y2, double z2, OneColor colour, float partialTicks, boolean depth, int width) {
        Entity render = Minecraft.func_71410_x().func_175606_aa();
        WorldRenderer worldRenderer = Tessellator.func_178181_a().func_178180_c();
        double realX = render.field_70142_S + (render.field_70165_t - render.field_70142_S) * (double)partialTicks;
        double realY = render.field_70137_T + (render.field_70163_u - render.field_70137_T) * (double)partialTicks;
        double realZ = render.field_70136_U + (render.field_70161_v - render.field_70136_U) * (double)partialTicks;
        GlStateManager.func_179094_E();
        GlStateManager.func_179137_b((double)(-realX), (double)(-realY), (double)(-realZ));
        GlStateManager.func_179090_x();
        if (!depth) {
            GlStateManager.func_179097_i();
            GlStateManager.func_179132_a((boolean)false);
        }
        GlStateManager.func_179140_f();
        GlStateManager.func_179147_l();
        GlStateManager.func_179118_c();
        GlStateManager.func_179120_a((int)770, (int)771, (int)1, (int)0);
        GL11.glLineWidth((float)width);
        GlStateManager.func_179131_c((float)((float)colour.getRed() / 255.0f), (float)((float)colour.getGreen() / 255.0f), (float)((float)colour.getBlue() / 255.0f), (float)((float)colour.getAlpha() / 255.0f));
        worldRenderer.func_181668_a(1, DefaultVertexFormats.field_181705_e);
        worldRenderer.func_181662_b(x1, y1, z1).func_181675_d();
        worldRenderer.func_181662_b(x2, y2, z2).func_181675_d();
        Tessellator.func_178181_a().func_78381_a();
        GlStateManager.func_179137_b((double)realX, (double)realY, (double)realZ);
        GlStateManager.func_179084_k();
        if (!depth) {
            GlStateManager.func_179126_j();
            GlStateManager.func_179132_a((boolean)true);
        }
        GlStateManager.func_179141_d();
        GlStateManager.func_179098_w();
        GlStateManager.func_179145_e();
        GlStateManager.func_179131_c((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GlStateManager.func_179121_F();
    }

    public static void drawNormalLine(BlockPos pos1, BlockPos pos2, OneColor color, float partialTicks, boolean depth, int width) {
        RenderUtils.drawNormalLine(pos1.func_177958_n(), pos1.func_177956_o(), pos1.func_177952_p(), pos2.func_177958_n(), pos2.func_177956_o(), pos2.func_177952_p(), color, partialTicks, depth, width);
    }

    public static void drawText(String text, BlockPos pos, float partialTicks, Boolean depth, Boolean shadow, Float scale) {
        Minecraft mc = Minecraft.func_71410_x();
        RenderManager rm = mc.func_175598_ae();
        FontRenderer fr = mc.field_71466_p;
        EntityPlayerSP player = mc.field_71439_g;
        double viewerPosX = player.field_70142_S + (player.field_70165_t - player.field_70142_S) * (double)partialTicks;
        double viewerPosY = player.field_70137_T + (player.field_70163_u - player.field_70137_T) * (double)partialTicks;
        double viewerPosZ = player.field_70136_U + (player.field_70161_v - player.field_70136_U) * (double)partialTicks;
        double posX = (double)pos.func_177958_n() - viewerPosX + 0.5;
        double posY = (double)pos.func_177956_o() - viewerPosY - (double)player.func_70047_e();
        double posZ = (double)pos.func_177952_p() - viewerPosZ + 0.5;
        double distance = Math.sqrt(posX * posX + posY * posY + posZ * posZ);
        GlStateManager.func_179094_E();
        GlStateManager.func_179137_b((double)posX, (double)posY, (double)posZ);
        GlStateManager.func_179109_b((float)0.0f, (float)player.func_70047_e(), (float)0.0f);
        GlStateManager.func_179114_b((float)(-rm.field_78735_i), (float)0.0f, (float)1.0f, (float)0.0f);
        GlStateManager.func_179114_b((float)rm.field_78732_j, (float)1.0f, (float)0.0f, (float)0.0f);
        GlStateManager.func_179152_a((float)(-Constants.baseScale * scale.floatValue()), (float)(-Constants.baseScale * scale.floatValue()), (float)(-Constants.baseScale * scale.floatValue()));
        float constantScaleFactor = (float)(distance * (double)Constants.distanceScaleFactor);
        GlStateManager.func_179152_a((float)(1.0f + constantScaleFactor), (float)(1.0f + constantScaleFactor), (float)(1.0f + constantScaleFactor));
        GlStateManager.func_179140_f();
        if (!depth.booleanValue()) {
            GlStateManager.func_179132_a((boolean)false);
            GlStateManager.func_179097_i();
        }
        GlStateManager.func_179147_l();
        GlStateManager.func_179112_b((int)770, (int)771);
        float width = (float)fr.func_78256_a(text) / 2.0f;
        fr.func_175065_a(text, -width, 0.0f, 0xFFFFFF, shadow.booleanValue());
        if (!depth.booleanValue()) {
            GlStateManager.func_179126_j();
            GlStateManager.func_179132_a((boolean)true);
        }
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
        GlStateManager.func_179121_F();
    }

    public static void drawFromPlayer(EntityPlayerSP p, BlockPos pos, OneColor color, float partialticks, int width) {
        double px = p.field_70169_q + (p.field_70165_t - p.field_70169_q) * (double)partialticks;
        double py = p.field_70167_r + (p.field_70163_u - p.field_70167_r) * (double)partialticks;
        double pz = p.field_70166_s + (p.field_70161_v - p.field_70166_s) * (double)partialticks;
        RenderUtils.drawNormalLine(px, py + (double)p.func_70047_e(), pz, (double)pos.func_177958_n() + 0.5, pos.func_177956_o(), (double)pos.func_177952_p() + 0.5, color, partialticks, false, width);
    }

    public static void drawFromPlayer(EntityPlayerSP p, double x, double y, double z, OneColor color, float partialticks, int width) {
        double px = p.field_70169_q + (p.field_70165_t - p.field_70169_q) * (double)partialticks;
        double py = p.field_70167_r + (p.field_70163_u - p.field_70167_r) * (double)partialticks;
        double pz = p.field_70166_s + (p.field_70161_v - p.field_70166_s) * (double)partialticks;
        RenderUtils.drawNormalLine(px, py + (double)p.func_70047_e(), pz, x + 0.5, y, z + 0.5, color, partialticks, false, width);
    }
}

