/*
 * Decompiled with CFR 0.152.
 */
package xyz.yourboykyle.secretroutes.deps.libautoupdate;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public interface CurrentVersion {
    public static CurrentVersion of(final int number) {
        return new CurrentVersion(){

            @Override
            public String display() {
                return String.valueOf(number);
            }

            @Override
            public boolean isOlderThan(JsonElement element) {
                if (!element.isJsonPrimitive()) {
                    return true;
                }
                JsonPrimitive prim = element.getAsJsonPrimitive();
                if (!prim.isNumber()) {
                    return true;
                }
                return prim.getAsInt() > number;
            }

            public String toString() {
                return "VersionNumber (" + number + ")";
            }
        };
    }

    public static CurrentVersion ofTag(final String tagName) {
        return new CurrentVersion(){

            @Override
            public String display() {
                return tagName;
            }

            @Override
            public boolean isOlderThan(JsonElement element) {
                return !element.isJsonPrimitive() || !element.getAsString().equalsIgnoreCase(tagName);
            }

            public String toString() {
                return "VersionTag (" + tagName + ")";
            }
        };
    }

    public String display();

    public boolean isOlderThan(JsonElement var1);
}

