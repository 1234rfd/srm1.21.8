/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.util.Vec3
 *  net.minecraftforge.client.event.ClientChatReceivedEvent
 *  net.minecraftforge.event.world.WorldEvent$Unload
 *  net.minecraftforge.fml.common.eventhandler.EventPriority
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 *  net.minecraftforge.fml.common.gameevent.TickEvent$ClientTickEvent
 *  net.minecraftforge.fml.common.gameevent.TickEvent$Phase
 */
package xyz.yourboykyle.secretroutes.deps.dungeonrooms.dungeons.catacombs;

import java.awt.Point;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.util.Vec3;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.dungeons.catacombs.RoomDetection;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.dungeons.catacombs.Waypoints;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.utils.MapUtils;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.utils.Utils;

public class DungeonManager {
    Minecraft mc = Minecraft.func_71410_x();
    public static int gameStage = 0;
    public static Integer[][] map;
    public static Point[] entranceMapCorners;
    public static Point entrancePhysicalNWCorner;
    public static Integer mapId;
    long bloodTime = Long.MAX_VALUE;

    @SubscribeEvent(priority=EventPriority.HIGHEST, receiveCanceled=true)
    public void onChat(ClientChatReceivedEvent event) {
        if (!Utils.inCatacombs) {
            return;
        }
        String message = event.message.func_150254_d();
        if (message.startsWith("\u00a7e[NPC] \u00a7bMort\u00a7f: \u00a7rHere, I found this map when I first entered the dungeon.\u00a7r")) {
            gameStage = 2;
        } else if (message.startsWith("\u00a7r\u00a7c[BOSS] The Watcher\u00a7r\u00a7f: You have proven yourself. You may pass.\u00a7r")) {
            this.bloodTime = System.currentTimeMillis() + 5000L;
        } else if (System.currentTimeMillis() > this.bloodTime && (message.startsWith("\u00a7r\u00a7c[BOSS] ") && !message.contains(" The Watcher\u00a7r\u00a7f:") || message.startsWith("\u00a7r\u00a74[BOSS] "))) {
            if (gameStage != 3) {
                gameStage = 3;
                RoomDetection.resetCurrentRoom();
                RoomDetection.roomName = "Boss Room";
                RoomDetection.roomCategory = "General";
            }
        } else if (message.contains("\u00a7r\u00a7c\u2620 \u00a7r\u00a7eDefeated \u00a7r")) {
            gameStage = 4;
            RoomDetection.resetCurrentRoom();
        }
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.START) {
            return;
        }
        EntityPlayerSP player = this.mc.field_71439_g;
        if (!Utils.inCatacombs) {
            return;
        }
        if (gameStage == 0 || gameStage == 1) {
            if (gameStage == 0) {
                Utils.checkForConflictingHotkeys();
                gameStage = 1;
            }
            if (MapUtils.mapExists()) {
                gameStage = 2;
                return;
            }
            if (gameStage == 1 && entrancePhysicalNWCorner == null && !player.func_174791_d().equals(new Vec3(0.0, 0.0, 0.0))) {
                entrancePhysicalNWCorner = MapUtils.getClosestNWPhysicalCorner(player.func_174791_d());
            }
        }
    }

    @SubscribeEvent
    public void onWorldUnload(WorldEvent.Unload event) {
        Utils.inCatacombs = false;
        gameStage = 0;
        mapId = null;
        map = null;
        entranceMapCorners = null;
        entrancePhysicalNWCorner = null;
        RoomDetection.entranceMapNullCount = 0;
        this.bloodTime = Long.MAX_VALUE;
        if (RoomDetection.stage2Executor != null) {
            RoomDetection.stage2Executor.shutdown();
        }
        Waypoints.allSecretsMap.clear();
        RoomDetection.resetCurrentRoom();
    }
}

