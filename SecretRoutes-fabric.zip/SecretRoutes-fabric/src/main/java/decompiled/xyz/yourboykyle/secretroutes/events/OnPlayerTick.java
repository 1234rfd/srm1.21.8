/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.util.BlockPos
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 *  net.minecraftforge.fml.common.gameevent.TickEvent$PlayerTickEvent
 */
package xyz.yourboykyle.secretroutes.events;

import net.minecraft.client.Minecraft;
import net.minecraft.util.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import xyz.yourboykyle.secretroutes.Main;
import xyz.yourboykyle.secretroutes.config.SRMConfig;
import xyz.yourboykyle.secretroutes.utils.LogUtils;
import xyz.yourboykyle.secretroutes.utils.Room;

public class OnPlayerTick {
    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent e) {
        BlockPos pos;
        if (e.player.func_110124_au() != Minecraft.func_71410_x().field_71439_g.func_110124_au()) {
            return;
        }
        if (SRMConfig.modEnabled) {
            Main.currentRoom.renderLines();
        }
        if (Main.currentRoom.getSecretType() == Room.SECRET_TYPES.BAT) {
            pos = e.player.func_180425_c();
            BlockPos batPos = Main.currentRoom.getSecretLocation();
            if (pos.func_177958_n() >= batPos.func_177958_n() - 3 && pos.func_177958_n() <= batPos.func_177958_n() + 3 && pos.func_177956_o() >= batPos.func_177956_o() - 3 && pos.func_177956_o() <= batPos.func_177956_o() + 3 && pos.func_177952_p() >= batPos.func_177952_p() - 3 && pos.func_177952_p() <= batPos.func_177952_p() + 3) {
                Main.currentRoom.nextSecret();
                LogUtils.info("Went by bat at " + batPos);
            }
        }
        if (Main.currentRoom.getSecretType() == Room.SECRET_TYPES.ITEM) {
            pos = e.player.func_180425_c();
            BlockPos itemPos = Main.currentRoom.getSecretLocation();
            if (pos.func_177958_n() >= itemPos.func_177958_n() - 2 && pos.func_177958_n() <= itemPos.func_177958_n() + 2 && pos.func_177956_o() >= itemPos.func_177956_o() - 2 && pos.func_177956_o() <= itemPos.func_177956_o() + 2 && pos.func_177952_p() >= itemPos.func_177952_p() - 2 && pos.func_177952_p() <= itemPos.func_177952_p() + 2) {
                new Thread(() -> {
                    try {
                        Thread.sleep(1500L);
                        if (Main.currentRoom.getSecretType() == Room.SECRET_TYPES.ITEM && itemPos.func_177958_n() == Main.currentRoom.getSecretLocation().func_177958_n() && itemPos.func_177956_o() == Main.currentRoom.getSecretLocation().func_177956_o() && itemPos.func_177952_p() == Main.currentRoom.getSecretLocation().func_177952_p()) {
                            Main.currentRoom.nextSecret();
                            LogUtils.info("Picked up item at " + itemPos + " (Auto)");
                        }
                    }
                    catch (InterruptedException e1) {
                        LogUtils.error(e1);
                    }
                }).start();
            }
        }
        if (Main.routeRecording.recording) {
            if (Main.routeRecording.previousLocation == null) {
                Main.routeRecording.addWaypoint(Room.WAYPOINT_TYPES.LOCATIONS, e.player.func_180425_c());
                Main.routeRecording.previousLocation = e.player.func_180425_c();
            } else {
                pos = e.player.func_180425_c();
                BlockPos prevPos = Main.routeRecording.previousLocation;
                double distance = Math.abs(Math.sqrt(Math.pow(pos.func_177958_n() - prevPos.func_177958_n(), 2.0) + Math.pow(pos.func_177956_o() - prevPos.func_177956_o(), 2.0) + Math.pow(pos.func_177952_p() - prevPos.func_177952_p(), 2.0)));
                if (distance >= 2.4) {
                    Main.routeRecording.addWaypoint(Room.WAYPOINT_TYPES.LOCATIONS, e.player.func_180425_c());
                    Main.routeRecording.previousLocation = e.player.func_180425_c();
                }
            }
        }
    }
}

