/*
 * Decompiled with CFR 0.152.
 */
package xyz.yourboykyle.secretroutes.utils;

public class Constants {
    public static float distanceScaleFactor = 0.08f;
    public static float baseScale = 0.012f;
    public static boolean shadows = false;
    public static int zPos = 1000;
}

