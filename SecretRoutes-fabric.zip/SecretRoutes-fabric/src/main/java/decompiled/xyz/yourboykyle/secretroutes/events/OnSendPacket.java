/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.network.play.client.C08PacketPlayerBlockPlacement
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.world.World
 *  net.minecraftforge.event.entity.player.PlayerInteractEvent
 *  net.minecraftforge.event.entity.player.PlayerInteractEvent$Action
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package xyz.yourboykyle.secretroutes.events;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.World;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.events.PacketEvent;
import xyz.yourboykyle.secretroutes.events.OnPlayerInteract;

public class OnSendPacket {
    @SubscribeEvent
    public void onSendPacket(PacketEvent.SendEvent e) {
        try {
            if (e.packet instanceof C08PacketPlayerBlockPlacement) {
                Minecraft mc = Minecraft.func_71410_x();
                OnPlayerInteract.onPlayerInteract(new PlayerInteractEvent((EntityPlayer)mc.field_71439_g, PlayerInteractEvent.Action.RIGHT_CLICK_BLOCK, ((C08PacketPlayerBlockPlacement)e.packet).func_179724_a(), EnumFacing.UP, (World)mc.field_71441_e));
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}

