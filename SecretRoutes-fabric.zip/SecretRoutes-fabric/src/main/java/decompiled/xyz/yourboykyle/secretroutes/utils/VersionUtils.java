/*
 * Decompiled with CFR 0.152.
 */
package xyz.yourboykyle.secretroutes.utils;

public class VersionUtils {
    public static Boolean isLower(String version) {
        String[] current = "0.4.16".split("\\.");
        String[] check = version.split("\\.");
        if (check.length != 3) {
            return null;
        }
        for (int i = 0; i < current.length && i < check.length; ++i) {
            if (Integer.parseInt(current[i]) < Integer.parseInt(check[i])) {
                return false;
            }
            if (Integer.parseInt(current[i]) <= Integer.parseInt(check[i])) continue;
            return true;
        }
        return true;
    }
}

