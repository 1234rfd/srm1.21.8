/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.netty.channel.ChannelHandler
 *  net.minecraft.client.Minecraft
 *  net.minecraft.command.ICommand
 *  net.minecraft.util.EnumChatFormatting
 *  net.minecraftforge.client.ClientCommandHandler
 *  net.minecraftforge.common.MinecraftForge
 *  net.minecraftforge.fml.common.Mod
 *  net.minecraftforge.fml.common.Mod$EventHandler
 *  net.minecraftforge.fml.common.event.FMLInitializationEvent
 *  net.minecraftforge.fml.common.event.FMLPreInitializationEvent
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 *  net.minecraftforge.fml.common.network.FMLNetworkEvent$ClientConnectedToServerEvent
 */
package xyz.yourboykyle.secretroutes;

import io.netty.channel.ChannelHandler;
import java.awt.Point;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import net.minecraft.client.Minecraft;
import net.minecraft.command.ICommand;
import net.minecraft.util.EnumChatFormatting;
import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.network.FMLNetworkEvent;
import xyz.yourboykyle.secretroutes.commands.ChangeColorProfile;
import xyz.yourboykyle.secretroutes.commands.ChangeRoute;
import xyz.yourboykyle.secretroutes.commands.Debug;
import xyz.yourboykyle.secretroutes.commands.LoadRoute;
import xyz.yourboykyle.secretroutes.commands.Recording;
import xyz.yourboykyle.secretroutes.commands.SRM;
import xyz.yourboykyle.secretroutes.config.SRMConfig;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.DungeonRooms;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.dungeons.catacombs.RoomDetection;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.handlers.PacketHandler;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.utils.Utils;
import xyz.yourboykyle.secretroutes.events.GuildEvents;
import xyz.yourboykyle.secretroutes.events.OnBlockPlace;
import xyz.yourboykyle.secretroutes.events.OnChatReceive;
import xyz.yourboykyle.secretroutes.events.OnGuiRender;
import xyz.yourboykyle.secretroutes.events.OnItemPickedUp;
import xyz.yourboykyle.secretroutes.events.OnMouseInput;
import xyz.yourboykyle.secretroutes.events.OnPlaySound;
import xyz.yourboykyle.secretroutes.events.OnPlayerTick;
import xyz.yourboykyle.secretroutes.events.OnRecievePacket;
import xyz.yourboykyle.secretroutes.events.OnSendPacket;
import xyz.yourboykyle.secretroutes.events.OnWorldRender;
import xyz.yourboykyle.secretroutes.utils.APIUtils;
import xyz.yourboykyle.secretroutes.utils.ChatUtils;
import xyz.yourboykyle.secretroutes.utils.ConfigUtils;
import xyz.yourboykyle.secretroutes.utils.FileUtils;
import xyz.yourboykyle.secretroutes.utils.LogUtils;
import xyz.yourboykyle.secretroutes.utils.PBUtils;
import xyz.yourboykyle.secretroutes.utils.Room;
import xyz.yourboykyle.secretroutes.utils.RouteRecording;
import xyz.yourboykyle.secretroutes.utils.RouteUtils;
import xyz.yourboykyle.secretroutes.utils.SSLUtils;
import xyz.yourboykyle.secretroutes.utils.autoupdate.UpdateManager;

@Mod(modid="secretroutesmod", name="SecretRoutes", version="0.4.16")
public class Main {
    public static final String MODID = "secretroutesmod";
    public static final String NAME = "SecretRoutes";
    public static final String VERSION = "0.4.16";
    public static final String CONFIG_FOLDER_PATH = Minecraft.func_71410_x().field_71412_D.getAbsolutePath() + File.separator + "config" + File.separator + "SecretRoutes";
    public static final String ROUTES_PATH = Minecraft.func_71410_x().field_71412_D.getAbsolutePath() + File.separator + "config" + File.separator + "SecretRoutes" + File.separator + "routes";
    public static final String COLOR_PROFILE_PATH = Minecraft.func_71410_x().field_71412_D.getAbsolutePath() + File.separator + "config" + File.separator + "SecretRoutes" + File.separator + "colorprofiles";
    public static final String tmpDir = Minecraft.func_71410_x().field_71412_D.getAbsolutePath() + File.separator + "SecretRoutes" + File.separator + "tmp";
    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    public static final File logDir = new File(Minecraft.func_71410_x().field_71412_D.getAbsolutePath() + File.separator + "logs" + File.separator + "SecretRoutes");
    public static File outputLogs;
    public static Room currentRoom;
    public static RouteRecording routeRecording;
    public static UpdateManager updateManager;
    private static DungeonRooms dungeonRooms;
    public static Main instance;
    public static SRMConfig config;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent e) {
        dungeonRooms.preInit(e);
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent e) {
        File shellFile;
        File batchFile;
        String jarpath = Main.class.getProtectionDomain().getCodeSource().getLocation().getPath();
        String date = sdf.format(System.currentTimeMillis());
        outputLogs = new File(logDir + File.separator + "LATEST-" + date + ".log");
        if (!logDir.exists()) {
            logDir.mkdirs();
        } else {
            File[] files;
            for (File file : files = logDir.listFiles((dir, name) -> name.startsWith("LATEST"))) {
                File[] logFiles = logDir.listFiles((dir, name) -> name.contains(date));
                int logsNo = logFiles == null ? 1 : logFiles.length;
                String newName = file.getName().replaceFirst("LATEST-", "").split("\\.")[0] + "-" + logsNo + ".log";
                File renamedFile = new File(logDir + File.separator + newName);
                file.renameTo(renamedFile);
            }
        }
        try {
            outputLogs.createNewFile();
        }
        catch (IOException e1) {
            System.out.println("Secret Routes Mod logging file creation failed :(");
            e1.printStackTrace();
        }
        LogUtils.info("Jarpath: " + jarpath);
        if (!new File(tmpDir).exists()) {
            new File(tmpDir).mkdirs();
        }
        if ((batchFile = new File(tmpDir + File.separator + "update.bat")).exists()) {
            batchFile.delete();
        }
        if ((shellFile = new File(tmpDir + File.separator + "update.sh")).exists()) {
            shellFile.delete();
        }
        LogUtils.info("\u00a7bSetting ssl certificate");
        SSLUtils.setSSlCertificate();
        routeRecording = new RouteRecording();
        config = new SRMConfig();
        LogUtils.info("Checking for updates...");
        instance = this;
        dungeonRooms.init(e);
        Main.checkRoutesData();
        Main.checkProfilesData();
        Main.checkPBData();
        PBUtils.loadPBData();
        MinecraftForge.EVENT_BUS.register((Object)new OnBlockPlace());
        MinecraftForge.EVENT_BUS.register((Object)new OnItemPickedUp());
        MinecraftForge.EVENT_BUS.register((Object)new OnPlayerTick());
        MinecraftForge.EVENT_BUS.register((Object)new OnPlaySound());
        MinecraftForge.EVENT_BUS.register((Object)new OnRecievePacket());
        MinecraftForge.EVENT_BUS.register((Object)new OnSendPacket());
        MinecraftForge.EVENT_BUS.register((Object)new OnWorldRender());
        MinecraftForge.EVENT_BUS.register((Object)new OnMouseInput());
        MinecraftForge.EVENT_BUS.register((Object)new OnChatReceive());
        MinecraftForge.EVENT_BUS.register((Object)new OnGuiRender());
        MinecraftForge.EVENT_BUS.register((Object)new GuildEvents());
        MinecraftForge.EVENT_BUS.register((Object)this);
        ClientCommandHandler.instance.func_71560_a((ICommand)new LoadRoute());
        ClientCommandHandler.instance.func_71560_a((ICommand)new Recording());
        ClientCommandHandler.instance.func_71560_a((ICommand)new SRM());
        ClientCommandHandler.instance.func_71560_a((ICommand)new ChangeRoute());
        ClientCommandHandler.instance.func_71560_a((ICommand)new ChangeColorProfile());
        ClientCommandHandler.instance.func_71560_a((ICommand)new Debug());
        if (SRMConfig.autoUpdateRoutes) {
            new Thread(() -> {
                try {
                    RouteUtils.checkRoutesFiles();
                }
                catch (Exception e1) {
                    LogUtils.error(e1);
                }
            }).start();
        }
        RoomDetection.roomName = "undefined";
        RoomDetection.roomCorner = new Point(0, 0);
        RoomDetection.roomDirection = "NW";
    }

    public static void checkRoomData() {
        if (RoomDetection.roomName == null) {
            RoomDetection.roomName = "undefined";
        }
        if (RoomDetection.roomCorner == null) {
            RoomDetection.roomCorner = new Point(0, 0);
        }
        if (RoomDetection.roomDirection == null) {
            RoomDetection.roomDirection = "NW";
        }
    }

    public static void checkProfilesData() {
        try {
            String filePath = "default.json";
            File colorProfileDir = new File(COLOR_PROFILE_PATH);
            if (!colorProfileDir.exists()) {
                colorProfileDir.mkdirs();
            }
            if (FileUtils.getFileNames(COLOR_PROFILE_PATH).isEmpty()) {
                ConfigUtils.writeColorConfig(filePath);
            }
        }
        catch (Exception e) {
            LogUtils.error(e);
        }
    }

    public static void checkRoutesData() {
        try {
            String filePath = ROUTES_PATH + File.separator + "routes.json";
            File configDir = new File(ROUTES_PATH);
            if (!configDir.exists()) {
                configDir.mkdirs();
            }
            File configFile = new File(filePath);
            File configFilePearl = new File(ROUTES_PATH + File.separator + "pearlroutes.json");
            if (!configFile.exists()) {
                RouteUtils.updateRoutes(configFile);
            }
            if (!configFilePearl.exists()) {
                RouteUtils.updatePearlRoutes();
            }
        }
        catch (Exception e) {
            LogUtils.error(e);
        }
    }

    public static void checkPBData() {
        try {
            File configFile;
            String filePath = CONFIG_FOLDER_PATH + File.separator + "personal_bests.json";
            File configDir = new File(CONFIG_FOLDER_PATH);
            if (!configDir.exists()) {
                configDir.mkdirs();
            }
            if (!(configFile = new File(filePath)).exists()) {
                configFile.createNewFile();
                FileWriter pbWriter = new FileWriter(configFile);
                pbWriter.write("{}");
                pbWriter.close();
            }
        }
        catch (Exception e) {
            LogUtils.error(e);
        }
    }

    @SubscribeEvent
    public void onServerConnect(FMLNetworkEvent.ClientConnectedToServerEvent event) {
        try {
            Thread.sleep(3000L);
        }
        catch (Exception exception) {
            // empty catch block
        }
        Minecraft mc = Minecraft.func_71410_x();
        if (mc.func_147104_D() == null) {
            return;
        }
        if (mc.func_147104_D().field_78845_b.toLowerCase().contains("hypixel.")) {
            if (SRMConfig.autoCheckUpdates) {
                new Thread(() -> {
                    try {
                        updateManager.checkUpdate(false);
                    }
                    catch (Exception e) {
                        LogUtils.error(e);
                    }
                }).start();
            }
            new Thread(() -> {
                try {
                    Thread.sleep(3000L);
                }
                catch (Exception exception) {
                    // empty catch block
                }
                byte res = APIUtils.addMember();
                if (res == 1) {
                    ChatUtils.sendChatMessage("\u00a7aFirst logon detected... things work");
                } else if (res == 0) {
                    ChatUtils.sendChatMessage("\u00a7aWelcome back!");
                }
            }).start();
            if (!APIUtils.apiQueued) {
                Runtime.getRuntime().addShutdownHook(new Thread(APIUtils::offline));
                APIUtils.apiQueued = true;
            }
            event.manager.channel().pipeline().addBefore("packet_handler", "secretroutes_packet_handler", (ChannelHandler)new PacketHandler());
            new Thread(() -> {
                try {
                    while (mc.field_71439_g == null) {
                        Thread.sleep(100L);
                    }
                    Thread.sleep(3000L);
                    if (mc.func_147104_D().field_78845_b.toLowerCase().contains("hypixel.")) {
                        Utils.checkForConflictingHotkeys();
                    }
                }
                catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }).start();
            LogUtils.info("RouteRecording json status: " + RouteRecording.malformed);
            if (RouteRecording.malformed) {
                ChatUtils.sendChatMessage("[ERROR] The JSON file in downloads is malformed. Check the file or delete it.", EnumChatFormatting.RED);
            }
        }
    }

    public static void toggleSecretsKeybind() {
        if (SRMConfig.modEnabled) {
            SRMConfig.modEnabled = false;
            ChatUtils.sendChatMessage(EnumChatFormatting.RED + "Secret Routes Mod secret rendering has been disabled.");
        } else {
            SRMConfig.modEnabled = true;
            ChatUtils.sendChatMessage(EnumChatFormatting.GREEN + "Secret Routes Mod secret rendering has been enabled.");
        }
    }

    static {
        currentRoom = new Room(null);
        routeRecording = null;
        updateManager = new UpdateManager();
        dungeonRooms = new DungeonRooms();
        instance = new Main();
    }
}

