/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.command.CommandBase
 *  net.minecraft.command.CommandException
 *  net.minecraft.command.ICommandSender
 *  net.minecraft.util.ChatComponentText
 *  net.minecraft.util.IChatComponent
 */
package xyz.yourboykyle.secretroutes.commands;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import net.minecraft.client.Minecraft;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IChatComponent;
import xyz.yourboykyle.secretroutes.Main;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.dungeons.catacombs.RoomDetection;
import xyz.yourboykyle.secretroutes.utils.LogUtils;
import xyz.yourboykyle.secretroutes.utils.Room;

public class LoadRoute
extends CommandBase {
    public String func_71517_b() {
        return "loadroute";
    }

    public String func_71518_a(ICommandSender sender) {
        return "/loadroute";
    }

    public void func_71515_b(ICommandSender sender, String[] args) throws CommandException {
        String filePath = System.getProperty("user.home") + File.separator + "Downloads" + File.separator + "routes.json";
        try {
            Gson gson = new GsonBuilder().create();
            FileReader reader = new FileReader(filePath);
            JsonObject data = gson.fromJson((Reader)reader, JsonObject.class);
            Main.currentRoom = new Room(RoomDetection.roomName, filePath);
            Minecraft.func_71410_x().field_71439_g.func_145747_a((IChatComponent)new ChatComponentText("Loaded Route."));
        }
        catch (IOException e) {
            LogUtils.error(e);
        }
    }

    public int func_82362_a() {
        return 0;
    }
}

