/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.command.CommandBase
 *  net.minecraft.command.CommandException
 *  net.minecraft.command.ICommandSender
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumChatFormatting
 */
package xyz.yourboykyle.secretroutes.commands;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumChatFormatting;
import xyz.yourboykyle.secretroutes.Main;
import xyz.yourboykyle.secretroutes.config.SRMConfig;
import xyz.yourboykyle.secretroutes.utils.ChatUtils;
import xyz.yourboykyle.secretroutes.utils.FileUtils;

public class ChangeRoute
extends CommandBase {
    private ArrayList<String> subCommands = new ArrayList();
    private ArrayList<String> entries = new ArrayList();

    public ChangeRoute() {
        this.subCommands.add("list");
        this.subCommands.add("load");
    }

    public String func_71517_b() {
        return "changeroute";
    }

    public String func_71518_a(ICommandSender sender) {
        return "/changeroute [list|load [route]]";
    }

    public void func_71515_b(ICommandSender sender, String[] args) throws CommandException {
        if (args.length == 0) {
            ChatUtils.sendChatMessage("Incorrect usage: /changeroute [list|load [route]]", EnumChatFormatting.RED);
            return;
        }
        if (args.length == 1 && args[0].equals(this.subCommands.get(0))) {
            this.entries.addAll(FileUtils.getRouteFileNames());
            ChatUtils.sendChatMessage("Routes:", EnumChatFormatting.DARK_AQUA);
            for (String entry : this.entries) {
                ChatUtils.sendChatMessage(" - " + entry, EnumChatFormatting.AQUA);
            }
        } else if (args.length == 1 && args[0].equals(this.subCommands.get(1))) {
            ChatUtils.sendChatMessage("Incorrect usage: /changeroute load [routename]", EnumChatFormatting.RED);
        } else if (args.length == 2 && args[0].equals(this.subCommands.get(1))) {
            if (FileUtils.doesFileExist(Main.ROUTES_PATH + File.separator + args[1])) {
                SRMConfig.routesFileName = args[1];
                ChatUtils.sendChatMessage("Loaded " + args[1] + " as filename for custom routes", EnumChatFormatting.DARK_GREEN);
            } else {
                ChatUtils.sendChatMessage("Specified file does not exist", EnumChatFormatting.RED);
            }
        } else if (args.length > 2 && args[0].equals(this.subCommands.get(1))) {
            StringBuilder sb = new StringBuilder("\"");
            for (int i = 1; i < args.length; ++i) {
                sb.append(args[i]).append(" ");
            }
            sb.deleteCharAt(sb.length() - 1).append("\"");
            SRMConfig.routesFileName = sb.toString();
        }
    }

    public int func_82362_a() {
        return 0;
    }

    public List<String> func_71514_a() {
        ArrayList<String> aliases = new ArrayList<String>();
        aliases.add("cr");
        aliases.add("croute");
        return aliases;
    }

    public List<String> func_180525_a(ICommandSender sender, String[] args, BlockPos pos) {
        ArrayList<String> completions = new ArrayList<String>();
        ArrayList<String> basicOptions = new ArrayList<String>();
        basicOptions.add("list");
        basicOptions.add("load");
        switch (args.length) {
            case 0: {
                completions.addAll(basicOptions);
            }
            case 1: {
                completions.addAll(basicOptions);
                completions.removeIf(completion -> !completion.toLowerCase().startsWith(args[0].toLowerCase()));
                break;
            }
            case 2: {
                if (args[0].equalsIgnoreCase("load")) {
                    completions.addAll(FileUtils.getRouteFileNames());
                    break;
                }
            }
            case 3: {
                if (!args[0].equalsIgnoreCase("load")) break;
                completions.addAll(FileUtils.getRouteFileNames());
                completions.removeIf(completion -> !completion.toLowerCase().startsWith(args[1].toLowerCase()));
            }
        }
        return completions;
    }
}

