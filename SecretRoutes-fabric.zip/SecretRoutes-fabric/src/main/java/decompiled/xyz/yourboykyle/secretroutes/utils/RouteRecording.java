/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumChatFormatting
 */
package xyz.yourboykyle.secretroutes.utils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSyntaxException;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumChatFormatting;
import xyz.yourboykyle.secretroutes.Main;
import xyz.yourboykyle.secretroutes.config.SRMConfig;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.dungeons.catacombs.RoomDetection;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.utils.MapUtils;
import xyz.yourboykyle.secretroutes.utils.ChatUtils;
import xyz.yourboykyle.secretroutes.utils.LogUtils;
import xyz.yourboykyle.secretroutes.utils.Room;
import xyz.yourboykyle.secretroutes.utils.RotationUtils;
import xyz.yourboykyle.secretroutes.utils.multistorage.Triple;

public class RouteRecording {
    private static final String verboseTag = "Recording";
    public boolean recording = false;
    public JsonObject allSecretRoutes = new JsonObject();
    public JsonArray currentSecretRoute = new JsonArray();
    public JsonObject currentSecretWaypoints = new JsonObject();
    public String recordingMessage = "Recording...";
    private static int tntWaypoints = 0;
    private static int interactWaypoints = 0;
    private static int minewaypoints = 0;
    private static int etherwaypoints = 0;
    private static int locationwaypoints = 0;
    private static int enderPearlWaypoints = 0;
    private static int enderPearlAngleWaypoints = 0;
    public static boolean malformed = false;
    public BlockPos previousLocation;

    public RouteRecording() {
        this.currentSecretWaypoints.add("locations", new JsonArray());
        this.currentSecretWaypoints.add("etherwarps", new JsonArray());
        this.currentSecretWaypoints.add("mines", new JsonArray());
        this.currentSecretWaypoints.add("interacts", new JsonArray());
        this.currentSecretWaypoints.add("tnts", new JsonArray());
        this.currentSecretWaypoints.add("enderpearls", new JsonArray());
        this.currentSecretWaypoints.add("enderpearlangles", new JsonArray());
        this.importRoutes("routes.json");
    }

    public void startRecording() {
        this.recording = true;
        ChatUtils.sendVerboseMessage("\u00a7eRecording started...", verboseTag);
        SRMConfig.recordingHUD.enable();
        SRMConfig.currentRoomHUD.enable();
    }

    public void stopRecording() {
        this.recording = false;
        this.newRoute();
        ChatUtils.sendVerboseMessage("\u00a7eRecording stopped.", verboseTag);
        ChatUtils.sendVerboseMessage("\u00a76  Locations: " + locationwaypoints, verboseTag);
        ChatUtils.sendVerboseMessage("\u00a76  Etherwarps: " + etherwaypoints, verboseTag);
        ChatUtils.sendVerboseMessage("\u00a76  Mines: " + minewaypoints, verboseTag);
        ChatUtils.sendVerboseMessage("\u00a76  Interacts: " + interactWaypoints, verboseTag);
        ChatUtils.sendVerboseMessage("\u00a76  TNTs: " + tntWaypoints, verboseTag);
        ChatUtils.sendVerboseMessage("\u00a76  Enderpearls: " + enderPearlWaypoints, verboseTag);
        ChatUtils.sendVerboseMessage("\u00a76  Enderpearl Angles (should equal enderpearls): " + enderPearlAngleWaypoints, verboseTag);
        locationwaypoints = 0;
        etherwaypoints = 0;
        minewaypoints = 0;
        interactWaypoints = 0;
        tntWaypoints = 0;
        enderPearlWaypoints = 0;
        enderPearlAngleWaypoints = 0;
        SRMConfig.recordingHUD.disable();
        SRMConfig.currentRoomHUD.disable();
    }

    public void importRoutes(String fileName) {
        String filePath = System.getProperty("user.home") + File.separator + "Downloads" + File.separator + fileName;
        if (new File(filePath).exists()) {
            this.allSecretRoutes = new JsonObject();
            try {
                Gson gson = new GsonBuilder().create();
                FileReader reader = new FileReader(filePath);
                this.allSecretRoutes = gson.fromJson((Reader)reader, JsonObject.class);
            }
            catch (JsonSyntaxException e) {
                LogUtils.error(e);
                malformed = true;
            }
            catch (Exception e) {
                LogUtils.error(e);
            }
        }
    }

    public void addWaypoint(Room.WAYPOINT_TYPES type, BlockPos pos) {
        ChatUtils.sendVerboseMessage("\u00a7d Adding waypoint...", verboseTag);
        Main.checkRoomData();
        BlockPos relPos = MapUtils.actualToRelative(pos, RoomDetection.roomDirection, RoomDetection.roomCorner);
        JsonArray posArray = new JsonArray();
        posArray.add(new JsonPrimitive(relPos.func_177958_n()));
        posArray.add(new JsonPrimitive(relPos.func_177956_o()));
        posArray.add(new JsonPrimitive(relPos.func_177952_p()));
        ChatUtils.sendVerboseMessage("\u00a7d  Waypoint Type: " + (Object)((Object)type), verboseTag);
        if (type == Room.WAYPOINT_TYPES.LOCATIONS) {
            boolean shouldAddWaypoint = true;
            int count = 0;
            JsonArray array = this.currentSecretWaypoints.get("locations").getAsJsonArray();
            for (JsonElement element : array) {
                JsonArray location = element.getAsJsonArray();
                if (count < array.size() && location.equals(posArray)) {
                    shouldAddWaypoint = false;
                    break;
                }
                ++count;
            }
            if (shouldAddWaypoint) {
                ++locationwaypoints;
                ChatUtils.sendVerboseMessage("\u00a7d  Adding location waypoint...", verboseTag);
                this.currentSecretWaypoints.get("locations").getAsJsonArray().add(posArray);
            }
        } else if (type == Room.WAYPOINT_TYPES.ETHERWARPS) {
            ++etherwaypoints;
            boolean shouldAddWaypoint = true;
            int count = 0;
            JsonArray array = this.currentSecretWaypoints.get("etherwarps").getAsJsonArray();
            for (JsonElement element : array) {
                JsonArray location = element.getAsJsonArray();
                if (count < array.size() && location.equals(posArray)) {
                    shouldAddWaypoint = false;
                    break;
                }
                ++count;
            }
            if (shouldAddWaypoint) {
                ChatUtils.sendVerboseMessage("\u00a7d  Adding etherwarp waypoint...", verboseTag);
                this.currentSecretWaypoints.get("etherwarps").getAsJsonArray().add(posArray);
            }
        } else if (type == Room.WAYPOINT_TYPES.MINES) {
            ++minewaypoints;
            boolean shouldAddWaypoint = true;
            int count = 0;
            JsonArray array = this.currentSecretWaypoints.get("mines").getAsJsonArray();
            for (JsonElement element : array) {
                JsonArray location = element.getAsJsonArray();
                if (count < array.size() && location.equals(posArray)) {
                    shouldAddWaypoint = false;
                    break;
                }
                ++count;
            }
            if (shouldAddWaypoint) {
                ChatUtils.sendVerboseMessage("\u00a7d  Adding mine waypoint...", verboseTag);
                this.currentSecretWaypoints.get("mines").getAsJsonArray().add(posArray);
            }
        } else if (type == Room.WAYPOINT_TYPES.INTERACTS) {
            ++interactWaypoints;
            boolean shouldAddWaypoint = true;
            int count = 0;
            JsonArray array = this.currentSecretWaypoints.get("interacts").getAsJsonArray();
            for (JsonElement element : array) {
                JsonArray location = element.getAsJsonArray();
                if (count < array.size() && location.equals(posArray)) {
                    shouldAddWaypoint = false;
                    break;
                }
                ++count;
            }
            if (shouldAddWaypoint) {
                ChatUtils.sendVerboseMessage("\u00a7d  Adding interact waypoint...", verboseTag);
                this.currentSecretWaypoints.get("interacts").getAsJsonArray().add(posArray);
            }
        } else if (type == Room.WAYPOINT_TYPES.TNTS) {
            ++tntWaypoints;
            boolean shouldAddWaypoint = true;
            int count = 0;
            JsonArray array = this.currentSecretWaypoints.get("tnts").getAsJsonArray();
            for (JsonElement element : array) {
                JsonArray location = element.getAsJsonArray();
                if (count < array.size() && location.equals(posArray)) {
                    ChatUtils.sendVerboseMessage("\u00a75 Waypoint not added", verboseTag);
                    shouldAddWaypoint = false;
                    break;
                }
                ++count;
            }
            if (shouldAddWaypoint) {
                ChatUtils.sendVerboseMessage("\u00a7d  Adding TNT waypoint...", verboseTag);
                this.currentSecretWaypoints.get("tnts").getAsJsonArray().add(posArray);
            }
        }
    }

    public void addWaypoint(Room.WAYPOINT_TYPES type, EntityPlayer player) {
        ChatUtils.sendVerboseMessage("\u00a7d Adding waypoint...", verboseTag);
        Main.checkRoomData();
        JsonArray posArray = new JsonArray();
        Triple<Double, Double, Double> relativePos = MapUtils.actualToRelative(player.field_70165_t, player.field_70163_u, player.field_70161_v, RoomDetection.roomDirection, RoomDetection.roomCorner);
        posArray.add(new JsonPrimitive((Number)relativePos.getOne()));
        posArray.add(new JsonPrimitive((Number)relativePos.getTwo()));
        posArray.add(new JsonPrimitive(relativePos.getThree()));
        ChatUtils.sendVerboseMessage("\u00a7d  Waypoint Type: " + (Object)((Object)type), verboseTag);
        if (type == Room.WAYPOINT_TYPES.ENDERPEARLS) {
            ++enderPearlWaypoints;
            ++enderPearlAngleWaypoints;
            boolean shouldAddWaypoint = true;
            int count = 0;
            JsonArray array = this.currentSecretWaypoints.get("enderpearls").getAsJsonArray();
            for (JsonElement element : array) {
                JsonArray location = element.getAsJsonArray();
                if (count < array.size() && location.equals(posArray)) {
                    shouldAddWaypoint = false;
                    break;
                }
                ++count;
            }
            JsonArray anglePosArray = new JsonArray();
            anglePosArray.add(new JsonPrimitive(Float.valueOf(Minecraft.func_71410_x().field_71439_g.field_70125_A)));
            anglePosArray.add(new JsonPrimitive(Float.valueOf(RotationUtils.actualToRelativeYaw(Minecraft.func_71410_x().field_71439_g.field_70177_z % 360.0f, RoomDetection.roomDirection))));
            JsonArray anglesArray = this.currentSecretWaypoints.get("enderpearlangles").getAsJsonArray();
            for (JsonElement element : anglesArray) {
                JsonArray rotation = element.getAsJsonArray();
                if (count < array.size() && rotation.equals(anglePosArray)) {
                    shouldAddWaypoint = false;
                    break;
                }
                ++count;
            }
            if (shouldAddWaypoint) {
                ChatUtils.sendVerboseMessage("\u00a7d  Adding Ender Pearl waypoint...", verboseTag);
                this.currentSecretWaypoints.get("enderpearls").getAsJsonArray().add(posArray);
                this.currentSecretWaypoints.get("enderpearlangles").getAsJsonArray().add(anglePosArray);
            }
        }
    }

    public boolean addWaypoint(Room.SECRET_TYPES type, BlockPos pos) {
        Main.checkRoomData();
        BlockPos relPos = MapUtils.actualToRelative(pos, RoomDetection.roomDirection, RoomDetection.roomCorner);
        JsonArray posArray = new JsonArray();
        posArray.add(new JsonPrimitive(relPos.func_177958_n()));
        posArray.add(new JsonPrimitive(relPos.func_177956_o()));
        posArray.add(new JsonPrimitive(relPos.func_177952_p()));
        JsonObject secret = new JsonObject();
        if (type == Room.SECRET_TYPES.INTERACT) {
            secret.add("type", new JsonPrimitive("interact"));
        } else if (type == Room.SECRET_TYPES.ITEM) {
            secret.add("type", new JsonPrimitive("item"));
        } else if (type == Room.SECRET_TYPES.BAT) {
            secret.add("type", new JsonPrimitive("bat"));
        } else if (type == Room.SECRET_TYPES.EXITROUTE) {
            secret.add("type", new JsonPrimitive("exitroute"));
        }
        boolean shouldAddWaypoint = true;
        int count = 0;
        for (JsonElement element : this.currentSecretRoute) {
            JsonObject secretWaypoints;
            JsonArray location;
            JsonObject waypoints = element.getAsJsonObject();
            if (count < this.currentSecretRoute.size() && waypoints.get("secret") != null && waypoints.get("secret").getAsJsonObject().get("location") != null && (location = (secretWaypoints = waypoints.get("secret").getAsJsonObject()).get("location").getAsJsonArray()).equals(posArray)) {
                shouldAddWaypoint = false;
            }
            ++count;
        }
        secret.add("location", posArray);
        if (shouldAddWaypoint) {
            this.currentSecretWaypoints.add("secret", secret);
            return true;
        }
        return false;
    }

    public void newSecret() {
        this.currentSecretRoute.add(this.currentSecretWaypoints);
        this.currentSecretWaypoints = new JsonObject();
        this.currentSecretWaypoints.add("locations", new JsonArray());
        this.currentSecretWaypoints.add("etherwarps", new JsonArray());
        this.currentSecretWaypoints.add("mines", new JsonArray());
        this.currentSecretWaypoints.add("interacts", new JsonArray());
        this.currentSecretWaypoints.add("tnts", new JsonArray());
        this.currentSecretWaypoints.add("enderpearls", new JsonArray());
        this.currentSecretWaypoints.add("enderpearlangles", new JsonArray());
    }

    public void newRoute() {
        this.allSecretRoutes.add(SRMConfig.routeNumber != 0 ? RoomDetection.roomName + ":" + SRMConfig.routeNumber : RoomDetection.roomName, this.currentSecretRoute);
        this.currentSecretRoute = new JsonArray();
        this.currentSecretWaypoints = new JsonObject();
        this.currentSecretWaypoints.add("locations", new JsonArray());
        this.currentSecretWaypoints.add("etherwarps", new JsonArray());
        this.currentSecretWaypoints.add("mines", new JsonArray());
        this.currentSecretWaypoints.add("interacts", new JsonArray());
        this.currentSecretWaypoints.add("tnts", new JsonArray());
        this.currentSecretWaypoints.add("enderpearls", new JsonArray());
        this.currentSecretWaypoints.add("enderpearlangles", new JsonArray());
    }

    public void exportAllRoutes() {
        String filePath = System.getProperty("user.home") + File.separator + "Downloads";
        String fileName = "routes.json";
        File file = new File(filePath, fileName);
        try {
            FileWriter writer = new FileWriter(file);
            writer.write(RouteRecording.prettyPrint(this.allSecretRoutes));
            writer.flush();
            writer.close();
            ChatUtils.sendChatMessage(EnumChatFormatting.DARK_GREEN + "Exported routes to " + filePath + File.separator + fileName);
        }
        catch (IOException e) {
            LogUtils.error(e);
        }
    }

    public static String prettyPrint(JsonObject jsonObject) {
        Gson gson = new GsonBuilder().create();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("{\n");
        for (Map.Entry<String, JsonElement> entry : jsonObject.entrySet()) {
            stringBuilder.append("\t\"").append(entry.getKey()).append("\": ").append(gson.toJson(entry.getValue())).append(",\n");
        }
        stringBuilder.deleteCharAt(stringBuilder.length() - 2);
        stringBuilder.append("}\n");
        return stringBuilder.toString();
    }

    public void setRecordingMessage(String message) {
        this.recordingMessage = message;
        new Thread(() -> {
            try {
                Thread.sleep(1500L);
                if (this.recordingMessage.equals(message)) {
                    this.recordingMessage = "Recording...";
                }
            }
            catch (InterruptedException e) {
                LogUtils.error(e);
            }
        }).start();
    }
}

