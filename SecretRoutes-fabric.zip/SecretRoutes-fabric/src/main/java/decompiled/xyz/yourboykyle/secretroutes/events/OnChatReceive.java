/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.BlockPos
 *  net.minecraftforge.client.event.ClientChatReceivedEvent
 *  net.minecraftforge.fml.common.eventhandler.EventPriority
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package xyz.yourboykyle.secretroutes.events;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.util.BlockPos;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import xyz.yourboykyle.secretroutes.Main;
import xyz.yourboykyle.secretroutes.config.SRMConfig;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.dungeons.catacombs.RoomDetection;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.utils.MapUtils;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.utils.Utils;
import xyz.yourboykyle.secretroutes.events.OnGuiRender;
import xyz.yourboykyle.secretroutes.utils.BlockUtils;
import xyz.yourboykyle.secretroutes.utils.ChatUtils;
import xyz.yourboykyle.secretroutes.utils.LogUtils;
import xyz.yourboykyle.secretroutes.utils.SecretUtils;

public class OnChatReceive {
    Long lastSent = System.currentTimeMillis();
    private static String[] sections = null;
    private static String unformated = "";
    private static boolean allFound = false;
    private static HashMap<String, String> msgMap = new HashMap();

    @SubscribeEvent(priority=EventPriority.HIGH)
    public void onChatReceive(ClientChatReceivedEvent e) {
        Utils.checkForSkyblock();
        Utils.checkForCatacombs();
        if (!Utils.inSkyblock) {
            return;
        }
        String unformatted = e.message.func_150260_c();
        String secrets = "";
        if (e.type == 2) {
            Matcher matcher = Pattern.compile("\u00a77(?<roomCollectedSecrets>\\d+)/(?<roomTotalSecrets>\\d+) Secrets").matcher(unformatted);
            if (matcher.find()) {
                int secretsFound;
                int roomSecrets = Integer.parseInt(matcher.group("roomTotalSecrets"));
                if (roomSecrets == (secretsFound = Integer.parseInt(matcher.group("roomCollectedSecrets")))) {
                    ChatUtils.sendVerboseMessage("\u00a7aAll secrets found!", "Actionbar");
                    allFound = true;
                } else {
                    ChatUtils.sendVerboseMessage("\u00a79(" + secretsFound + "/" + roomSecrets + ")", "Actionbar");
                    allFound = false;
                }
            }
        } else if (e.message.func_150254_d().startsWith("\u00a7r\u00a7cThat chest is locked")) {
            LogUtils.info("\u00a7aLocked chest detected!");
            new Thread(() -> {
                try {
                    Thread.sleep(100L);
                }
                catch (InterruptedException interruptedException) {
                    // empty catch block
                }
                SecretUtils.secretLocations.remove(BlockUtils.blockPos(SecretUtils.lastInteract));
            }).start();
            SecretUtils.renderLever = true;
            JsonObject route = Main.currentRoom.currentSecretRoute.get(Main.currentRoom.currentSecretIndex - 1).getAsJsonObject().get("secret").getAsJsonObject();
            JsonArray loc = route.get("location").getAsJsonArray();
            BlockPos pos = new BlockPos(loc.get(0).getAsInt(), loc.get(1).getAsInt(), loc.get(2).getAsInt());
            if (route.get("type").getAsString().equals("interact")) {
                if (BlockUtils.compareBlocks(MapUtils.actualToRelative(SecretUtils.lastInteract, RoomDetection.roomDirection, RoomDetection.roomCorner), pos, 0)) {
                    Main.currentRoom.lastSecretKeybind();
                }
                ChatUtils.sendChatMessage("Distance : " + BlockUtils.blockDistance(MapUtils.actualToRelative(SecretUtils.lastInteract, RoomDetection.roomDirection, RoomDetection.roomCorner), pos));
            }
        }
    }

    public static boolean isAllFound() {
        return allFound;
    }

    @SubscribeEvent(priority=EventPriority.LOWEST)
    public void hideBossMessages(ClientChatReceivedEvent e) {
        if (e.type == 2) {
            return;
        }
        if (SRMConfig.hideBossMessages) {
            String formated;
            if (msgMap.isEmpty()) {
                msgMap.put("\u00a7r\u00a7c[BOSS] The Watcher", "hideWatcher");
                msgMap.put("\u00a7r\u00a7c[BOSS] Bonzo", "hideBonzo");
                msgMap.put("\u00a7r\u00a7c[BOSS] Scarf", "hideScarf");
                msgMap.put("\u00a7r\u00a7c[BOSS] The Professor", "hideProfessor");
                msgMap.put("\u00a7r\u00a7c[BOSS] Thorn", "hideThorn");
                msgMap.put("\u00a7r\u00a7c[BOSS] Livid", "hideLivid");
                msgMap.put("\u00a7r\u00a7c[BOSS] Sadan", "hideSadan");
                msgMap.put("\u00a7r\u00a74[BOSS] Maxor", "hideWitherLords");
                msgMap.put("\u00a7r\u00a74[BOSS] Storm", "hideWitherLords");
                msgMap.put("\u00a7r\u00a74[BOSS] Goldor", "hideWitherLords");
                msgMap.put("\u00a7r\u00a74[BOSS] Necron", "hideWitherLords");
            }
            if (!(formated = e.message.func_150254_d()).contains("BOSS")) {
                return;
            }
            if (SRMConfig.bloodNotif && formated.equals("\u00a7r\u00a7c[BOSS] The Watcher\u00a7r\u00a7f: That will be enough for now.\u00a7r")) {
                ChatUtils.sendChatMessage("KILL BLOOD");
                OnGuiRender.spawnNotifTime = System.currentTimeMillis() + (long)SRMConfig.bloodBannerDuration;
            }
            for (Map.Entry<String, String> entry : msgMap.entrySet()) {
                try {
                    Field field = SRMConfig.class.getField(entry.getValue());
                    field.setAccessible(true);
                    if (!formated.startsWith(entry.getKey()) || !field.getBoolean(null)) continue;
                    e.setCanceled(true);
                }
                catch (NoSuchFieldException ex) {
                    LogUtils.info("I (_Wyan) screwed up. No filed : " + entry.getValue());
                }
                catch (IllegalAccessException ex) {
                    LogUtils.info("I (_Wyan) screwed up. Field not accessible: " + entry.getValue());
                }
            }
        }
    }
}

