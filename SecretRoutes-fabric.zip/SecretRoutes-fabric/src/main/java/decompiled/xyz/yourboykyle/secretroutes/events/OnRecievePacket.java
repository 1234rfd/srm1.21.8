/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.multiplayer.WorldClient
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityItem
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Blocks
 *  net.minecraft.network.play.server.S0DPacketCollectItem
 *  net.minecraft.network.play.server.S23PacketBlockChange
 *  net.minecraft.network.play.server.S32PacketConfirmTransaction
 *  net.minecraft.util.BlockPos
 *  net.minecraft.world.World
 *  net.minecraftforge.common.util.BlockSnapshot
 *  net.minecraftforge.event.world.BlockEvent$BreakEvent
 *  net.minecraftforge.event.world.BlockEvent$PlaceEvent
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 *  net.minecraftforge.fml.common.gameevent.PlayerEvent$ItemPickupEvent
 */
package xyz.yourboykyle.secretroutes.events;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.server.S0DPacketCollectItem;
import net.minecraft.network.play.server.S23PacketBlockChange;
import net.minecraft.network.play.server.S32PacketConfirmTransaction;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.common.util.BlockSnapshot;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent;
import xyz.yourboykyle.secretroutes.Main;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.events.PacketEvent;
import xyz.yourboykyle.secretroutes.events.OnBlockBreak;
import xyz.yourboykyle.secretroutes.events.OnBlockPlace;
import xyz.yourboykyle.secretroutes.events.OnItemPickedUp;
import xyz.yourboykyle.secretroutes.utils.ChatUtils;
import xyz.yourboykyle.secretroutes.utils.LogUtils;

public class OnRecievePacket {
    public static boolean firstBlockBreakPacket = true;
    public static boolean firstBlockPlacePacket = true;

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @SubscribeEvent
    public void onRecievePacket(PacketEvent.ReceiveEvent e) {
        try {
            if (e.packet instanceof S0DPacketCollectItem) {
                S0DPacketCollectItem packet = (S0DPacketCollectItem)e.packet;
                Entity entity = Minecraft.func_71410_x().field_71441_e.func_73045_a(packet.func_149354_c());
                if (!(entity instanceof EntityItem)) return;
                EntityItem item = (EntityItem)entity;
                entity = Minecraft.func_71410_x().field_71441_e.func_73045_a(packet.func_149353_d());
                if (entity == null) {
                    LogUtils.info("Entity is null");
                    return;
                }
                if (!entity.func_174793_f().func_70005_c_().equals(Minecraft.func_71410_x().field_71439_g.func_70005_c_())) {
                    return;
                }
                PlayerEvent.ItemPickupEvent itemPickupEvent = new PlayerEvent.ItemPickupEvent((EntityPlayer)Minecraft.func_71410_x().field_71439_g, item);
                new OnItemPickedUp().onPickupItem(itemPickupEvent);
                return;
            }
            if (e.packet instanceof S23PacketBlockChange) {
                WorldClient world = Minecraft.func_71410_x().field_71441_e;
                S23PacketBlockChange packet = (S23PacketBlockChange)e.packet;
                BlockPos pos = packet.func_179827_b();
                IBlockState blockState = world.func_180495_p(pos);
                Block block = blockState.func_177230_c();
                if (block == Blocks.field_150350_a) {
                    if (Main.routeRecording.recording && firstBlockBreakPacket) {
                        new OnBlockBreak().onBlockBreak(new BlockEvent.BreakEvent((World)world, pos, blockState, (EntityPlayer)Minecraft.func_71410_x().field_71439_g));
                    }
                } else if (block != null && Main.routeRecording.recording && firstBlockPlacePacket) {
                    IBlockState placedAgainst = world.func_180495_p(new BlockPos(pos.func_177958_n() + 1, pos.func_177956_o(), pos.func_177952_p()));
                    new OnBlockPlace().onBlockPlace(new BlockEvent.PlaceEvent(new BlockSnapshot((World)world, pos, blockState), placedAgainst, (EntityPlayer)Minecraft.func_71410_x().field_71439_g));
                }
                firstBlockBreakPacket = !firstBlockBreakPacket;
                firstBlockPlacePacket = !firstBlockPlacePacket;
                return;
            }
            if (!(e.packet instanceof S32PacketConfirmTransaction)) return;
        }
        catch (Exception error) {
            LogUtils.error(error);
            ChatUtils.sendChatMessage("There was an error with the secretroutesmod mod.");
        }
    }
}

