/*
 * Decompiled with CFR 0.152.
 */
package xyz.yourboykyle.secretroutes.events;

import java.util.ArrayList;
import xyz.yourboykyle.secretroutes.Main;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.dungeons.catacombs.DungeonManager;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.dungeons.catacombs.RoomDetection;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.utils.Utils;
import xyz.yourboykyle.secretroutes.utils.LogUtils;
import xyz.yourboykyle.secretroutes.utils.Room;
import xyz.yourboykyle.secretroutes.utils.SecretUtils;

public class OnEnterNewRoom {
    public static void onEnterNewRoom(Room room) {
        try {
            Utils.checkForCatacombs();
            if (!Utils.inCatacombs || DungeonManager.gameStage != 2) {
                return;
            }
            LogUtils.info("Entered new room \"" + RoomDetection.roomName + "\".");
            LogUtils.info("Room direction: \"" + RoomDetection.roomDirection);
            Main.currentRoom = room;
            SecretUtils.secrets = null;
            SecretUtils.secretLocations = new ArrayList();
            SecretUtils.resetValues();
        }
        catch (Exception e) {
            LogUtils.error(e);
        }
    }
}

