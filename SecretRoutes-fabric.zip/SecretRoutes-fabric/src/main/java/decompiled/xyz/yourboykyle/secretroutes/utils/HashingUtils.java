/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 */
package xyz.yourboykyle.secretroutes.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import xyz.yourboykyle.secretroutes.utils.LogUtils;

public class HashingUtils {
    private static UUID hashedUUID = null;

    public static UUID getHashedUUID() {
        if (hashedUUID == null) {
            try {
                hashedUUID = HashingUtils.bytesToUUID(HashingUtils.computeSHA256(HashingUtils.uuidToBytes(Minecraft.func_71410_x().field_71439_g.func_110124_au())));
            }
            catch (NoSuchAlgorithmException e) {
                LogUtils.error(e);
            }
            catch (NullPointerException e) {
                LogUtils.info("HOW ??????");
                LogUtils.error(e);
            }
        }
        return hashedUUID;
    }

    private static byte[] uuidToBytes(UUID uuid) {
        long msb = uuid.getMostSignificantBits();
        long lsb = uuid.getLeastSignificantBits();
        byte[] uuidBytes = new byte[16];
        for (int i = 0; i < 8; ++i) {
            uuidBytes[i] = (byte)(msb >>> 8 * (7 - i));
            uuidBytes[8 + i] = (byte)(lsb >>> 8 * (7 - i));
        }
        return uuidBytes;
    }

    private static byte[] computeSHA256(byte[] input) throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        return digest.digest(input);
    }

    private static UUID bytesToUUID(byte[] bytes) {
        long msb = 0L;
        long lsb = 0L;
        for (int i = 0; i < 8; ++i) {
            msb = msb << 8 | (long)(bytes[i] & 0xFF);
            lsb = lsb << 8 | (long)(bytes[8 + i] & 0xFF);
        }
        return new UUID(msb, lsb);
    }
}

