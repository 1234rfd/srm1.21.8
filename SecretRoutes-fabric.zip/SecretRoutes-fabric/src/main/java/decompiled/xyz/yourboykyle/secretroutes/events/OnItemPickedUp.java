/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.BlockPos
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 *  net.minecraftforge.fml.common.gameevent.PlayerEvent$ItemPickupEvent
 */
package xyz.yourboykyle.secretroutes.events;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.minecraft.util.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent;
import xyz.yourboykyle.secretroutes.Main;
import xyz.yourboykyle.secretroutes.config.SRMConfig;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.utils.Utils;
import xyz.yourboykyle.secretroutes.utils.BlockUtils;
import xyz.yourboykyle.secretroutes.utils.LogUtils;
import xyz.yourboykyle.secretroutes.utils.Room;
import xyz.yourboykyle.secretroutes.utils.SecretSounds;
import xyz.yourboykyle.secretroutes.utils.SecretUtils;

public class OnItemPickedUp {
    public static boolean itemSecretOnCooldown = false;
    public static final String[] validItems = new String[]{"Decoy", "Defuse Kit", "Dungeon Chest Key", "Healing VIII", "Inflatable Jerry", "Spirit Leap", "Training Weights", "Trap", "Treasure Talisman"};

    @SubscribeEvent
    public void onPickupItem(PlayerEvent.ItemPickupEvent e) {
        Utils.checkForCatacombs();
        if (!Utils.inCatacombs) {
            return;
        }
        if (!OnItemPickedUp.isSecretItem(e.pickedUp.func_92059_d().func_82833_r())) {
            return;
        }
        if (SRMConfig.allSecrets) {
            if (SecretUtils.secrets == null) {
                return;
            }
            for (JsonElement obj : SecretUtils.secrets) {
                try {
                    JsonObject secret = obj.getAsJsonObject();
                    if (!secret.get("category").getAsString().equals("category")) {
                        return;
                    }
                    int x = secret.get("x").getAsInt();
                    int y = secret.get("y").getAsInt();
                    int z = secret.get("z").getAsInt();
                    BlockPos pos = e.player.func_180425_c();
                    if (pos.func_177958_n() < x - 10 || pos.func_177958_n() > x + 10 || pos.func_177956_o() < y - 10 || pos.func_177956_o() > y + 10 || pos.func_177952_p() < z - 10 || pos.func_177952_p() > z + 10 || SecretUtils.secretLocations.contains(BlockUtils.blockPos(new BlockPos(x, y, z)))) continue;
                    SecretUtils.secretLocations.add(BlockUtils.blockPos(new BlockPos(x, y, z)));
                }
                catch (Exception exception) {}
            }
        }
        if (Main.currentRoom.getSecretType() == Room.SECRET_TYPES.ITEM) {
            BlockPos pos = e.player.func_180425_c();
            BlockPos itemPos = Main.currentRoom.getSecretLocation();
            if (pos.func_177958_n() >= itemPos.func_177958_n() - 10 && pos.func_177958_n() <= itemPos.func_177958_n() + 10 && pos.func_177956_o() >= itemPos.func_177956_o() - 10 && pos.func_177956_o() <= itemPos.func_177956_o() + 10 && pos.func_177952_p() >= itemPos.func_177952_p() - 10 && pos.func_177952_p() <= itemPos.func_177952_p() + 10) {
                Main.currentRoom.nextSecret();
                SecretSounds.secretChime();
                LogUtils.info("Picked up item at " + itemPos);
            }
        }
        if (Main.routeRecording.recording) {
            String itemName = e.pickedUp.func_92059_d().func_82833_r();
            if (!itemSecretOnCooldown && OnItemPickedUp.isSecretItem(itemName)) {
                Main.routeRecording.addWaypoint(Room.SECRET_TYPES.ITEM, e.player.func_180425_c());
                Main.routeRecording.newSecret();
                Main.routeRecording.setRecordingMessage("Added item secret waypoint.");
            }
        }
    }

    public static boolean isSecretItem(String itemName) {
        for (String item : validItems) {
            if (!itemName.contains(item)) continue;
            return true;
        }
        return false;
    }
}

