/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  cc.polyfrost.oneconfig.config.core.OneColor
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.Tuple
 *  net.minecraftforge.client.event.RenderWorldLastEvent
 */
package xyz.yourboykyle.secretroutes.utils;

import cc.polyfrost.oneconfig.config.core.OneColor;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.BlockPos;
import net.minecraft.util.Tuple;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import xyz.yourboykyle.secretroutes.Main;
import xyz.yourboykyle.secretroutes.config.SRMConfig;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.dungeons.catacombs.RoomDetection;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.utils.MapUtils;
import xyz.yourboykyle.secretroutes.utils.BlockUtils;
import xyz.yourboykyle.secretroutes.utils.ChatUtils;
import xyz.yourboykyle.secretroutes.utils.LogUtils;
import xyz.yourboykyle.secretroutes.utils.PrintingUtils;
import xyz.yourboykyle.secretroutes.utils.RenderUtils;
import xyz.yourboykyle.secretroutes.utils.RotationUtils;
import xyz.yourboykyle.secretroutes.utils.SecretRoutesRenderUtils;
import xyz.yourboykyle.secretroutes.utils.multistorage.Triple;

public class SecretUtils {
    public static JsonArray secrets = null;
    public static boolean renderLever = false;
    public static PrintingUtils xPrinter = new PrintingUtils();
    public static PrintingUtils yPrinter = new PrintingUtils();
    public static PrintingUtils zPrinter = new PrintingUtils();
    public static BlockPos currentLeverPos = null;
    public static BlockPos lastInteract;
    public static Long removeBannerTime;
    public static boolean first;
    public static String chestName;
    public static String leverName;
    public static String leverNumber;
    public static ArrayList<String> secretLocations;

    public static void renderingCallback(JsonObject currentSecretWaypoints, RenderWorldLastEvent event, int index2) {
        JsonObject waypoints;
        BlockPos pos;
        BlockPos nextSecret;
        ArrayList<BlockPos> etherwarpPositions = new ArrayList<BlockPos>();
        ArrayList<BlockPos> minesPositions = new ArrayList<BlockPos>();
        ArrayList<BlockPos> interactsPositions = new ArrayList<BlockPos>();
        ArrayList<BlockPos> superboomsPositions = new ArrayList<BlockPos>();
        ArrayList<Triple<Double, Double, Double>> enderpearlPositons = new ArrayList<Triple<Double, Double, Double>>();
        ArrayList<Tuple> enderpearlAngles = new ArrayList<Tuple>();
        GlStateManager.func_179097_i();
        GlStateManager.func_179129_p();
        if (SRMConfig.playerWaypointLine && (nextSecret = Main.currentRoom.getSecretLocation()) != null) {
            RenderUtils.drawFromPlayer(Minecraft.func_71410_x().field_71439_g, nextSecret.func_177958_n(), nextSecret.func_177956_o(), nextSecret.func_177952_p(), SRMConfig.lineColor, event.partialTicks, SRMConfig.width);
        }
        if (currentSecretWaypoints != null && currentSecretWaypoints.get("etherwarps") != null && (!SRMConfig.wholeRoute || SRMConfig.allSteps || index2 == Main.currentRoom.currentSecretIndex) && SRMConfig.renderEtherwarps) {
            JsonArray etherwarpLocations = currentSecretWaypoints.get("etherwarps").getAsJsonArray();
            for (JsonElement etherwarpLocationElement : etherwarpLocations) {
                JsonArray etherwarpLocation = etherwarpLocationElement.getAsJsonArray();
                Main.checkRoomData();
                pos = MapUtils.relativeToActual(new BlockPos(etherwarpLocation.get(0).getAsInt(), etherwarpLocation.get(1).getAsInt(), etherwarpLocation.get(2).getAsInt()), RoomDetection.roomDirection, RoomDetection.roomCorner);
                if (!SRMConfig.wholeRoute && etherwarpLocations.get(0) == etherwarpLocationElement && SRMConfig.playerToEtherwarp) {
                    EntityPlayerSP player = Minecraft.func_71410_x().field_71439_g;
                    RenderUtils.drawFromPlayer(player, pos, new OneColor(0, 255, 255), event.partialTicks, 1);
                }
                etherwarpPositions.add(pos);
                if (SRMConfig.etherwarpFullBlock) {
                    SecretRoutesRenderUtils.drawFilledBoxAtBlock((double)pos.func_177958_n(), (double)pos.func_177956_o(), (double)pos.func_177952_p(), SRMConfig.etherWarp, 1, 1);
                    continue;
                }
                SecretRoutesRenderUtils.drawBoxAtBlock((double)pos.func_177958_n(), (double)pos.func_177956_o(), (double)pos.func_177952_p(), SRMConfig.etherWarp, 1, 1);
            }
        }
        if (currentSecretWaypoints != null && currentSecretWaypoints.get("mines") != null && (!SRMConfig.wholeRoute || SRMConfig.allSteps || index2 == Main.currentRoom.currentSecretIndex) && SRMConfig.renderMines) {
            JsonArray mineLocations = currentSecretWaypoints.get("mines").getAsJsonArray();
            for (JsonElement mineLocationElement : mineLocations) {
                JsonArray mineLocation = mineLocationElement.getAsJsonArray();
                Main.checkRoomData();
                pos = MapUtils.relativeToActual(new BlockPos(mineLocation.get(0).getAsInt(), mineLocation.get(1).getAsInt(), mineLocation.get(2).getAsInt()), RoomDetection.roomDirection, RoomDetection.roomCorner);
                minesPositions.add(pos);
                if (SRMConfig.mineFullBlock) {
                    SecretRoutesRenderUtils.drawFilledBoxAtBlock((double)pos.func_177958_n(), (double)pos.func_177956_o(), (double)pos.func_177952_p(), SRMConfig.mine, 1, 1);
                    continue;
                }
                SecretRoutesRenderUtils.drawBoxAtBlock((double)pos.func_177958_n(), (double)pos.func_177956_o(), (double)pos.func_177952_p(), SRMConfig.mine, 1, 1);
            }
        }
        if (currentSecretWaypoints != null && currentSecretWaypoints.get("interacts") != null && (!SRMConfig.wholeRoute || SRMConfig.allSteps || index2 == Main.currentRoom.currentSecretIndex) && SRMConfig.renderInteracts) {
            JsonArray interactLocations = currentSecretWaypoints.get("interacts").getAsJsonArray();
            for (JsonElement interactLocationElement : interactLocations) {
                JsonArray interactLocation = interactLocationElement.getAsJsonArray();
                Main.checkRoomData();
                pos = MapUtils.relativeToActual(new BlockPos(interactLocation.get(0).getAsInt(), interactLocation.get(1).getAsInt(), interactLocation.get(2).getAsInt()), RoomDetection.roomDirection, RoomDetection.roomCorner);
                interactsPositions.add(pos);
                if (SRMConfig.interactsFullBlock) {
                    SecretRoutesRenderUtils.drawFilledBoxAtBlock((double)pos.func_177958_n(), (double)pos.func_177956_o(), (double)pos.func_177952_p(), SRMConfig.interacts, 1, 1);
                    continue;
                }
                SecretRoutesRenderUtils.drawBoxAtBlock((double)pos.func_177958_n(), (double)pos.func_177956_o(), (double)pos.func_177952_p(), SRMConfig.interacts, 1, 1);
            }
        }
        if (currentSecretWaypoints != null && currentSecretWaypoints.get("tnts") != null && (!SRMConfig.wholeRoute || SRMConfig.allSteps || index2 == Main.currentRoom.currentSecretIndex) && SRMConfig.renderSuperboom) {
            JsonArray tntLocations = currentSecretWaypoints.get("tnts").getAsJsonArray();
            for (Object tntLocationElement : tntLocations) {
                JsonArray tntLocation = ((JsonElement)tntLocationElement).getAsJsonArray();
                Main.checkRoomData();
                pos = MapUtils.relativeToActual(new BlockPos(tntLocation.get(0).getAsInt(), tntLocation.get(1).getAsInt(), tntLocation.get(2).getAsInt()), RoomDetection.roomDirection, RoomDetection.roomCorner);
                superboomsPositions.add(pos);
                if (SRMConfig.superboomsFullBlock) {
                    SecretRoutesRenderUtils.drawFilledBoxAtBlock((double)pos.func_177958_n(), (double)pos.func_177956_o(), (double)pos.func_177952_p(), SRMConfig.superbooms, 1, 1);
                    continue;
                }
                SecretRoutesRenderUtils.drawBoxAtBlock((double)pos.func_177958_n(), (double)pos.func_177956_o(), (double)pos.func_177952_p(), SRMConfig.superbooms, 1, 1);
            }
        }
        if (currentSecretWaypoints != null && currentSecretWaypoints.get("locations") != null && SRMConfig.lineType == 1 && (!SRMConfig.wholeRoute || SRMConfig.allSteps || index2 == Main.currentRoom.currentSecretIndex)) {
            Object tntLocationElement;
            GlStateManager.func_179126_j();
            LinkedList<Triple<Double, Double, Double>> lines = new LinkedList<Triple<Double, Double, Double>>();
            JsonArray lineLocations = currentSecretWaypoints.get("locations").getAsJsonArray();
            tntLocationElement = lineLocations.iterator();
            while (tntLocationElement.hasNext()) {
                JsonElement lineLocationElement = (JsonElement)tntLocationElement.next();
                JsonArray lineLocation = lineLocationElement.getAsJsonArray();
                Main.checkRoomData();
                Triple<Double, Double, Double> linePos = MapUtils.relativeToActual(lineLocation.get(0).getAsDouble(), lineLocation.get(1).getAsDouble(), lineLocation.get(2).getAsDouble(), RoomDetection.roomDirection, RoomDetection.roomCorner);
                linePos.setOne((Double)linePos.getOne() + 0.5);
                linePos.setTwo((Double)linePos.getTwo() + 0.5);
                linePos.setThree(linePos.getThree() + 0.5);
                lines.add(linePos);
            }
            if (SRMConfig.modEnabled) {
                RenderUtils.drawMultipleNormalLines(lines, event.partialTicks, SRMConfig.lineColor, SRMConfig.width);
            }
            GlStateManager.func_179097_i();
        }
        if (currentSecretWaypoints != null && currentSecretWaypoints.get("enderpearls") != null && (!SRMConfig.wholeRoute || SRMConfig.allSteps || index2 == Main.currentRoom.currentSecretIndex) && SRMConfig.renderEnderpearls) {
            JsonArray enderpearlAnglesArray = currentSecretWaypoints.get("enderpearlangles").getAsJsonArray();
            for (JsonElement pearlAngleElement : enderpearlAnglesArray) {
                JsonArray pearlAngle = pearlAngleElement.getAsJsonArray();
                Main.checkRoomData();
                enderpearlAngles.add(new Tuple((Object)Float.valueOf(pearlAngle.get(0).getAsFloat()), (Object)Float.valueOf(pearlAngle.get(1).getAsFloat())));
            }
            JsonArray pearlLocations = currentSecretWaypoints.get("enderpearls").getAsJsonArray();
            int index = 0;
            for (Object pearlLocationElement : pearlLocations) {
                JsonArray pearlLocation = ((JsonElement)pearlLocationElement).getAsJsonArray();
                Main.checkRoomData();
                double d = pearlLocation.get(0).getAsDouble();
                double posY = pearlLocation.get(1).getAsDouble();
                double posZ = pearlLocation.get(2).getAsDouble();
                Triple<Double, Double, Double> positions = MapUtils.relativeToActual(d, posY, posZ, RoomDetection.roomDirection, RoomDetection.roomCorner);
                d = (Double)positions.getOne() - 0.25;
                posY = (Double)positions.getTwo();
                posZ = positions.getThree() - 0.25;
                if (SRMConfig.enderpearlFullBlock) {
                    SecretRoutesRenderUtils.drawFilledBoxAtBlock(d, posY, posZ, SRMConfig.enderpearls, 0.5f, 0.0f);
                } else {
                    SecretRoutesRenderUtils.drawBoxAtBlock(d, posY, posZ, SRMConfig.enderpearls, 0.5, 0.0);
                }
                double yaw = RotationUtils.relativeToActualYaw(((Float)((Tuple)enderpearlAngles.get(index)).func_76340_b()).floatValue(), RoomDetection.roomDirection);
                double pitch = ((Float)((Tuple)enderpearlAngles.get(index)).func_76341_a()).floatValue();
                double yawRadians = Math.toRadians(yaw);
                double pitchRadians = Math.toRadians(pitch);
                double length = 10.0;
                double x = -Math.sin(yawRadians) * Math.cos(pitchRadians);
                double y = -Math.sin(pitchRadians);
                double z = Math.cos(yawRadians) * Math.cos(pitchRadians);
                double sideLength = Math.sqrt(x * x + y * y + z * z);
                double newX = d + (x /= sideLength) * length + 0.25;
                double newY = posY + (y /= sideLength) * length + 1.62;
                double newZ = posZ + (z /= sideLength) * length + 0.25;
                RenderUtils.drawNormalLine(d + 0.25, posY + (double)1.62f, posZ + 0.25, newX, newY, newZ, SRMConfig.pearlLineColor, event.partialTicks, true, SRMConfig.pearlLineWidth);
                enderpearlPositons.add(new Triple<Double, Double, Double>(d, posY, posZ));
                ++index;
            }
        }
        if (currentSecretWaypoints != null && currentSecretWaypoints.get("secret") != null) {
            String text;
            JsonObject secret = currentSecretWaypoints.get("secret").getAsJsonObject();
            String type = secret.get("type").getAsString();
            JsonArray location = secret.get("location").getAsJsonArray();
            Main.checkRoomData();
            BlockPos pos2 = MapUtils.relativeToActual(new BlockPos(location.get(0).getAsInt(), location.get(1).getAsInt(), location.get(2).getAsInt()), RoomDetection.roomDirection, RoomDetection.roomCorner);
            GlStateManager.func_179090_x();
            switch (type) {
                case "interact": {
                    if (!SRMConfig.renderSecretIteract) break;
                    if (SRMConfig.secretsInteractFullBlock) {
                        SecretRoutesRenderUtils.drawFilledBoxAtBlock((double)pos2.func_177958_n(), (double)pos2.func_177956_o(), (double)pos2.func_177952_p(), SRMConfig.secretsInteract, 1, 1);
                    } else {
                        SecretRoutesRenderUtils.drawBoxAtBlock((double)pos2.func_177958_n(), (double)pos2.func_177956_o(), (double)pos2.func_177952_p(), SRMConfig.secretsInteract, 1, 1);
                    }
                    if (!SRMConfig.interactTextToggle) break;
                    SecretRoutesRenderUtils.drawText(pos2.func_177958_n(), pos2.func_177956_o(), pos2.func_177952_p(), SecretRoutesRenderUtils.getTextColor(SRMConfig.interactWaypointColorIndex) + "Interact", SRMConfig.interactTextSize, event.partialTicks);
                    break;
                }
                case "item": {
                    if (!SRMConfig.renderSecretsItem) break;
                    if (SRMConfig.secretsItemFullBlock) {
                        SecretRoutesRenderUtils.drawFilledBoxAtBlock((double)pos2.func_177958_n(), (double)pos2.func_177956_o(), (double)pos2.func_177952_p(), SRMConfig.secretsItem, 1, 1);
                    } else {
                        SecretRoutesRenderUtils.drawBoxAtBlock((double)pos2.func_177958_n(), (double)pos2.func_177956_o(), (double)pos2.func_177952_p(), SRMConfig.secretsItem, 1, 1);
                    }
                    if (!SRMConfig.itemTextToggle) break;
                    SecretRoutesRenderUtils.drawText(pos2.func_177958_n(), pos2.func_177956_o(), pos2.func_177952_p(), SecretRoutesRenderUtils.getTextColor(SRMConfig.itemWaypointColorIndex) + "Item", SRMConfig.itemTextSize, event.partialTicks);
                    break;
                }
                case "bat": {
                    if (!SRMConfig.renderSecretBat) break;
                    if (SRMConfig.secretsBatFullBlock) {
                        SecretRoutesRenderUtils.drawFilledBoxAtBlock((double)pos2.func_177958_n(), (double)pos2.func_177956_o(), (double)pos2.func_177952_p(), SRMConfig.secretsBat, 1, 1);
                    } else {
                        SecretRoutesRenderUtils.drawBoxAtBlock((double)pos2.func_177958_n(), (double)pos2.func_177956_o(), (double)pos2.func_177952_p(), SRMConfig.secretsBat, 1, 1);
                    }
                    if (!SRMConfig.batTextToggle) break;
                    SecretRoutesRenderUtils.drawText(pos2.func_177958_n(), pos2.func_177956_o(), pos2.func_177952_p(), SecretRoutesRenderUtils.getTextColor(SRMConfig.batWaypointColorIndex) + "Bat", SRMConfig.batTextSize, event.partialTicks);
                }
            }
            if (SRMConfig.etherwarpsTextToggle) {
                int iEtherwarp = 1;
                for (BlockPos blockPos : etherwarpPositions) {
                    text = SRMConfig.etherwarpsEnumToggle ? "etherwarp" : "etherwarp " + iEtherwarp++;
                    SecretRoutesRenderUtils.drawText(blockPos.func_177958_n(), blockPos.func_177956_o(), blockPos.func_177952_p(), SecretRoutesRenderUtils.getTextColor(SRMConfig.etherwarpsWaypointColorIndex) + text, SRMConfig.etherwarpsTextSize, event.partialTicks);
                }
            }
            if (SRMConfig.minesTextToggle) {
                int iMine = 1;
                for (BlockPos blockPos : minesPositions) {
                    text = SRMConfig.minesEnumToggle ? "mine" : "mine " + iMine++;
                    SecretRoutesRenderUtils.drawText(blockPos.func_177958_n(), blockPos.func_177956_o(), blockPos.func_177952_p(), SecretRoutesRenderUtils.getTextColor(SRMConfig.minesWaypointColorIndex) + text, SRMConfig.minesTextSize, event.partialTicks);
                }
            }
            if (SRMConfig.interactsTextToggle) {
                int iInteract = 1;
                for (BlockPos blockPos : interactsPositions) {
                    text = SRMConfig.interactsEnumToggle ? "interact" : "interact " + iInteract;
                    SecretRoutesRenderUtils.drawText(blockPos.func_177958_n(), blockPos.func_177956_o(), blockPos.func_177952_p(), SecretRoutesRenderUtils.getTextColor(SRMConfig.interactsWaypointColorIndex) + text, SRMConfig.interactsTextSize, event.partialTicks);
                }
            }
            if (SRMConfig.superboomsTextToggle) {
                int iSuperboom = 1;
                for (BlockPos blockPos : superboomsPositions) {
                    text = SRMConfig.superboomsEnumToggle ? "superboom" : "superboom " + iSuperboom++;
                    SecretRoutesRenderUtils.drawText(blockPos.func_177958_n(), blockPos.func_177956_o(), blockPos.func_177952_p(), SecretRoutesRenderUtils.getTextColor(SRMConfig.superboomsWaypointColorIndex) + text, SRMConfig.superboomsTextSize, event.partialTicks);
                }
            }
            if (SRMConfig.enderpearlTextToggle) {
                int iEnderpearl = 1;
                for (Triple triple : enderpearlPositons) {
                    text = SRMConfig.enderpearlEnumToggle ? "ender pearl" : "ender pearl " + iEnderpearl++;
                    SecretRoutesRenderUtils.drawText((Double)triple.getOne(), (Double)triple.getTwo(), (Double)triple.getThree(), SecretRoutesRenderUtils.getTextColor(SRMConfig.enderpearlWaypointColorIndex) + text, SRMConfig.enderpearlTextSize, event.partialTicks);
                }
            }
            GlStateManager.func_179098_w();
        }
        if ((waypoints = currentSecretWaypoints) != null && waypoints.get("locations") != null && waypoints.get("locations").getAsJsonArray().size() > 0 && waypoints.get("locations").getAsJsonArray().get(0) != null) {
            if (index2 == 0) {
                JsonArray startCoords = currentSecretWaypoints.get("locations").getAsJsonArray().get(0).getAsJsonArray();
                Main.checkRoomData();
                BlockPos pos3 = MapUtils.relativeToActual(new BlockPos(startCoords.get(0).getAsInt(), startCoords.get(1).getAsInt(), startCoords.get(2).getAsInt()), RoomDetection.roomDirection, RoomDetection.roomCorner);
                if (SRMConfig.startTextToggle) {
                    SecretRoutesRenderUtils.drawText(pos3.func_177958_n(), pos3.func_177956_o(), pos3.func_177952_p(), SecretRoutesRenderUtils.getTextColor(SRMConfig.startWaypointColorIndex) + "Start", SRMConfig.startTextSize, event.partialTicks);
                }
            }
            if (index2 == Main.currentRoom.currentSecretRoute.getAsJsonArray().size() - 1) {
                JsonObject secret = currentSecretWaypoints.get("secret").getAsJsonObject();
                String type = secret.get("type").getAsString();
                JsonArray location = secret.get("location").getAsJsonArray();
                Main.checkRoomData();
                BlockPos pos4 = MapUtils.relativeToActual(new BlockPos(location.get(0).getAsInt(), location.get(1).getAsInt(), location.get(2).getAsInt()), RoomDetection.roomDirection, RoomDetection.roomCorner);
                if (SRMConfig.exitTextToggle && type.equals("exitroute")) {
                    SecretRoutesRenderUtils.drawText(pos4.func_177958_n(), pos4.func_177956_o(), pos4.func_177952_p(), SecretRoutesRenderUtils.getTextColor(SRMConfig.exitWaypointColorIndex) + "Exit", SRMConfig.exitTextSize, event.partialTicks);
                }
            }
        }
        GlStateManager.func_179089_o();
        GlStateManager.func_179126_j();
    }

    public static void renderSecrets(RenderWorldLastEvent event) {
        secrets = SecretUtils.getSecrets();
        if (secrets != null) {
            for (JsonElement secret : secrets) {
                JsonObject secretInfos = secret.getAsJsonObject();
                String name = secretInfos.get("secretName").getAsString();
                String type = secretInfos.get("category").getAsString();
                if (!name.contains("Chest") && !name.contains("Bat") && !name.contains("Wither Essence") && !name.contains("Lever") && !name.contains("Item")) continue;
                int xPos = secretInfos.get("x").getAsInt();
                int yPos = secretInfos.get("y").getAsInt();
                int zPos = secretInfos.get("z").getAsInt();
                Main.checkRoomData();
                Triple<Double, Double, Double> abs = MapUtils.relativeToActual(xPos, yPos, zPos, RoomDetection.roomDirection, RoomDetection.roomCorner);
                OneColor color = new OneColor(255, 255, 255);
                if (secretLocations.contains(BlockUtils.blockPos(new BlockPos(xPos, yPos, zPos)))) continue;
                if (name.contains("Chest") || name.contains("Wither Essence")) {
                    color = SRMConfig.secretsInteract;
                    if (SRMConfig.interactTextToggle) {
                        SecretRoutesRenderUtils.drawText((Double)abs.getOne(), (Double)abs.getTwo(), abs.getThree(), SecretRoutesRenderUtils.getTextColor(SRMConfig.interactWaypointColorIndex) + "Interact", SRMConfig.interactTextSize, event.partialTicks);
                    }
                } else if (name.contains("Bat")) {
                    color = SRMConfig.secretsBat;
                    if (SRMConfig.batTextToggle) {
                        SecretRoutesRenderUtils.drawText((Double)abs.getOne(), (Double)abs.getTwo(), abs.getThree(), SecretRoutesRenderUtils.getTextColor(SRMConfig.batWaypointColorIndex) + "Bat", SRMConfig.batTextSize, event.partialTicks);
                    }
                } else if (name.contains("Lever")) {
                    color = SRMConfig.interacts;
                    if (SRMConfig.interactsTextToggle) {
                        SecretRoutesRenderUtils.drawText((Double)abs.getOne(), (Double)abs.getTwo(), abs.getThree(), SecretRoutesRenderUtils.getTextColor(SRMConfig.interactsWaypointColorIndex) + "Interact", SRMConfig.interactsTextSize, event.partialTicks);
                    }
                } else if (name.contains("Item")) {
                    color = SRMConfig.secretsItem;
                    if (SRMConfig.itemTextToggle) {
                        SecretRoutesRenderUtils.drawText((Double)abs.getOne(), (Double)abs.getTwo(), abs.getThree(), SecretRoutesRenderUtils.getTextColor(SRMConfig.itemWaypointColorIndex) + "Item", SRMConfig.itemTextSize, event.partialTicks);
                    }
                }
                SecretRoutesRenderUtils.drawBoxAtBlock((Double)abs.getOne(), (Double)abs.getTwo(), abs.getThree(), color, 1, 1, 1);
            }
        }
    }

    public static void renderLever(RenderWorldLastEvent e) {
        String name;
        JsonObject secretInfos;
        ArrayList<JsonElement> levers = new ArrayList<JsonElement>();
        JsonArray csr = SecretUtils.getSecrets();
        String leverNum = null;
        if (csr == null) {
            renderLever = false;
        }
        if (currentLeverPos == null && csr != null) {
            for (JsonElement secret : csr) {
                String[] nums;
                int z;
                int y;
                int x;
                Triple<Double, Double, Double> abs2;
                BlockPos pos;
                secretInfos = secret.getAsJsonObject();
                name = secretInfos.get("secretName").getAsString();
                String category = secretInfos.get("category").getAsString();
                if (category.equals("chest") && leverNum == null && BlockUtils.blockPos(pos = new BlockPos(((Double)(abs2 = MapUtils.relativeToActual(x = secretInfos.get("x").getAsInt(), y = secretInfos.get("y").getAsInt(), z = secretInfos.get("z").getAsInt(), RoomDetection.roomDirection, RoomDetection.roomCorner)).getOne()).doubleValue(), ((Double)abs2.getTwo()).doubleValue(), abs2.getThree().doubleValue())).equals(BlockUtils.blockPos(lastInteract))) {
                    leverNumber = leverNum = name.split(" ")[0];
                    chestName = name;
                }
                if (!category.equals("lever")) continue;
                if (leverNum == null) {
                    levers.add(secret);
                    continue;
                }
                String[] stringArray = nums = leverNum.split("/");
                int n = stringArray.length;
                for (int abs2 = 0; abs2 < n; ++abs2) {
                    String num = stringArray[abs2];
                    if (!name.contains(num)) continue;
                    currentLeverPos = new BlockPos(secretInfos.get("x").getAsInt(), secretInfos.get("y").getAsInt(), secretInfos.get("z").getAsInt());
                    leverName = name;
                }
            }
        }
        if (currentLeverPos != null || !levers.isEmpty()) {
            if (currentLeverPos == null && leverNum != null) {
                for (JsonElement secret : levers) {
                    String[] nums;
                    secretInfos = secret.getAsJsonObject();
                    name = secretInfos.get("secretName").getAsString();
                    for (String num : nums = leverNum.split("/")) {
                        if (!name.contains(num)) continue;
                        currentLeverPos = new BlockPos(secretInfos.get("x").getAsInt(), secretInfos.get("y").getAsInt(), secretInfos.get("z").getAsInt());
                        leverName = name;
                    }
                }
            }
            if (currentLeverPos == null) {
                ChatUtils.sendChatMessage("\u00a7cLever not found :(");
            } else {
                Triple<Double, Double, Double> abs = MapUtils.relativeToActual(currentLeverPos.func_177958_n(), currentLeverPos.func_177956_o(), currentLeverPos.func_177952_p(), RoomDetection.roomDirection, RoomDetection.roomCorner);
                if (SRMConfig.secretsInteractFullBlock) {
                    SecretRoutesRenderUtils.drawFilledBoxAtBlock((Double)abs.getOne(), (Double)abs.getTwo(), abs.getThree(), SRMConfig.secretsInteract, 1, 1, 1.0f);
                } else {
                    SecretRoutesRenderUtils.drawBoxAtBlock((Double)abs.getOne(), (Double)abs.getTwo(), abs.getThree(), SRMConfig.secretsInteract, 1, 1, 1);
                }
                SecretRoutesRenderUtils.drawText((Double)abs.getOne(), (Double)abs.getTwo(), abs.getThree(), SecretRoutesRenderUtils.getTextColor(SRMConfig.interactsWaypointColorIndex) + "Locked chest lever", SRMConfig.interactsTextSize, e.partialTicks);
                if (first) {
                    removeBannerTime = System.currentTimeMillis() + 5000L;
                    new Thread(() -> {
                        try {
                            Thread.sleep(5000L);
                            removeBannerTime = null;
                        }
                        catch (InterruptedException interruptedException) {
                            // empty catch block
                        }
                    }).start();
                    first = false;
                }
            }
        } else {
            ChatUtils.sendChatMessage("\u00a7cLever not found :(");
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static JsonArray getSecrets() {
        Main.checkRoomData();
        String roomName = Main.currentRoom.name;
        if (secrets != null) return secrets;
        try (InputStreamReader reader = new InputStreamReader(Main.class.getResourceAsStream("/assets/roomdetection/secretlocations.json"));){
            JsonParser parser = new JsonParser();
            JsonObject object = parser.parse(reader).getAsJsonObject();
            if (object.has(roomName)) {
                secrets = object.getAsJsonArray(roomName);
            }
            JsonArray jsonArray = secrets;
            return jsonArray;
        }
        catch (Exception e) {
            LogUtils.error(e);
            return null;
        }
    }

    public static void resetValues() {
        renderLever = false;
        currentLeverPos = null;
        removeBannerTime = null;
        first = true;
        chestName = null;
        leverName = null;
        leverNumber = null;
    }

    static {
        removeBannerTime = null;
        first = true;
        chestName = null;
        leverName = null;
        leverNumber = null;
        secretLocations = new ArrayList();
    }
}

