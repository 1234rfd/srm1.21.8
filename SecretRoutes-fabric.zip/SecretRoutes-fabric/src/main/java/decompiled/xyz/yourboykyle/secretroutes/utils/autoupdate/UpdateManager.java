/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.EnumChatFormatting
 */
package xyz.yourboykyle.secretroutes.utils.autoupdate;

import com.google.gson.JsonElement;
import java.io.IOException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import net.minecraft.util.EnumChatFormatting;
import xyz.yourboykyle.secretroutes.config.SRMConfig;
import xyz.yourboykyle.secretroutes.deps.libautoupdate.CurrentVersion;
import xyz.yourboykyle.secretroutes.deps.libautoupdate.PotentialUpdate;
import xyz.yourboykyle.secretroutes.deps.libautoupdate.UpdateContext;
import xyz.yourboykyle.secretroutes.deps.libautoupdate.UpdateSource;
import xyz.yourboykyle.secretroutes.deps.libautoupdate.UpdateTarget;
import xyz.yourboykyle.secretroutes.utils.ChatUtils;
import xyz.yourboykyle.secretroutes.utils.LogUtils;
import xyz.yourboykyle.secretroutes.utils.autoupdate.MinecraftExecutor;

public class UpdateManager {
    private static CompletableFuture<?> _activePromise = null;
    private static UpdateState updateState = UpdateState.NONE;
    private static PotentialUpdate potentialUpdate = null;
    private static final UpdateContext context = new UpdateContext(UpdateSource.githubUpdateSource("yourboykyle", "SecretRoutes"), UpdateTarget.deleteAndSaveInTheSameFolder(UpdateManager.class), new CurrentVersion(){
        private final CurrentVersion normalDelegate = CurrentVersion.ofTag("v0.4.16");

        @Override
        public String display() {
            if (SRMConfig.forceUpdateDEBUG) {
                return "Force Outdated";
            }
            return this.normalDelegate.display();
        }

        @Override
        public boolean isOlderThan(JsonElement element) {
            if (SRMConfig.forceUpdateDEBUG) {
                LogUtils.info("isOlderThan: force update!");
                return true;
            }
            return this.normalDelegate.isOlderThan(element);
        }

        public String toString() {
            return "" + this.normalDelegate;
        }
    }, "secretroutesmod");

    public static void setActivePromise(CompletableFuture<?> value) {
        if (_activePromise != null) {
            _activePromise.cancel(true);
        }
        _activePromise = value;
    }

    public static String getNextVersion() {
        return potentialUpdate != null ? potentialUpdate.getUpdate().getVersionNumber().getAsString() : null;
    }

    public void reset() {
        updateState = UpdateState.NONE;
        _activePromise = null;
        potentialUpdate = null;
        LogUtils.info("Reset update state");
    }

    public void checkUpdate(Boolean button) {
        if (updateState == UpdateState.DOWNLOADED) {
            LogUtils.info("The latest version has already been downloaded in this session. Please restart to apply the changes.");
            return;
        }
        if (updateState == UpdateState.QUEUED) {
            LogUtils.info("Trying to perform update check while another update is already in progress");
            return;
        }
        if (updateState == UpdateState.AVAILABLE) {
            LogUtils.info("This appears to be the second update check. Assuming user checking manually");
        }
        UpdateManager.setActivePromise(context.checkUpdate("full").thenAcceptAsync(update -> {
            LogUtils.info("Update check completed");
            potentialUpdate = update;
            LogUtils.info("Current version: " + context.getCurrentVersion());
            LogUtils.info("Latest version: " + update.getUpdate().getVersionNumber());
            if (this.checkVersion((PotentialUpdate)update) || SRMConfig.forceUpdateDEBUG) {
                updateState = UpdateState.AVAILABLE;
                LogUtils.info("Update available");
                ChatUtils.sendChatMessage(EnumChatFormatting.GREEN + "Secret Routes Mod found a new update: " + update.getUpdate().getVersionName());
                if (SRMConfig.autoDownload) {
                    LogUtils.info("Update available, autoUpdate is enabled");
                    ChatUtils.sendChatMessage(EnumChatFormatting.GREEN + "Automatically downloading new Secret Routes Mod update, since AutoDownload is true...");
                    this.queueUpdate();
                } else {
                    ChatUtils.sendClickableMessage(EnumChatFormatting.GREEN + "Download at https://github.com/yourboykyle/SecretRoutes/releases/latest", "https://github.com/yourboykyle/SecretRoutes/releases/latest");
                }
            } else {
                if (button.booleanValue()) {
                    ChatUtils.sendChatMessage(EnumChatFormatting.GREEN + "Secret Routes Mod is up to date!");
                }
                LogUtils.info("No update available.");
            }
        }, (Executor)MinecraftExecutor.INSTANCE));
    }

    public void queueUpdate() {
        if (updateState != UpdateState.AVAILABLE) {
            LogUtils.info("Trying to queue an update while another one is already downloaded or none is present");
            return;
        }
        updateState = UpdateState.QUEUED;
        UpdateManager.setActivePromise(CompletableFuture.supplyAsync(() -> {
            LogUtils.info("Update download started");
            try {
                potentialUpdate.prepareUpdate();
            }
            catch (IOException e) {
                LogUtils.error(e);
            }
            return null;
        }).thenAcceptAsync(aVoid -> {
            LogUtils.info("Update download completed, setting exit hook");
            updateState = UpdateState.DOWNLOADED;
            potentialUpdate.executePreparedUpdate();
            ChatUtils.sendChatMessage("\u00a7eDownload of update complete.");
            ChatUtils.sendChatMessage("\u00a7aThe update will be installed after your next restart.");
        }));
    }

    public boolean checkVersion(PotentialUpdate update) {
        String[] currentV = "0.4.16".split("\\.");
        String[] nextV = update.getUpdate().getVersionName().substring(1).split("\\.");
        for (int i = 0; i < currentV.length && i < nextV.length; ++i) {
            if (Integer.parseInt(currentV[i]) < Integer.parseInt(nextV[i])) {
                return true;
            }
            if (Integer.parseInt(currentV[i]) <= Integer.parseInt(nextV[i])) continue;
            return false;
        }
        return currentV.length < nextV.length;
    }

    static {
        context.cleanup();
    }

    public static enum UpdateState {
        AVAILABLE,
        QUEUED,
        DOWNLOADED,
        NONE;

    }
}

