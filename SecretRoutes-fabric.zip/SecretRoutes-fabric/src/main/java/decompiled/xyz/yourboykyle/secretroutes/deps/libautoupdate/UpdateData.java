/*
 * Decompiled with CFR 0.152.
 */
package xyz.yourboykyle.secretroutes.deps.libautoupdate;

import com.google.gson.JsonElement;
import java.net.MalformedURLException;
import java.net.URL;

public class UpdateData {
    String versionName;
    JsonElement versionNumber;
    String sha256;
    String download;

    public URL getDownloadAsURL() throws MalformedURLException {
        return new URL(this.download);
    }

    public String getVersionName() {
        return this.versionName;
    }

    public JsonElement getVersionNumber() {
        return this.versionNumber;
    }

    public String getSha256() {
        return this.sha256;
    }

    public String getDownload() {
        return this.download;
    }

    public void setVersionName(String versionName) {
        this.versionName = versionName;
    }

    public void setVersionNumber(JsonElement versionNumber) {
        this.versionNumber = versionNumber;
    }

    public void setSha256(String sha256) {
        this.sha256 = sha256;
    }

    public void setDownload(String download) {
        this.download = download;
    }

    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof UpdateData)) {
            return false;
        }
        UpdateData other = (UpdateData)o;
        if (!other.canEqual(this)) {
            return false;
        }
        String this$versionName = this.getVersionName();
        String other$versionName = other.getVersionName();
        if (this$versionName == null ? other$versionName != null : !this$versionName.equals(other$versionName)) {
            return false;
        }
        JsonElement this$versionNumber = this.getVersionNumber();
        JsonElement other$versionNumber = other.getVersionNumber();
        if (this$versionNumber == null ? other$versionNumber != null : !this$versionNumber.equals(other$versionNumber)) {
            return false;
        }
        String this$sha256 = this.getSha256();
        String other$sha256 = other.getSha256();
        if (this$sha256 == null ? other$sha256 != null : !this$sha256.equals(other$sha256)) {
            return false;
        }
        String this$download = this.getDownload();
        String other$download = other.getDownload();
        return !(this$download == null ? other$download != null : !this$download.equals(other$download));
    }

    protected boolean canEqual(Object other) {
        return other instanceof UpdateData;
    }

    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        String $versionName = this.getVersionName();
        result = result * 59 + ($versionName == null ? 43 : $versionName.hashCode());
        JsonElement $versionNumber = this.getVersionNumber();
        result = result * 59 + ($versionNumber == null ? 43 : $versionNumber.hashCode());
        String $sha256 = this.getSha256();
        result = result * 59 + ($sha256 == null ? 43 : $sha256.hashCode());
        String $download = this.getDownload();
        result = result * 59 + ($download == null ? 43 : $download.hashCode());
        return result;
    }

    public String toString() {
        return "UpdateData(versionName=" + this.getVersionName() + ", versionNumber=" + this.getVersionNumber() + ", sha256=" + this.getSha256() + ", download=" + this.getDownload() + ")";
    }

    public UpdateData() {
    }

    public UpdateData(String versionName, JsonElement versionNumber, String sha256, String download) {
        this.versionName = versionName;
        this.versionNumber = versionNumber;
        this.sha256 = sha256;
        this.download = download;
    }
}

