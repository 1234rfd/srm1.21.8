/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.EnumChatFormatting
 */
package xyz.yourboykyle.secretroutes.utils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.util.EnumChatFormatting;
import xyz.yourboykyle.secretroutes.Main;
import xyz.yourboykyle.secretroutes.config.SRMConfig;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.dungeons.catacombs.RoomDetection;
import xyz.yourboykyle.secretroutes.utils.ChatUtils;
import xyz.yourboykyle.secretroutes.utils.LogUtils;

public class PBUtils {
    public static JsonObject personalBests = new JsonObject();
    public static String filePath = Main.CONFIG_FOLDER_PATH + File.separator + "personal_bests.json";
    public static long startTime = System.currentTimeMillis();
    public static boolean pbIsValid = false;

    public static boolean loadPBData() {
        if (!new File(filePath).exists()) {
            ChatUtils.sendChatMessage(EnumChatFormatting.RED + "Personal bests file not found.");
            return false;
        }
        Gson gson = new GsonBuilder().create();
        FileReader reader = null;
        try {
            reader = new FileReader(filePath);
            personalBests = gson.fromJson((Reader)reader, JsonObject.class);
        }
        catch (FileNotFoundException e) {
            LogUtils.error(e);
            ChatUtils.sendChatMessage("\u00a74 THIS SHOULD NEVER HAVE HAPPENED... (ConfigUtils 123)");
            return false;
        }
        return true;
    }

    public static void setPersonalBest(String roomName, long timeInMs) {
        if (!SRMConfig.trackPersonalBests) {
            return;
        }
        personalBests.addProperty(roomName, PBUtils.formatTime(timeInMs));
        PBUtils.writePBData();
    }

    public static void removePersonalBest(String roomName) {
        if (!SRMConfig.trackPersonalBests) {
            return;
        }
        if (personalBests.has(roomName)) {
            personalBests.remove(roomName);
            PBUtils.writePBData();
        }
    }

    public static long getPBForRoom(String roomName) {
        if (personalBests.has(roomName)) {
            String formattedTime = personalBests.get(roomName).getAsString();
            return PBUtils.parseTimeToMillis(formattedTime);
        }
        return -1L;
    }

    public static void writePBData() {
        if (!SRMConfig.trackPersonalBests) {
            return;
        }
        try (FileWriter writer = new FileWriter(filePath);){
            writer.write(personalBests.toString());
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void startRoute() {
        if (!SRMConfig.trackPersonalBests) {
            return;
        }
        startTime = System.currentTimeMillis();
    }

    public static void stopRoute() {
        if (!SRMConfig.trackPersonalBests) {
            return;
        }
        if (!pbIsValid) {
            ChatUtils.sendVerboseMessage("PB is invalid, not saving.", "Personal Bests");
            return;
        }
        long time = System.currentTimeMillis() - startTime;
        startTime = 0L;
        long pbTime = PBUtils.getPBForRoom(RoomDetection.roomName);
        ChatUtils.sendVerboseMessage("PB for " + RoomDetection.roomName + ": " + (pbTime == -1L ? "N/A" : PBUtils.formatTime(pbTime)), "Personal Bests");
        if (pbTime == -1L || time < pbTime) {
            if (SRMConfig.sendChatMessages) {
                ChatUtils.sendChatMessage("\u00a7rNew personal best for " + RoomDetection.roomName + ": \u00a7a" + PBUtils.formatTime(time));
            }
            PBUtils.setPersonalBest(RoomDetection.roomName, time);
        }
        pbIsValid = false;
        ChatUtils.sendVerboseMessage("Time for " + RoomDetection.roomName + ": \u00a7a" + PBUtils.formatTime(time), "Personal Bests");
    }

    public static String formatTime(long millis) {
        long days = millis / 86400000L;
        long hours = (millis %= 86400000L) / 3600000L;
        long minutes = (millis %= 3600000L) / 60000L;
        long seconds = (millis %= 60000L) / 1000L;
        long milliseconds = millis % 1000L;
        StringBuilder sb = new StringBuilder();
        if (days > 0L) {
            sb.append(days).append("d ");
        }
        if (hours > 0L) {
            sb.append(hours).append("h ");
        }
        if (minutes > 0L) {
            sb.append(minutes).append("m ");
        }
        if (seconds > 0L || milliseconds > 0L) {
            sb.append(seconds);
            if (milliseconds > 0L) {
                sb.append(".").append(String.format("%03d", milliseconds));
            }
            sb.append("s");
        }
        return sb.toString().trim();
    }

    public static long parseTimeToMillis(String formattedTime) {
        ChatUtils.sendVerboseMessage("Formatted PB time: " + formattedTime, "Personal Bests");
        long totalMillis = 0L;
        Pattern pattern = Pattern.compile("(\\d+)d| *(\\d+)h| *(\\d+)m| *(\\d+)\\.(\\d{1,3})?s| *(\\d+)s");
        Matcher matcher = pattern.matcher(formattedTime);
        while (matcher.find()) {
            if (matcher.group(1) != null) {
                totalMillis += Long.parseLong(matcher.group(1)) * 86400000L;
            }
            if (matcher.group(2) != null) {
                totalMillis += Long.parseLong(matcher.group(2)) * 3600000L;
            }
            if (matcher.group(3) != null) {
                totalMillis += Long.parseLong(matcher.group(3)) * 60000L;
            }
            if (matcher.group(4) != null) {
                totalMillis += Long.parseLong(matcher.group(4)) * 1000L;
                if (matcher.group(5) != null) {
                    String millisStr = matcher.group(5);
                    while (millisStr.length() < 3) {
                        millisStr = millisStr + "0";
                    }
                    totalMillis += (long)Integer.parseInt(millisStr);
                }
            }
            if (matcher.group(6) == null) continue;
            totalMillis += Long.parseLong(matcher.group(6)) * 1000L;
        }
        return totalMillis;
    }
}

