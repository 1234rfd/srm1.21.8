/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.client.event.RenderWorldLastEvent
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package xyz.yourboykyle.secretroutes.events;

import com.google.gson.JsonArray;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import xyz.yourboykyle.secretroutes.Main;
import xyz.yourboykyle.secretroutes.config.SRMConfig;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.dungeons.catacombs.DungeonManager;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.utils.Utils;
import xyz.yourboykyle.secretroutes.events.OnChatReceive;
import xyz.yourboykyle.secretroutes.utils.LogUtils;
import xyz.yourboykyle.secretroutes.utils.SecretUtils;

public class OnWorldRender {
    private static final String verboseTAG = "Rendering";
    public static boolean playCompleteFirst = true;

    @SubscribeEvent
    public void onRenderWorld(RenderWorldLastEvent event) {
        try {
            Utils.checkForCatacombs();
            if (!Utils.inCatacombs || DungeonManager.gameStage != 2 || !SRMConfig.modEnabled) {
                return;
            }
            if (OnChatReceive.isAllFound()) {
                if (!SRMConfig.renderComplete) {
                    return;
                }
            } else {
                playCompleteFirst = true;
            }
            if (SRMConfig.allSecrets) {
                SecretUtils.renderSecrets(event);
            } else if (SRMConfig.wholeRoute) {
                JsonArray csr = Main.currentRoom.currentSecretRoute;
                if (csr != null) {
                    for (int i = Main.currentRoom.currentSecretIndex; i < csr.size(); ++i) {
                        SecretUtils.renderingCallback(csr.get(i).getAsJsonObject(), event, i);
                    }
                }
            } else {
                SecretUtils.renderingCallback(Main.currentRoom.currentSecretWaypoints, event, Main.currentRoom.currentSecretIndex);
            }
            if (SecretUtils.renderLever) {
                SecretUtils.renderLever(event);
            }
        }
        catch (Exception e) {
            LogUtils.error(e);
        }
    }
}

