/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Iterables
 *  com.google.common.collect.Lists
 *  net.minecraft.client.Minecraft
 *  net.minecraft.scoreboard.Score
 *  net.minecraft.scoreboard.ScoreObjective
 *  net.minecraft.scoreboard.ScorePlayerTeam
 *  net.minecraft.scoreboard.Scoreboard
 *  net.minecraft.scoreboard.Team
 *  net.minecraft.util.StringUtils
 */
package xyz.yourboykyle.secretroutes.deps.dungeonrooms.handlers;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.client.Minecraft;
import net.minecraft.scoreboard.Score;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.Team;
import net.minecraft.util.StringUtils;

public class ScoreboardHandler {
    public static String cleanSB(String scoreboard) {
        char[] nvString = StringUtils.func_76338_a((String)scoreboard).toCharArray();
        StringBuilder cleaned = new StringBuilder();
        for (char c : nvString) {
            if (c <= '\u0014' || c >= '\u007f') continue;
            cleaned.append(c);
        }
        return cleaned.toString();
    }

    public static List<String> getSidebarLines() {
        ArrayList<String> lines = new ArrayList<String>();
        if (Minecraft.func_71410_x().field_71441_e == null) {
            return lines;
        }
        Scoreboard scoreboard = Minecraft.func_71410_x().field_71441_e.func_96441_U();
        if (scoreboard == null) {
            return lines;
        }
        ScoreObjective objective = scoreboard.func_96539_a(1);
        if (objective == null) {
            return lines;
        }
        ArrayList scores = scoreboard.func_96534_i(objective);
        ArrayList list = scores.stream().filter(input -> input != null && input.func_96653_e() != null && !input.func_96653_e().startsWith("#")).collect(Collectors.toList());
        scores = list.size() > 15 ? Lists.newArrayList((Iterable)Iterables.skip(list, (int)(scores.size() - 15))) : list;
        for (Score score : scores) {
            ScorePlayerTeam team = scoreboard.func_96509_i(score.func_96653_e());
            lines.add(ScorePlayerTeam.func_96667_a((Team)team, (String)score.func_96653_e()));
        }
        return lines;
    }
}

