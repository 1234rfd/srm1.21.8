/*
 * Decompiled with CFR 0.152.
 */
package xyz.yourboykyle.secretroutes.deps.libautoupdate;

import java.util.concurrent.CompletableFuture;
import xyz.yourboykyle.secretroutes.deps.libautoupdate.CurrentVersion;
import xyz.yourboykyle.secretroutes.deps.libautoupdate.UpdateContext;
import xyz.yourboykyle.secretroutes.deps.libautoupdate.UpdateSource;
import xyz.yourboykyle.secretroutes.deps.libautoupdate.UpdateTarget;

public class Main {
    public static void main(String[] args) {
        UpdateContext updater = new UpdateContext(UpdateSource.githubUpdateSource("hannibal002", "SkyHanni"), UpdateTarget.deleteAndSaveInTheSameFolder(Main.class), CurrentVersion.ofTag("1.1.0"), "test");
        updater.cleanup();
        System.out.println("Update cleaned");
        System.out.println("Created update context: " + updater);
        String stream = "pre";
        ((CompletableFuture)updater.checkUpdate(stream).thenCompose(it -> {
            System.out.println("Checked for update on " + stream + ": " + it);
            System.out.println("Can update: " + it.isUpdateAvailable());
            System.out.println("Executing update.");
            return it.launchUpdate();
        })).join();
    }
}

