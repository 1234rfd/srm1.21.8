/*
 * Decompiled with CFR 0.152.
 */
package xyz.yourboykyle.secretroutes.utils.multistorage;

import xyz.yourboykyle.secretroutes.utils.multistorage.Tuple;

public class Triple<X, Y, Z>
extends Tuple<X, Y> {
    private Z three;

    public Triple(X one, Y two, Z three) {
        super(one, two);
        this.three = three;
    }

    public void setThree(Z three) {
        this.three = three;
    }

    public Z getThree() {
        return this.three;
    }
}

