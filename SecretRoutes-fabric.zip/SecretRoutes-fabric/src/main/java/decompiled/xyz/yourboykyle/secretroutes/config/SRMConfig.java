/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  cc.polyfrost.oneconfig.config.Config
 *  cc.polyfrost.oneconfig.config.annotations.Button
 *  cc.polyfrost.oneconfig.config.annotations.Checkbox
 *  cc.polyfrost.oneconfig.config.annotations.Color
 *  cc.polyfrost.oneconfig.config.annotations.Dropdown
 *  cc.polyfrost.oneconfig.config.annotations.DualOption
 *  cc.polyfrost.oneconfig.config.annotations.HUD
 *  cc.polyfrost.oneconfig.config.annotations.Info
 *  cc.polyfrost.oneconfig.config.annotations.KeyBind
 *  cc.polyfrost.oneconfig.config.annotations.Number
 *  cc.polyfrost.oneconfig.config.annotations.Slider
 *  cc.polyfrost.oneconfig.config.annotations.Switch
 *  cc.polyfrost.oneconfig.config.annotations.Text
 *  cc.polyfrost.oneconfig.config.core.OneColor
 *  cc.polyfrost.oneconfig.config.core.OneKeyBind
 *  cc.polyfrost.oneconfig.config.data.InfoType
 *  cc.polyfrost.oneconfig.config.data.Mod
 *  cc.polyfrost.oneconfig.config.data.ModType
 *  cc.polyfrost.oneconfig.config.elements.BasicOption
 *  cc.polyfrost.oneconfig.config.elements.OptionCategory
 *  cc.polyfrost.oneconfig.gui.pages.ModConfigPage
 *  cc.polyfrost.oneconfig.libs.universal.UKeyboard
 *  net.minecraft.client.Minecraft
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumChatFormatting
 */
package xyz.yourboykyle.secretroutes.config;

import cc.polyfrost.oneconfig.config.Config;
import cc.polyfrost.oneconfig.config.annotations.Button;
import cc.polyfrost.oneconfig.config.annotations.Checkbox;
import cc.polyfrost.oneconfig.config.annotations.Color;
import cc.polyfrost.oneconfig.config.annotations.Dropdown;
import cc.polyfrost.oneconfig.config.annotations.DualOption;
import cc.polyfrost.oneconfig.config.annotations.HUD;
import cc.polyfrost.oneconfig.config.annotations.Info;
import cc.polyfrost.oneconfig.config.annotations.KeyBind;
import cc.polyfrost.oneconfig.config.annotations.Number;
import cc.polyfrost.oneconfig.config.annotations.Slider;
import cc.polyfrost.oneconfig.config.annotations.Switch;
import cc.polyfrost.oneconfig.config.annotations.Text;
import cc.polyfrost.oneconfig.config.core.OneColor;
import cc.polyfrost.oneconfig.config.core.OneKeyBind;
import cc.polyfrost.oneconfig.config.data.InfoType;
import cc.polyfrost.oneconfig.config.data.Mod;
import cc.polyfrost.oneconfig.config.data.ModType;
import cc.polyfrost.oneconfig.config.elements.BasicOption;
import cc.polyfrost.oneconfig.config.elements.OptionCategory;
import cc.polyfrost.oneconfig.gui.pages.ModConfigPage;
import cc.polyfrost.oneconfig.libs.universal.UKeyboard;
import java.io.File;
import net.minecraft.client.Minecraft;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumChatFormatting;
import xyz.yourboykyle.secretroutes.Main;
import xyz.yourboykyle.secretroutes.config.huds.CurrentRoomHUD;
import xyz.yourboykyle.secretroutes.config.huds.RecordingHUD;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.dungeons.catacombs.RoomDetection;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.utils.Utils;
import xyz.yourboykyle.secretroutes.utils.ChatUtils;
import xyz.yourboykyle.secretroutes.utils.ConfigUtils;
import xyz.yourboykyle.secretroutes.utils.FileUtils;
import xyz.yourboykyle.secretroutes.utils.LogUtils;
import xyz.yourboykyle.secretroutes.utils.PBUtils;
import xyz.yourboykyle.secretroutes.utils.Room;
import xyz.yourboykyle.secretroutes.utils.RouteUtils;
import xyz.yourboykyle.secretroutes.utils.SecretSounds;

public class SRMConfig
extends Config {
    @Switch(name="Render Routes", description="Main toggle", subcategory="General")
    public static boolean modEnabled = true;
    @Switch(name="Render secrets when room is completed", description="Renders secrets even if the room is completed", subcategory="General")
    public static boolean renderComplete = false;
    @Switch(name="Full route", description="Render all secrets in the route", subcategory="General")
    public static boolean wholeRoute = false;
    @Switch(name="Render steps", description="Renders the entire path to the secret instead of just the secret", subcategory="General")
    public static boolean allSteps = false;
    @Info(text="Full Route - Renders the Entire route (only secrets unless All Steps is enabled)", subcategory="General", size=2, type=InfoType.WARNING)
    public static boolean ignored;
    @Switch(name="All secrets", description="Renders all secrets in the room (DOES NOT RENDER STEPS) - NO LINES", subcategory="General")
    public static boolean allSecrets;
    @Info(text="All secrets displays all secrets, but not the route... (no lines)", subcategory="General", size=2, type=InfoType.WARNING)
    public static boolean ignored2;
    @Dropdown(name="Line Type", options={"Particles", "Lines", "None"}, subcategory="General", size=2)
    public static int lineType;
    @Dropdown(name="Particle Type", options={"Explosion Normal", "Explosion Large", "Explosion Huge", "Fireworks Spark", "Bubble", "Water Splash", "Water Wake", "Suspended", "Suspended Depth", "Crit", "Magic Crit", "Smoke Normal", "Smoke Large", "Spell", "Instant Spell", "Mob Spell", "Mob Spell Ambient", "Witch Magic", "Drip Water", "Drip Lava", "Villager Angry", "Villager Happy", "Town Aura", "Note", "Portal", "Enchantment Table", "Flame", "Lava", "Footstep", "Cloud", "Redstone", "Snowball", "Snow Shovel", "Slime", "Heart", "Barrier", "Water Drop", "Item Take", "Mob Appearance"}, subcategory="General")
    public static int particles;
    @Slider(name="Tick inverval", description="The interval between when the game renders the particles. Higher values will reduce lag, but may cause the particles to be less smooth", min=0.0f, max=20.1f, step=1, subcategory="General")
    public static int tickInterval;
    @Slider(name="Line width (not for particles)", min=1.0f, max=10.1f, step=1, subcategory="General")
    public static int width;
    @Slider(name="Line width (for ender pearls)", min=1.0f, max=10.1f, step=1, subcategory="General")
    public static int pearlLineWidth;
    @DualOption(name="Type of routes", left="No pearls", right="Pearls", description="Toggle the default between pearls and no pearls", subcategory="General", size=2)
    public static boolean pearls;
    @Text(name="Routes file name", description="The file name used when No pearls is selected", placeholder="routes.json", subcategory="General")
    public static String routesFileName;
    @Text(name="Pearl routes file name", description="The file name used when Pearls is selected", placeholder="pearlroutes.json", subcategory="General")
    public static String pearlRoutesFileName;
    @Button(name="Update routes", text="Update routes", description="Downloads the routes.json from github", subcategory="General", size=2)
    Runnable runnable = () -> new Thread(() -> {
        if (pearls) {
            RouteUtils.updatePearlRoutes();
        } else {
            RouteUtils.updateRoutes();
        }
    }).start();
    @Button(name="Import routes", text="Import routes", description="Select a routes.json file to import, this will be copied to .minecraft/config/SecretRoutes/routes.json", size=2, subcategory="General")
    Runnable runnable9 = () -> new Thread(() -> {
        try {
            File file = FileUtils.promptUserForFile();
            if (file != null) {
                FileUtils.copyFileToDirectory(file, Main.ROUTES_PATH);
            }
        }
        catch (Exception e) {
            LogUtils.error(e);
        }
    }).start();
    @Text(name="Copy file name", description="This is the name of the file to copy the routes.json in your downloads to.", subcategory="General")
    public static String copyFileName;
    @Button(name="Copy routes", text="Copy routes", description="Copies the Downloads/routes.json to the routes directory under the name specified in the Copy file name field", size=2, subcategory="General")
    Runnable runnable21 = () -> new Thread(() -> {
        try {
            FileUtils.copyFileToRoutesDirectory();
        }
        catch (Exception e) {
            LogUtils.error(e);
        }
    }).start();
    @Switch(name="Personal Best Tracking", description="Tracks your personal best time for completing the secrets in each room", subcategory="Personal Bests")
    public static boolean trackPersonalBests;
    @Switch(name="Send Chat Messages For New PBs", description="Sends chat messages when you beat your personal best", subcategory="Personal Bests")
    public static boolean sendChatMessages;
    @Button(name="Get personal best (current room)", text="Get PB", description="Gets your personal best time for the current room", subcategory="Personal Bests")
    Runnable runnable19 = () -> new Thread(() -> {
        long pb = PBUtils.getPBForRoom(RoomDetection.roomName);
        if (pb != -1L) {
            ChatUtils.sendChatMessage("Personal best for " + RoomDetection.roomName + ": " + EnumChatFormatting.GREEN + PBUtils.formatTime(pb));
        } else {
            ChatUtils.sendChatMessage(EnumChatFormatting.DARK_RED + "No personal best found for " + RoomDetection.roomName);
        }
    }).start();
    @Button(name="Reset personal best (current room)", text="Reset PB", description="Reset your personal best time for the current room", subcategory="Personal Bests")
    Runnable runnable20 = () -> new Thread(() -> {
        PBUtils.removePersonalBest(RoomDetection.roomName);
        ChatUtils.sendChatMessage("Reset personal best for " + RoomDetection.roomName);
    }).start();
    @Switch(name="Notify for new updates", description="Automatically checks for updates on startup. WILL NOT AUTO UPDATE", subcategory="Updates")
    public static boolean autoCheckUpdates;
    @Switch(name="Auto download new updates", description="Automatically downloads updates when they are available", subcategory="Updates")
    public static boolean autoDownload;
    @Button(name="Check for updates", text="Check for updates", description="Manually check for an update if you wish to make sure", subcategory="Updates", size=2)
    Runnable runnable14 = () -> new Thread(() -> {
        ChatUtils.sendChatMessage("Checking for updates, please wait a few seconds...");
        Main.updateManager.checkUpdate(true);
    }).start();
    @Switch(name="Auto update Routes", description="Automatically updates the routes.json file when it is out of date", subcategory="Updates", size=2)
    public static boolean autoUpdateRoutes;
    @Info(text="THIS WILL OVERWRITE THE FILE. MAKE SURE YOUR CUSTOM ROUTES ARE NOT NAMED ROUTES.JSON OR PEARLROUTES.JSON", subcategory="Updates", size=2, type=InfoType.WARNING)
    @Button(name="Set Bat Waypoint", text="Set Bat Waypoint", description="Since bat waypoints aren't automatically detected, sadly we must manually set a bat waypoint", size=2, category="Route Recording")
    Runnable runnable3 = () -> new Thread(() -> {
        if (Main.routeRecording.recording) {
            BlockPos playerPos = Minecraft.func_71410_x().field_71439_g.func_180425_c();
            BlockPos targetPos = new BlockPos(playerPos.func_177958_n(), playerPos.func_177956_o(), playerPos.func_177952_p());
            targetPos = targetPos.func_177982_a(-1, 2, -1);
            Main.routeRecording.addWaypoint(Room.SECRET_TYPES.BAT, targetPos);
            Main.routeRecording.newSecret();
            Main.routeRecording.setRecordingMessage(EnumChatFormatting.YELLOW + "Added bat secret waypoint.");
        } else {
            ChatUtils.sendChatMessage(EnumChatFormatting.RED + "Route recording is not enabled. Press the start recording button to begin.");
        }
    }).start();
    @Button(name="Start recording", text="Start recording", description="Start recording a custom secret route", size=2, category="Route Recording")
    Runnable runnable2 = () -> new Thread(() -> Main.routeRecording.startRecording()).start();
    @Button(name="Set Exit Waypoint", text="Set Exit Waypoint", description="Set an exit waypoint to at the end of your route", size=2, category="Route Recording")
    Runnable runnable16 = () -> new Thread(() -> {
        if (Main.routeRecording.recording) {
            BlockPos playerPos = Minecraft.func_71410_x().field_71439_g.func_180425_c();
            BlockPos targetPos = new BlockPos(playerPos.func_177958_n(), playerPos.func_177956_o(), playerPos.func_177952_p());
            targetPos = targetPos.func_177982_a(-1, 0, -1);
            Main.routeRecording.addWaypoint(Room.SECRET_TYPES.EXITROUTE, targetPos);
            Main.routeRecording.newSecret();
            Main.routeRecording.stopRecording();
            Main.routeRecording.setRecordingMessage("Added route exit waypoint & stopped recording.");
            LogUtils.info("Added route exit waypoint & stopped recording.");
        } else {
            ChatUtils.sendChatMessage(EnumChatFormatting.RED + "Route recording is not enabled. Press the start recording button to begin.");
        }
    }).start();
    @Button(name="Stop recording", text="Stop recording", description="Stop recording your secret route", size=2, category="Route Recording")
    Runnable runnable4 = () -> new Thread(() -> Main.routeRecording.stopRecording()).start();
    @Button(name="Export routes", text="Export routes", description="Export your current secret routes to your downloads folder as routes.json", size=2, category="Route Recording")
    Runnable runnable5 = () -> new Thread(() -> Main.routeRecording.exportAllRoutes()).start();
    @Button(name="Import routes", text="Import routes", description="Import routes to recording from a routes.json in your downloads folder", size=2, category="Route Recording")
    Runnable runnable6 = () -> new Thread(() -> Main.routeRecording.importRoutes("routes.json")).start();
    @Number(name="Route number", description="Sets the number of the route you are currently recording (NOTE: the preceding number needs to be filled for this route to be checked)", min=0.0f, max=10.0f, category="Route Recording", size=2)
    public static int routeNumber;
    @Slider(name="Ping", description="Amount of time to wait before checking pos again to determine etherwarp", max=1000.0f, min=0.0f, category="Route Recording")
    public static int etherwarpPing;
    @HUD(name="Recording info", category="HUD")
    public static RecordingHUD recordingHUD;
    @HUD(name="Current room", category="HUD")
    public static CurrentRoomHUD currentRoomHUD;
    @Text(name="Color Profile Name", description="The name of the color profile to save or load", subcategory="Profiles", category="Rendering", placeholder="default.json")
    public static String colorProfileName;
    @Info(text="Will auto append the .json extension if not provided", subcategory="Profiles", category="Rendering", type=InfoType.INFO)
    public static boolean b;
    @Button(name="Save Color Profile", text="Save", description="Write the current color profile, excluding waypoints, to a file", subcategory="Profiles", category="Rendering")
    Runnable runnable10 = () -> new Thread(() -> ConfigUtils.writeColorConfig(colorProfileName)).start();
    @Button(name="Load Color Profile", text="Load", description="Reads the color profile from a file", subcategory="Profiles", category="Rendering")
    Runnable runnable11 = () -> new Thread(() -> {
        if (ConfigUtils.loadColorConfig(colorProfileName.isEmpty() ? "default.json" : colorProfileName)) {
            ChatUtils.sendChatMessage(EnumChatFormatting.DARK_GREEN + "Loaded " + EnumChatFormatting.GREEN + colorProfileName + EnumChatFormatting.DARK_GREEN + " as color profile");
        }
    }).start();
    @Button(name="List all Color Profiles", text="List", description="Lists all the color profiles in the color profile directory", subcategory="Profiles", category="Rendering")
    Runnable runnable12 = () -> new Thread(() -> {
        ChatUtils.sendChatMessage("Color Profiles:", EnumChatFormatting.DARK_AQUA);
        for (String name : FileUtils.getFileNames(Main.COLOR_PROFILE_PATH)) {
            ChatUtils.sendChatMessage(" - " + name, EnumChatFormatting.AQUA);
        }
    }).start();
    @Button(name="Import Color Profile", text="Import", description="Select a color profile to import, this will be copied to .minecraft/config/SecretRoutes/colorprofiles", subcategory="Profiles", category="Rendering")
    Runnable runnable13 = () -> new Thread(() -> {
        try {
            File file = FileUtils.promptUserForFile();
            if (file != null) {
                FileUtils.copyFileToDirectory(file, Main.COLOR_PROFILE_PATH);
            }
        }
        catch (Exception e) {
            LogUtils.error(e);
        }
    }).start();
    @Slider(name="Alpha multiplier", description="Default opacity multiplier. ONLY HAS AN EFFECT ON THE FULL BLOCK", min=0.0f, max=1.0f, category="Rendering", subcategory="Waypoint Colors")
    public static float alphaMultiplier;
    @Color(name="Line color", subcategory="Waypoint Colors", category="Rendering")
    public static OneColor lineColor;
    @Color(name="Pearl line color", subcategory="Waypoint Colors", category="Rendering")
    public static OneColor pearlLineColor;
    @Color(name="EtherWarp", subcategory="Waypoint Colors", category="Rendering")
    public static OneColor etherWarp;
    @Color(name="Mine", subcategory="Waypoint Colors", category="Rendering")
    public static OneColor mine;
    @Color(name="Interacts", subcategory="Waypoint Colors", category="Rendering")
    public static OneColor interacts;
    @Color(name="superbooms", subcategory="Waypoint Colors", category="Rendering")
    public static OneColor superbooms;
    @Color(name="enderpearls", subcategory="Waypoint Colors", category="Rendering")
    public static OneColor enderpearls;
    @Color(name="Secrets - item", subcategory="Waypoint Colors", category="Rendering")
    public static OneColor secretsItem;
    @Color(name="Secrets - interact", subcategory="Waypoint Colors", category="Rendering")
    public static OneColor secretsInteract;
    @Color(name="Secrets - bat", subcategory="Waypoint Colors", category="Rendering")
    public static OneColor secretsBat;
    @Button(name="Reset to default colors", text="Reset", size=2, subcategory="Waypoint Colors", category="Rendering")
    Runnable runnable7 = () -> {
        alphaMultiplier = 0.5f;
        lineColor = new OneColor(255, 0, 0);
        pearlLineColor = new OneColor(0, 255, 255);
        etherWarp = new OneColor(128, 0, 128);
        mine = new OneColor(255, 255, 0);
        interacts = new OneColor(0, 0, 255);
        superbooms = new OneColor(255, 0, 0);
        enderpearls = new OneColor(0, 255, 255);
        secretsItem = new OneColor(0, 255, 255);
        secretsInteract = new OneColor(0, 0, 255);
        secretsBat = new OneColor(0, 255, 0);
    };
    @Switch(name="Render etherwarps", subcategory="Render Options", category="Rendering", description="Toggles the rendering of etherwarp waypoints")
    public static boolean renderEtherwarps;
    @Switch(name="Full block", subcategory="Render Options", category="Rendering")
    public static boolean etherwarpFullBlock;
    @Switch(name="Render mines", subcategory="Render Options", category="Rendering", description="Toggles the rendering of mines waypoints")
    public static boolean renderMines;
    @Switch(name="Full block", subcategory="Render Options", category="Rendering")
    public static boolean mineFullBlock;
    @Switch(name="Render interacts", subcategory="Render Options", category="Rendering", description="Toggles the rendering of interact waypoints")
    public static boolean renderInteracts;
    @Switch(name="Full block", subcategory="Render Options", category="Rendering")
    public static boolean interactsFullBlock;
    @Switch(name="Render superbooms", subcategory="Render Options", category="Rendering", description="Toggles the rendering of superbooms waypoints")
    public static boolean renderSuperboom;
    @Switch(name="Full block", subcategory="Render Options", category="Rendering")
    public static boolean superboomsFullBlock;
    @Switch(name="Render enderpearls", subcategory="Render Options", category="Rendering", description="Toggles the rendering of enderpearls waypoints")
    public static boolean renderEnderpearls;
    @Switch(name="Full block", subcategory="Render Options", category="Rendering")
    public static boolean enderpearlFullBlock;
    @Switch(name="Render item secrets", subcategory="Render Options", category="Rendering", description="Toggles the rendering of item secret waypoints")
    public static boolean renderSecretsItem;
    @Switch(name="Full block", subcategory="Render Options", category="Rendering")
    public static boolean secretsItemFullBlock;
    @Switch(name="Render interact secrets", subcategory="Render Options", category="Rendering", description="Toggles the rendering of interact secrets waypoints")
    public static boolean renderSecretIteract;
    @Switch(name="Full block", subcategory="Render Options", category="Rendering")
    public static boolean secretsInteractFullBlock;
    @Switch(name="Render bat secrets", subcategory="Render Options", category="Rendering", description="Toggles the rendering of bat secrets waypoints")
    public static boolean renderSecretBat;
    @Switch(name="Full block", subcategory="Render Options", category="Rendering")
    public static boolean secretsBatFullBlock;
    @Button(name="Reset default options", text="reset", category="Rendering", subcategory="Render Options", size=2)
    Runnable runnable17 = () -> {
        renderEtherwarps = true;
        etherwarpFullBlock = false;
        renderMines = true;
        mineFullBlock = false;
        renderInteracts = true;
        interactsFullBlock = false;
        renderSuperboom = true;
        superboomsFullBlock = false;
        renderEnderpearls = true;
        enderpearlFullBlock = false;
        renderSecretsItem = true;
        secretsItemFullBlock = false;
        renderSecretIteract = true;
        secretsInteractFullBlock = false;
        renderSecretBat = true;
        secretsBatFullBlock = false;
    };
    @Switch(name="Start text toggle", size=2, subcategory="Waypoint Text Rendering", category="Rendering")
    public static boolean startTextToggle;
    @Dropdown(name="Start waypoint text color", options={"Black", "Dark blue", "Dark green", "Dark aqua", "Dark red", "Dark purple", "Gold", "Gray", "Dark gray", "Blue", "Green", "Aqua", "Red", "Light purple", "Yellow", "White"}, size=2, subcategory="Waypoint Text Rendering", category="Rendering")
    public static int startWaypointColorIndex;
    @Slider(name="Start waypoint text size", min=1.0f, max=10.0f, subcategory="Waypoint Text Rendering", category="Rendering")
    public static float startTextSize;
    @Switch(name="Exit text toggle", size=2, subcategory="Waypoint Text Rendering", category="Rendering")
    public static boolean exitTextToggle;
    @Dropdown(name="Exit waypoint text color", options={"Black", "Dark blue", "Dark green", "Dark aqua", "Dark red", "Dark purple", "Gold", "Gray", "Dark gray", "Blue", "Green", "Aqua", "Red", "Light purple", "Yellow", "White"}, size=2, subcategory="Waypoint Text Rendering", category="Rendering")
    public static int exitWaypointColorIndex;
    @Slider(name="Exit waypoint text size", min=1.0f, max=10.0f, subcategory="Waypoint Text Rendering", category="Rendering")
    public static float exitTextSize;
    @Switch(name="Interact text toggle", size=2, subcategory="Waypoint Text Rendering", category="Rendering")
    public static boolean interactTextToggle;
    @Dropdown(name="Interact waypoint text color", options={"Black", "Dark blue", "Dark green", "Dark aqua", "Dark red", "Dark purple", "Gold", "Gray", "Dark gray", "Blue", "Green", "Aqua", "Red", "Light purple", "Yellow", "White"}, size=2, subcategory="Waypoint Text Rendering", category="Rendering")
    public static int interactWaypointColorIndex;
    @Slider(name="Interact waypoint text size", min=1.0f, max=10.0f, subcategory="Waypoint Text Rendering", category="Rendering")
    public static float interactTextSize;
    @Switch(name="Item text toggle", size=2, subcategory="Waypoint Text Rendering", category="Rendering")
    public static boolean itemTextToggle;
    @Dropdown(name="Item waypoint text color", options={"Black", "Dark blue", "Dark green", "Dark aqua", "Dark red", "Dark purple", "Gold", "Gray", "Dark gray", "Blue", "Green", "Aqua", "Red", "Light purple", "Yellow", "White"}, size=2, subcategory="Waypoint Text Rendering", category="Rendering")
    public static int itemWaypointColorIndex;
    @Slider(name="Item waypoint text size", min=1.0f, max=10.0f, subcategory="Waypoint Text Rendering", category="Rendering")
    public static float itemTextSize;
    @Switch(name="Bat text toggle", size=2, subcategory="Waypoint Text Rendering", category="Rendering")
    public static boolean batTextToggle;
    @Dropdown(name="Bat waypoint text color", options={"Black", "Dark blue", "Dark green", "Dark aqua", "Dark red", "Dark purple", "Gold", "Gray", "Dark gray", "Blue", "Green", "Aqua", "Red", "Light purple", "Yellow", "White"}, size=2, subcategory="Waypoint Text Rendering", category="Rendering")
    public static int batWaypointColorIndex;
    @Slider(name="Bat waypoint text size", min=1.0f, max=10.0f, subcategory="Waypoint Text Rendering", category="Rendering")
    public static float batTextSize;
    @Switch(name="Etherwarp text toggle", subcategory="Waypoint Text Rendering", category="Rendering")
    public static boolean etherwarpsTextToggle;
    @Switch(name="Etherwarp enumeration toggle", subcategory="Waypoint Text Rendering", category="Rendering", description="Adds a number to the etherwarp waypoints")
    public static boolean etherwarpsEnumToggle;
    @Dropdown(name="Etherwarp waypoint text color", options={"Black", "Dark blue", "Dark green", "Dark aqua", "Dark red", "Dark purple", "Gold", "Gray", "Dark gray", "Blue", "Green", "Aqua", "Red", "Light purple", "Yellow", "White"}, size=2, subcategory="Waypoint Text Rendering", category="Rendering")
    public static int etherwarpsWaypointColorIndex;
    @Slider(name="Etherwarp waypoint text size", min=1.0f, max=10.0f, subcategory="Waypoint Text Rendering", category="Rendering")
    public static float etherwarpsTextSize;
    @Switch(name="Stonk text toggle", size=2, subcategory="Waypoint Text Rendering", category="Rendering")
    public static boolean minesTextToggle;
    @Switch(name="Stonk enumeration toggle", subcategory="Waypoint Text Rendering", category="Rendering", description="Adds a number to the mines waypoints")
    public static boolean minesEnumToggle;
    @Dropdown(name="Stonk waypoint text color", options={"Black", "Dark blue", "Dark green", "Dark aqua", "Dark red", "Dark purple", "Gold", "Gray", "Dark gray", "Blue", "Green", "Aqua", "Red", "Light purple", "Yellow", "White"}, size=2, subcategory="Waypoint Text Rendering", category="Rendering")
    public static int minesWaypointColorIndex;
    @Slider(name="Stonk waypoint text size", min=1.0f, max=10.0f, subcategory="Waypoint Text Rendering", category="Rendering")
    public static float minesTextSize;
    @Switch(name="Interact text toggle", subcategory="Waypoint Text Rendering", size=2, category="Rendering")
    public static boolean interactsTextToggle;
    @Switch(name="Interact enumeration toggle", subcategory="Waypoint Text Rendering", category="Rendering", description="Adds a number to the interact waypoints")
    public static boolean interactsEnumToggle;
    @Dropdown(name="Interact waypoint text color", options={"Black", "Dark blue", "Dark green", "Dark aqua", "Dark red", "Dark purple", "Gold", "Gray", "Dark gray", "Blue", "Green", "Aqua", "Red", "Light purple", "Yellow", "White"}, size=2, subcategory="Waypoint Text Rendering", category="Rendering")
    public static int interactsWaypointColorIndex;
    @Slider(name="Interact waypoint text size", min=1.0f, max=10.0f, subcategory="Waypoint Text Rendering", category="Rendering")
    public static float interactsTextSize;
    @Switch(name="Superboom text toggle", subcategory="Waypoint Text Rendering", size=2, category="Rendering")
    public static boolean superboomsTextToggle;
    @Switch(name="Superboom enumeration toggle", subcategory="Waypoint Text Rendering", category="Rendering", description="Adds a number to the superboom waypoints")
    public static boolean superboomsEnumToggle;
    @Dropdown(name="Superboom waypoint text color", options={"Black", "Dark blue", "Dark green", "Dark aqua", "Dark red", "Dark purple", "Gold", "Gray", "Dark gray", "Blue", "Green", "Aqua", "Red", "Light purple", "Yellow", "White"}, size=2, subcategory="Waypoint Text Rendering", category="Rendering")
    public static int superboomsWaypointColorIndex;
    @Slider(name="Superboom waypoint text size", min=1.0f, max=10.0f, subcategory="Waypoint Text Rendering", category="Rendering")
    public static float superboomsTextSize;
    @Switch(name="Ender Pearl text toggle", size=2, subcategory="Waypoint Text Rendering", category="Rendering")
    public static boolean enderpearlTextToggle;
    @Switch(name="Enderpearl enumeration toggle", subcategory="Waypoint Text Rendering", category="Rendering", description="Adds a number to the superboom waypoints")
    public static boolean enderpearlEnumToggle;
    @Dropdown(name="Ender Pearl waypoint text color", options={"Black", "Dark blue", "Dark green", "Dark aqua", "Dark red", "Dark purple", "Gold", "Gray", "Dark gray", "Blue", "Green", "Aqua", "Red", "Light purple", "Yellow", "White"}, size=2, subcategory="Waypoint Text Rendering", category="Rendering")
    public static int enderpearlWaypointColorIndex;
    @Slider(name="Ender Pearl waypoint text size", min=1.0f, max=10.0f, subcategory="Waypoint Text Rendering", category="Rendering")
    public static float enderpearlTextSize;
    @Button(name="Reset to text defaults", text="Reset", description="Resets all the text options to their default values", size=2, subcategory="Waypoint Text Rendering", category="Rendering")
    Runnable runnable8 = () -> {
        startTextToggle = true;
        startWaypointColorIndex = 12;
        startTextSize = 3.0f;
        exitTextToggle = true;
        exitWaypointColorIndex = 12;
        exitTextSize = 3.0f;
        interactTextToggle = true;
        interactTextSize = 3.0f;
        interactWaypointColorIndex = 10;
        itemTextToggle = true;
        itemWaypointColorIndex = 11;
        itemTextSize = 3.0f;
        batTextToggle = true;
        batWaypointColorIndex = 10;
        batTextSize = 3.0f;
        etherwarpsTextToggle = false;
        etherwarpsEnumToggle = false;
        etherwarpsWaypointColorIndex = 5;
        etherwarpsTextSize = 3.0f;
        minesTextToggle = false;
        minesEnumToggle = false;
        minesWaypointColorIndex = 14;
        minesTextSize = 3.0f;
        interactsTextToggle = false;
        interactsEnumToggle = false;
        interactsWaypointColorIndex = 9;
        interactsTextSize = 3.0f;
        superboomsTextToggle = false;
        superboomsEnumToggle = false;
        superboomsWaypointColorIndex = 12;
        superboomsTextSize = 3.0f;
        enderpearlTextToggle = true;
        enderpearlEnumToggle = false;
        enderpearlWaypointColorIndex = 11;
        enderpearlTextSize = 3.0f;
    };
    @Text(name="Dev password", description="The password to access the dev options", subcategory="General", category="Dev", size=2)
    public static String devPassword;
    @Switch(name="Verbose logging", description="Adds more detailed logging, useful for debugging", subcategory="Chat logging", category="Dev", size=2)
    public static boolean verboseLogging;
    @Switch(name="Better recording", description="Adds more detailed logging for recording, useful for debugging", subcategory="Chat logging", category="Dev")
    public static boolean verboseRecording;
    @Switch(name="Better updating", description="adds more detailed logging for updating, useful for debugging", subcategory="Chat logging", category="Dev")
    public static boolean verboseUpdating;
    @Switch(name="Better info", description="adds more detailed logging for info, useful for debugging", subcategory="Chat logging", category="Dev")
    public static boolean verboseInfo;
    @Switch(name="Better rendering", description="adds more detailed logging rendering, useful for debugging", subcategory="Chat logging", category="Dev")
    public static boolean verboseRendering;
    @Switch(name="ActionBar info", description="Send the actionbar in chat for debugging purposes", subcategory="Chat logging", category="Dev")
    public static boolean actionbarInfo;
    @Switch(name="Force outdated", description="Forces the version to be outdated, useful for testing the auto updater", subcategory="General", category="Dev")
    public static boolean forceUpdateDEBUG;
    @Info(text="Do not turn this on unless you know exactly what you are doing", type=InfoType.ERROR, category="Dev", subcategory="General")
    public static boolean c;
    @Dropdown(name="Custom Pearl Orientation (Unused)", options={"Default", "SW", "NW", "NE", "SE"}, category="Dev")
    public static int customPearlOrientation;
    @KeyBind(name="Next Secret", description="Cycles to the next secret", category="Keybinds", subcategory="Secrets", size=2)
    public static OneKeyBind nextSecret;
    @KeyBind(name="Last Secret", description="Cycles to the last secret", category="Keybinds", subcategory="Secrets", size=2)
    public static OneKeyBind lastSecret;
    @KeyBind(name="Toggle Secret rendering", description="Toggles the rendering of secrets", category="Keybinds", subcategory="Secrets", size=2)
    public static OneKeyBind toggleSecrets;
    @KeyBind(name="Start recording", description="Starts the recording process", category="Keybinds", subcategory="Recording")
    public static OneKeyBind startRecording;
    @KeyBind(name="Stop recording", description="Stops the recording process and adds an exit waypoint", subcategory="Recording", category="Keybinds")
    public static OneKeyBind stopRecording;
    @KeyBind(name="Set Bat Waypoint", description="Adds a bat waypoint on your current position", category="Keybinds", subcategory="Recording")
    public static OneKeyBind setBatWaypoint;
    @KeyBind(name="Export Routes", description="Exports current routes to the routes.json in your downloads folder", category="Keybinds", subcategory="Recording")
    public static OneKeyBind exportRoutes;
    @Switch(name="Warn when keybinds used outside of dungeons", description="Sends a warning message when keybinds are used outside of dungeons", size=2, category="Keybinds", subcategory="General")
    public static boolean warnKeybindsOutsideDungeon;
    @Switch(name="Custom Secret Sound", description="Plays a custom sound when a secret is found", category="General", subcategory="Sound", size=2)
    public static boolean customSecretSound;
    @Dropdown(name="Custom Secret Sound", options={"mob.blaze.hit", "fire.ignite", "random.orb", "random.break", "mob.guardian.land.hit", "note.pling", "zyra.meow"}, category="General", subcategory="Sound")
    public static int customSecretSoundIndex;
    @Slider(name="Custom Secret Sound Volume", min=0.0f, max=1.0f, category="General", subcategory="Sound")
    public static float customSecretSoundVolume;
    @Slider(name="Custom Secret Sound Pitch", min=0.0f, max=2.0f, category="General", subcategory="Sound")
    public static float customSecretSoundPitch;
    @Button(name="Play Custom Secret Sound", text="Play", description="Plays the custom secret sound", category="General", subcategory="Sound", size=2)
    public static Runnable runnable15;
    @Switch(name="Hide boss messages", description="Hides boss messages without impacting other mods", category="General", size=2, subcategory="Messages")
    public static boolean hideBossMessages;
    @Checkbox(name="Hide watcher", description="Hides watcher messages", category="General", subcategory="Messages")
    public static boolean hideWatcher;
    @Checkbox(name="Hide Bonzo", description="Hides Bonzo messages", category="General", subcategory="Messages")
    public static boolean hideBonzo;
    @Checkbox(name="Hide Scarf", description="Hides Scarf messages (f2/m2)", category="General", subcategory="Messages")
    public static boolean hideScarf;
    @Checkbox(name="Hide Professor", description="Hides Professor messages (f3/m3)", category="General", subcategory="Messages")
    public static boolean hideProfessor;
    @Checkbox(name="Hide Thorn", description="Hides Thron messages (f4/m4)", category="General", subcategory="Messages")
    public static boolean hideThorn;
    @Checkbox(name="Hide Livid", description="Hides Livid messages (f5/m5)", category="General", subcategory="Messages")
    public static boolean hideLivid;
    @Checkbox(name="Hide Sadan", description="Hides Sadan messages (f6/m6)", category="General", subcategory="Messages")
    public static boolean hideSadan;
    @Checkbox(name="Hide Wither lords", description="Hides wither lords messages (f7/m7)", category="General", subcategory="Messages")
    public static boolean hideWitherLords;
    @Switch(name="Blood spawned notification", description="Notifies when blood is fully spawned", category="General", subcategory="Messages", size=2)
    public static boolean bloodNotif;
    @Text(name="Blood ready text", description="Text to show when blood is fully spawned", subcategory="Messages", size=1)
    public static String bloodReadyText;
    @Dropdown(name="Color", description="Color of the message", options={"Black", "Dark blue", "Dark green", "Dark aqua", "Dark red", "Dark purple", "Gold", "Gray", "Dark gray", "Blue", "Green", "Aqua", "Red", "Light purple", "Yellow", "White"}, subcategory="Messages")
    public static int bloodReadyColor;
    @Number(name="Duration", description="Duration of the banner", max=15000.0f, min=1.0f, subcategory="Messages")
    public static int bloodBannerDuration;
    @Number(name="Scale", description="Scale of the text", min=1.0f, max=10.0f, size=1, subcategory="Messages")
    public static int bloodScale;
    @Slider(name="X Offset", description="X Offset for the message. (POSITIVE TO THE RIGHT)", subcategory="Messages", min=-1000.0f, max=1000.0f)
    public static int bloodX;
    @Slider(name="Y Offset", description="Y Offset for the message. (POSITIVE TO THE BOTTOM)", subcategory="Messages", min=-1000.0f, max=1000.0f)
    public static int bloodY;
    @Checkbox(name="Render Test message", description="Renders a test message with the paramaters to change position. (Untick when done)", subcategory="Messages")
    public static Boolean renderBlood;
    @Switch(name="Player to next waypoint", category="Dev", subcategory="WIP", size=2)
    public static boolean playerWaypointLine;
    @Switch(name="Player to Etherwarp", description="Draws a line to the next etherwarp location", size=2, category="Dev", subcategory="WIP")
    public static boolean playerToEtherwarp;
    @Checkbox(name="debug", category="Dev", subcategory="WIP", size=2)
    public static boolean debug;
    @Switch(name="Bridge", category="Guild", subcategory="WIP", size=2)
    public static boolean bridge;
    @Switch(name="Server Data", subcategory="Data Privacy", description="Sends data to the server (Masked UUID, Login Timestamp, Mod Version, Online Data)", size=2)
    public static boolean sendData;

    public Boolean lambda(String dependentOption) {
        try {
            return (boolean)((Boolean)((BasicOption)this.optionNames.get(dependentOption)).get());
        }
        catch (IllegalAccessException ignored) {
            ChatUtils.sendVerboseMessage("Error in lambda function");
            return true;
        }
    }

    public SRMConfig() {
        super(new Mod("secretroutesmod", ModType.SKYBLOCK), "secretroutesmod.json");
        this.initialize();
        try {
            ((BasicOption)this.optionNames.get("lineType")).addHideCondition(() -> this.lambda("modEnabled") == false);
            ((BasicOption)this.optionNames.get("width")).addHideCondition(() -> this.lambda("modEnabled") == false);
            ((BasicOption)this.optionNames.get("routesFileName")).addHideCondition(() -> this.lambda("modEnabled") == false);
            ((BasicOption)this.optionNames.get("runnable")).addHideCondition(() -> this.lambda("modEnabled") == false);
            ((BasicOption)this.optionNames.get("runnable9")).addHideCondition(() -> this.lambda("modEnabled") == false);
            ((BasicOption)this.optionNames.get("runnable14")).addHideCondition(() -> this.lambda("modEnabled") == false);
            ((BasicOption)this.optionNames.get("particles")).addHideCondition(() -> !this.isEqualTo(lineType, 0));
            ((BasicOption)this.optionNames.get("particles")).addHideCondition(() -> this.lambda("modEnabled") == false);
            ((BasicOption)this.optionNames.get("tickInterval")).addHideCondition(() -> !this.isEqualTo(lineType, 0));
            ((BasicOption)this.optionNames.get("tickInterval")).addHideCondition(() -> this.lambda("modEnabled") == false);
            ((BasicOption)this.optionNames.get("pearlLineWidth")).addHideCondition(() -> this.lambda("modEnabled") == false);
            ((BasicOption)this.optionNames.get("pearls")).addHideCondition(() -> this.lambda("modEnabled") == false);
            ((BasicOption)this.optionNames.get("pearlRoutesFileName")).addHideCondition(() -> this.lambda("modEnabled") == false);
            ((BasicOption)this.optionNames.get("allSecrets")).addHideCondition(() -> this.lambda("modEnabled") == false);
            ((BasicOption)this.optionNames.get("renderComplete")).addHideCondition(() -> this.lambda("modEnabled") == false);
            ((BasicOption)this.optionNames.get("allSteps")).addHideCondition(() -> this.lambda("modEnabled") == false);
            ((BasicOption)this.optionNames.get("allSteps")).addHideCondition(() -> this.lambda("wholeRoute") == false);
            ((BasicOption)this.optionNames.get("ignored")).addHideCondition(() -> this.lambda("modEnabled") == false);
            ((BasicOption)this.optionNames.get("autoDownload")).addHideCondition(() -> this.lambda("autoCheckUpdates") == false);
            ((BasicOption)this.optionNames.get("startWaypointColorIndex")).addHideCondition(() -> this.lambda("startTextToggle") == false);
            ((BasicOption)this.optionNames.get("startTextSize")).addHideCondition(() -> this.lambda("startTextToggle") == false);
            ((BasicOption)this.optionNames.get("exitWaypointColorIndex")).addHideCondition(() -> this.lambda("exitTextToggle") == false);
            ((BasicOption)this.optionNames.get("exitTextSize")).addHideCondition(() -> this.lambda("exitTextToggle") == false);
            ((BasicOption)this.optionNames.get("interactWaypointColorIndex")).addHideCondition(() -> this.lambda("interactTextToggle") == false);
            ((BasicOption)this.optionNames.get("interactTextSize")).addHideCondition(() -> this.lambda("interactTextToggle") == false);
            ((BasicOption)this.optionNames.get("itemWaypointColorIndex")).addHideCondition(() -> this.lambda("itemTextToggle") == false);
            ((BasicOption)this.optionNames.get("itemTextSize")).addHideCondition(() -> this.lambda("itemTextToggle") == false);
            ((BasicOption)this.optionNames.get("batWaypointColorIndex")).addHideCondition(() -> this.lambda("batTextToggle") == false);
            ((BasicOption)this.optionNames.get("batTextSize")).addHideCondition(() -> this.lambda("batTextToggle") == false);
            ((BasicOption)this.optionNames.get("etherwarpsEnumToggle")).addHideCondition(() -> this.lambda("etherwarpsTextToggle") == false);
            ((BasicOption)this.optionNames.get("etherwarpsWaypointColorIndex")).addHideCondition(() -> this.lambda("etherwarpsTextToggle") == false);
            ((BasicOption)this.optionNames.get("etherwarpsTextSize")).addHideCondition(() -> this.lambda("etherwarpsTextToggle") == false);
            ((BasicOption)this.optionNames.get("minesEnumToggle")).addHideCondition(() -> this.lambda("minesTextToggle") == false);
            ((BasicOption)this.optionNames.get("minesWaypointColorIndex")).addHideCondition(() -> this.lambda("minesTextToggle") == false);
            ((BasicOption)this.optionNames.get("minesTextSize")).addHideCondition(() -> this.lambda("minesTextToggle") == false);
            ((BasicOption)this.optionNames.get("interactsEnumToggle")).addHideCondition(() -> this.lambda("interactsTextToggle") == false);
            ((BasicOption)this.optionNames.get("interactsWaypointColorIndex")).addHideCondition(() -> this.lambda("interactsTextToggle") == false);
            ((BasicOption)this.optionNames.get("interactsTextSize")).addHideCondition(() -> this.lambda("interactsTextToggle") == false);
            ((BasicOption)this.optionNames.get("superboomsEnumToggle")).addHideCondition(() -> this.lambda("superboomsTextToggle") == false);
            ((BasicOption)this.optionNames.get("superboomsWaypointColorIndex")).addHideCondition(() -> this.lambda("superboomsTextToggle") == false);
            ((BasicOption)this.optionNames.get("superboomsTextSize")).addHideCondition(() -> this.lambda("superboomsTextToggle") == false);
            ((BasicOption)this.optionNames.get("enderpearlEnumToggle")).addHideCondition(() -> this.lambda("enderpearlTextToggle") == false);
            ((BasicOption)this.optionNames.get("enderpearlWaypointColorIndex")).addHideCondition(() -> this.lambda("enderpearlTextToggle") == false);
            ((BasicOption)this.optionNames.get("enderpearlTextSize")).addHideCondition(() -> this.lambda("enderpearlTextToggle") == false);
            ((BasicOption)this.optionNames.get("forceUpdateDEBUG")).addHideCondition(() -> this.isDevPasswordNotCorrect());
            ((BasicOption)this.optionNames.get("verboseLogging")).addHideCondition(() -> this.isDevPasswordNotCorrect());
            ((BasicOption)this.optionNames.get("c")).addHideCondition(() -> this.isDevPasswordNotCorrect());
            ((BasicOption)this.optionNames.get("debug")).addHideCondition(() -> this.isDevPasswordNotCorrect());
            ((BasicOption)this.optionNames.get("verboseRecording")).addHideCondition(() -> this.lambda("verboseLogging") == false);
            ((BasicOption)this.optionNames.get("verboseUpdating")).addHideCondition(() -> this.lambda("verboseLogging") == false);
            ((BasicOption)this.optionNames.get("verboseInfo")).addHideCondition(() -> this.lambda("verboseLogging") == false);
            ((BasicOption)this.optionNames.get("verboseRendering")).addHideCondition(() -> this.lambda("verboseLogging") == false);
            ((BasicOption)this.optionNames.get("actionbarInfo")).addHideCondition(() -> this.lambda("verboseLogging") == false);
            ((BasicOption)this.optionNames.get("customSecretSoundIndex")).addHideCondition(() -> this.lambda("customSecretSound") == false);
            ((BasicOption)this.optionNames.get("customSecretSoundVolume")).addHideCondition(() -> this.lambda("customSecretSound") == false);
            ((BasicOption)this.optionNames.get("customSecretSoundPitch")).addHideCondition(() -> this.lambda("customSecretSound") == false);
            ((BasicOption)this.optionNames.get("runnable15")).addHideCondition(() -> this.lambda("customSecretSound") == false);
            ((BasicOption)this.optionNames.get("hideWatcher")).addHideCondition(() -> this.lambda("hideBossMessages") == false);
            ((BasicOption)this.optionNames.get("hideBonzo")).addHideCondition(() -> this.lambda("hideBossMessages") == false);
            ((BasicOption)this.optionNames.get("hideScarf")).addHideCondition(() -> this.lambda("hideBossMessages") == false);
            ((BasicOption)this.optionNames.get("hideProfessor")).addHideCondition(() -> this.lambda("hideBossMessages") == false);
            ((BasicOption)this.optionNames.get("hideThorn")).addHideCondition(() -> this.lambda("hideBossMessages") == false);
            ((BasicOption)this.optionNames.get("hideLivid")).addHideCondition(() -> this.lambda("hideBossMessages") == false);
            ((BasicOption)this.optionNames.get("hideSadan")).addHideCondition(() -> this.lambda("hideBossMessages") == false);
            ((BasicOption)this.optionNames.get("hideWitherLords")).addHideCondition(() -> this.lambda("hideBossMessages") == false);
            ((BasicOption)this.optionNames.get("bloodReadyText")).addHideCondition(() -> this.lambda("bloodNotif") == false);
            ((BasicOption)this.optionNames.get("bloodReadyColor")).addHideCondition(() -> this.lambda("bloodNotif") == false);
            ((BasicOption)this.optionNames.get("bloodBannerDuration")).addHideCondition(() -> this.lambda("bloodNotif") == false);
            ((BasicOption)this.optionNames.get("bloodScale")).addHideCondition(() -> this.lambda("bloodNotif") == false);
            ((BasicOption)this.optionNames.get("bloodX")).addHideCondition(() -> this.lambda("bloodNotif") == false);
            ((BasicOption)this.optionNames.get("bloodY")).addHideCondition(() -> this.lambda("bloodNotif") == false);
            ((BasicOption)this.optionNames.get("renderBlood")).addHideCondition(() -> this.lambda("bloodNotif") == false);
            this.registerKeyBind(lastSecret, () -> {
                if (Utils.inCatacombs) {
                    Main.currentRoom.lastSecretKeybind();
                } else if (warnKeybindsOutsideDungeon) {
                    ChatUtils.sendChatMessage("\u00a7cYou are not in a dungeon!");
                }
            });
            this.registerKeyBind(nextSecret, () -> {
                if (Utils.inCatacombs) {
                    Main.currentRoom.nextSecretKeybind();
                } else if (warnKeybindsOutsideDungeon) {
                    ChatUtils.sendChatMessage("\u00a7cYou are not in a dungeon!");
                }
            });
            this.registerKeyBind(toggleSecrets, () -> {
                if (Utils.inCatacombs) {
                    Main.toggleSecretsKeybind();
                } else if (warnKeybindsOutsideDungeon) {
                    ChatUtils.sendChatMessage("\u00a7cYou are not in a dungeon!");
                }
            });
            this.registerKeyBind(startRecording, this.runnable2);
            this.registerKeyBind(stopRecording, this.runnable16);
            this.registerKeyBind(setBatWaypoint, this.runnable3);
            this.registerKeyBind(exportRoutes, this.runnable5);
        }
        catch (Exception e) {
            LogUtils.error(e);
        }
    }

    public boolean isDevPasswordNotCorrect() {
        if (devPassword.equals("KyleIsMyDaddy")) {
            return false;
        }
        verboseLogging = false;
        forceUpdateDEBUG = false;
        return true;
    }

    public boolean isEqualTo(Object a, Object b) {
        return a.equals(b);
    }

    public void openGui(String page) {
        ModConfigPage test = new ModConfigPage(Main.config.mod.defaultPage);
        ((OptionCategory)test.getPage().categories.get((Object)"add")).subcategories.get(1);
    }

    static {
        allSecrets = false;
        lineType = 0;
        particles = 26;
        tickInterval = 1;
        width = 5;
        pearlLineWidth = 5;
        pearls = true;
        routesFileName = "routes.json";
        pearlRoutesFileName = "pearlroutes.json";
        copyFileName = "";
        trackPersonalBests = true;
        sendChatMessages = true;
        autoCheckUpdates = true;
        autoDownload = false;
        autoUpdateRoutes = false;
        routeNumber = 0;
        etherwarpPing = 150;
        recordingHUD = new RecordingHUD();
        currentRoomHUD = new CurrentRoomHUD();
        colorProfileName = "default.json";
        alphaMultiplier = 0.5f;
        lineColor = new OneColor(255, 0, 0);
        pearlLineColor = new OneColor(0, 255, 255);
        etherWarp = new OneColor(128, 0, 128);
        mine = new OneColor(255, 255, 0);
        interacts = new OneColor(0, 0, 255);
        superbooms = new OneColor(255, 0, 0);
        enderpearls = new OneColor(0, 255, 255);
        secretsItem = new OneColor(0, 255, 255);
        secretsInteract = new OneColor(0, 0, 255);
        secretsBat = new OneColor(0, 255, 0);
        renderEtherwarps = true;
        etherwarpFullBlock = false;
        renderMines = true;
        mineFullBlock = false;
        renderInteracts = true;
        interactsFullBlock = false;
        renderSuperboom = true;
        superboomsFullBlock = false;
        renderEnderpearls = true;
        enderpearlFullBlock = false;
        renderSecretsItem = true;
        secretsItemFullBlock = false;
        renderSecretIteract = true;
        secretsInteractFullBlock = false;
        renderSecretBat = true;
        secretsBatFullBlock = false;
        startTextToggle = true;
        startWaypointColorIndex = 12;
        startTextSize = 3.0f;
        exitTextToggle = true;
        exitWaypointColorIndex = 12;
        exitTextSize = 3.0f;
        interactTextToggle = true;
        interactWaypointColorIndex = 9;
        interactTextSize = 3.0f;
        itemTextToggle = true;
        itemWaypointColorIndex = 11;
        itemTextSize = 3.0f;
        batTextToggle = true;
        batWaypointColorIndex = 10;
        batTextSize = 3.0f;
        etherwarpsTextToggle = false;
        etherwarpsEnumToggle = false;
        etherwarpsWaypointColorIndex = 5;
        etherwarpsTextSize = 3.0f;
        minesTextToggle = false;
        minesEnumToggle = false;
        minesWaypointColorIndex = 14;
        minesTextSize = 3.0f;
        interactsTextToggle = false;
        interactsEnumToggle = false;
        interactsWaypointColorIndex = 9;
        interactsTextSize = 3.0f;
        superboomsTextToggle = false;
        superboomsEnumToggle = false;
        superboomsWaypointColorIndex = 12;
        superboomsTextSize = 3.0f;
        enderpearlTextToggle = true;
        enderpearlEnumToggle = false;
        enderpearlWaypointColorIndex = 11;
        enderpearlTextSize = 3.0f;
        devPassword = "";
        verboseLogging = false;
        verboseRecording = true;
        verboseUpdating = true;
        verboseInfo = false;
        verboseRendering = false;
        actionbarInfo = false;
        forceUpdateDEBUG = false;
        customPearlOrientation = 0;
        nextSecret = new OneKeyBind(new int[]{UKeyboard.KEY_RBRACKET});
        lastSecret = new OneKeyBind(new int[]{UKeyboard.KEY_LBRACKET});
        toggleSecrets = new OneKeyBind(new int[]{UKeyboard.KEY_BACKSLASH});
        startRecording = new OneKeyBind();
        stopRecording = new OneKeyBind();
        setBatWaypoint = new OneKeyBind();
        exportRoutes = new OneKeyBind();
        warnKeybindsOutsideDungeon = true;
        customSecretSound = false;
        customSecretSoundIndex = 6;
        customSecretSoundVolume = 1.0f;
        customSecretSoundPitch = 1.0f;
        runnable15 = () -> SecretSounds.secretChime(true);
        hideBossMessages = false;
        hideWatcher = true;
        hideBonzo = true;
        hideScarf = true;
        hideProfessor = true;
        hideThorn = true;
        hideLivid = true;
        hideSadan = true;
        hideWitherLords = false;
        bloodNotif = false;
        bloodReadyText = "Blood Ready";
        bloodReadyColor = 6;
        bloodBannerDuration = 3000;
        bloodScale = 2;
        bloodX = 0;
        bloodY = -100;
        renderBlood = false;
        playerWaypointLine = false;
        playerToEtherwarp = false;
        debug = false;
        bridge = false;
        sendData = true;
    }
}

