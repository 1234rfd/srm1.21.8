/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.NonNull
 */
package xyz.yourboykyle.secretroutes.deps.libautoupdate;

import java.io.File;
import java.util.List;
import lombok.NonNull;

public abstract class UpdateAction {
    private UpdateAction() {
    }

    public abstract void encode(List<String> var1);

    public static final class MoveDownloadedFile
    extends UpdateAction {
        @NonNull
        private final File whereFrom;
        @NonNull
        private final File whereTo;

        @Override
        public void encode(List<String> arguments) {
            arguments.add("move");
            arguments.add(this.whereFrom.getAbsolutePath());
            arguments.add(this.whereTo.getAbsolutePath());
        }

        public MoveDownloadedFile(@NonNull File whereFrom, @NonNull File whereTo) {
            if (whereFrom == null) {
                throw new NullPointerException("whereFrom is marked non-null but is null");
            }
            if (whereTo == null) {
                throw new NullPointerException("whereTo is marked non-null but is null");
            }
            this.whereFrom = whereFrom;
            this.whereTo = whereTo;
        }

        @NonNull
        public File getWhereFrom() {
            return this.whereFrom;
        }

        @NonNull
        public File getWhereTo() {
            return this.whereTo;
        }

        public String toString() {
            return "UpdateAction.MoveDownloadedFile(whereFrom=" + this.getWhereFrom() + ", whereTo=" + this.getWhereTo() + ")";
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof MoveDownloadedFile)) {
                return false;
            }
            MoveDownloadedFile other = (MoveDownloadedFile)o;
            if (!other.canEqual(this)) {
                return false;
            }
            File this$whereFrom = this.getWhereFrom();
            File other$whereFrom = other.getWhereFrom();
            if (this$whereFrom == null ? other$whereFrom != null : !((Object)this$whereFrom).equals(other$whereFrom)) {
                return false;
            }
            File this$whereTo = this.getWhereTo();
            File other$whereTo = other.getWhereTo();
            return !(this$whereTo == null ? other$whereTo != null : !((Object)this$whereTo).equals(other$whereTo));
        }

        protected boolean canEqual(Object other) {
            return other instanceof MoveDownloadedFile;
        }

        public int hashCode() {
            int PRIME = 59;
            int result = 1;
            File $whereFrom = this.getWhereFrom();
            result = result * 59 + ($whereFrom == null ? 43 : ((Object)$whereFrom).hashCode());
            File $whereTo = this.getWhereTo();
            result = result * 59 + ($whereTo == null ? 43 : ((Object)$whereTo).hashCode());
            return result;
        }
    }

    public static final class DeleteFile
    extends UpdateAction {
        @NonNull
        private final File toDelete;

        @Override
        public void encode(List<String> arguments) {
            arguments.add("delete");
            arguments.add(this.toDelete.getAbsolutePath());
        }

        public DeleteFile(@NonNull File toDelete) {
            if (toDelete == null) {
                throw new NullPointerException("toDelete is marked non-null but is null");
            }
            this.toDelete = toDelete;
        }

        @NonNull
        public File getToDelete() {
            return this.toDelete;
        }

        public String toString() {
            return "UpdateAction.DeleteFile(toDelete=" + this.getToDelete() + ")";
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof DeleteFile)) {
                return false;
            }
            DeleteFile other = (DeleteFile)o;
            if (!other.canEqual(this)) {
                return false;
            }
            File this$toDelete = this.getToDelete();
            File other$toDelete = other.getToDelete();
            return !(this$toDelete == null ? other$toDelete != null : !((Object)this$toDelete).equals(other$toDelete));
        }

        protected boolean canEqual(Object other) {
            return other instanceof DeleteFile;
        }

        public int hashCode() {
            int PRIME = 59;
            int result = 1;
            File $toDelete = this.getToDelete();
            result = result * 59 + ($toDelete == null ? 43 : ((Object)$toDelete).hashCode());
            return result;
        }
    }
}

