/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumParticleTypes
 */
package xyz.yourboykyle.secretroutes.utils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.io.File;
import java.io.FileReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumParticleTypes;
import xyz.yourboykyle.secretroutes.Main;
import xyz.yourboykyle.secretroutes.config.SRMConfig;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.dungeons.catacombs.RoomDetection;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.utils.MapUtils;
import xyz.yourboykyle.secretroutes.events.OnSecretComplete;
import xyz.yourboykyle.secretroutes.utils.BlockUtils;
import xyz.yourboykyle.secretroutes.utils.LogUtils;
import xyz.yourboykyle.secretroutes.utils.PBUtils;
import xyz.yourboykyle.secretroutes.utils.PrintingUtils;
import xyz.yourboykyle.secretroutes.utils.RenderUtils;
import xyz.yourboykyle.secretroutes.utils.multistorage.Triple;

public class Room {
    int c = 0;
    public String name;
    public JsonArray currentSecretRoute;
    public JsonArray currentSecretRoute2;
    public int currentSecretIndex = 0;
    public JsonObject currentSecretWaypoints;
    public JsonArray tests;
    public HashMap<String, Integer> map = new HashMap();
    public PrintingUtils printer = new PrintingUtils();
    public ArrayList<JsonArray> arrays = new ArrayList();
    public Triple<String, Integer, Double> closest = null;

    public Room(String roomName) {
        try {
            this.name = roomName;
            if (roomName != null) {
                String filePath = SRMConfig.pearls ? Main.ROUTES_PATH + File.separator + (!SRMConfig.pearlRoutesFileName.equals("") ? SRMConfig.pearlRoutesFileName : "pearlroutes.json") : Main.ROUTES_PATH + File.separator + (!SRMConfig.routesFileName.equals("") ? SRMConfig.routesFileName : "pearlroutes.json");
                this.getData(filePath);
            } else {
                this.currentSecretRoute = null;
            }
        }
        catch (Exception e) {
            LogUtils.error(e);
        }
    }

    public Room(String roomName, String filePath) {
        try {
            this.name = roomName;
            if (roomName != null) {
                this.getData(filePath);
            }
        }
        catch (Exception e) {
            LogUtils.error(e);
        }
    }

    public void lastSecretKeybind() {
        PBUtils.pbIsValid = false;
        if (this.currentSecretIndex > 0) {
            --this.currentSecretIndex;
        }
        this.currentSecretWaypoints = this.currentSecretIndex < this.currentSecretRoute.size() ? this.currentSecretRoute.get(this.currentSecretIndex).getAsJsonObject() : null;
    }

    public void nextSecret() {
        OnSecretComplete.onSecretCompleteNoKeybind();
        ++this.currentSecretIndex;
        this.currentSecretWaypoints = this.currentSecretIndex < this.currentSecretRoute.size() ? this.currentSecretRoute.get(this.currentSecretIndex).getAsJsonObject() : null;
    }

    public void nextSecretKeybind() {
        PBUtils.pbIsValid = false;
        if (this.currentSecretRoute != null) {
            if (this.currentSecretIndex < this.currentSecretRoute.size() - 1) {
                ++this.currentSecretIndex;
            }
            this.currentSecretWaypoints = this.currentSecretIndex < this.currentSecretRoute.size() ? this.currentSecretRoute.get(this.currentSecretIndex).getAsJsonObject() : null;
        }
    }

    public SECRET_TYPES getSecretType() {
        try {
            if (this.currentSecretWaypoints != null && this.currentSecretWaypoints.get("secret") != null && this.currentSecretWaypoints.get("secret").getAsJsonObject().get("type") != null) {
                String type;
                switch (type = this.currentSecretWaypoints.get("secret").getAsJsonObject().get("type").getAsString()) {
                    case "interact": {
                        return SECRET_TYPES.INTERACT;
                    }
                    case "item": {
                        return SECRET_TYPES.ITEM;
                    }
                    case "bat": {
                        return SECRET_TYPES.BAT;
                    }
                    case "exitroute": {
                        return SECRET_TYPES.EXITROUTE;
                    }
                }
            }
        }
        catch (Exception e) {
            LogUtils.error(e);
        }
        return null;
    }

    public BlockPos getSecretLocation() {
        if (this.currentSecretWaypoints == null) {
            return null;
        }
        if (this.currentSecretWaypoints.get("secret") != null && this.currentSecretWaypoints.get("secret").getAsJsonObject().get("location") != null) {
            JsonArray location = this.currentSecretWaypoints.get("secret").getAsJsonObject().get("location").getAsJsonArray();
            Main.checkRoomData();
            return MapUtils.relativeToActual(new BlockPos(location.get(0).getAsInt(), location.get(1).getAsInt(), location.get(2).getAsInt()), RoomDetection.roomDirection, RoomDetection.roomCorner);
        }
        return null;
    }

    public void renderLines() {
        block10: {
            try {
                if (this.currentSecretWaypoints == null || !this.currentSecretWaypoints.has("locations")) break block10;
                LinkedList<BlockPos> lines = new LinkedList<BlockPos>();
                JsonArray lineLocations = new JsonArray();
                try {
                    lineLocations = this.currentSecretWaypoints.get("locations").getAsJsonArray();
                }
                catch (IllegalStateException e) {
                    LogUtils.info(String.valueOf(this.currentSecretWaypoints.get("locations")));
                    LogUtils.info(this.currentSecretWaypoints.get("locations").getClass().getName());
                    LogUtils.error(e);
                    return;
                }
                for (JsonElement lineLocationElement : lineLocations) {
                    JsonArray lineLocation = lineLocationElement.getAsJsonArray();
                    Main.checkRoomData();
                    lines.add(MapUtils.relativeToActual(new BlockPos(lineLocation.get(0).getAsInt(), lineLocation.get(1).getAsInt(), lineLocation.get(2).getAsInt()), RoomDetection.roomDirection, RoomDetection.roomCorner));
                }
                if (SRMConfig.lineType == 0) {
                    if (this.c < SRMConfig.tickInterval) {
                        ++this.c;
                        return;
                    }
                    this.c = 0;
                    int particleType = SRMConfig.particles;
                    if (particleType >= 36) {
                        particleType += 3;
                    }
                    try {
                        RenderUtils.drawLineMultipleParticles(EnumParticleTypes.func_179342_a((int)particleType), lines);
                    }
                    catch (Exception e) {
                        LogUtils.error(e);
                    }
                }
            }
            catch (Exception e) {
                LogUtils.error(e);
            }
        }
    }

    public void getData(String filePath) {
        new Thread(() -> {
            HashMap<String, Integer> map = new HashMap<String, Integer>();
            try {
                int i;
                Gson gson = new GsonBuilder().create();
                FileReader reader = new FileReader(filePath);
                JsonObject data = gson.fromJson((Reader)reader, JsonObject.class);
                for (i = 0; i <= 10; ++i) {
                    String path = this.name;
                    if (i == 0) {
                        if (data == null || data.isJsonNull() || data.get(this.name) == null || data.get(this.name).isJsonNull()) {
                            this.currentSecretRoute = null;
                        }
                    } else {
                        path = this.name + ":" + i;
                    }
                    if (data == null || data.isJsonNull() || data.get(path) == null || data.get(path).isJsonNull()) continue;
                    JsonArray route = data.get(path).getAsJsonArray();
                    this.arrays.add(route);
                    JsonArray starPoseArray = route.get(0).getAsJsonObject().get("locations").getAsJsonArray().get(0).getAsJsonArray();
                    BlockPos startPos = new BlockPos(starPoseArray.get(0).getAsInt(), starPoseArray.get(1).getAsInt(), starPoseArray.get(2).getAsInt());
                    map.put(BlockUtils.blockPos(startPos), i);
                }
                i = 0;
                for (Map.Entry entry : map.entrySet()) {
                    double dist2;
                    EntityPlayerSP p = Minecraft.func_71410_x().field_71439_g;
                    BlockPos pPos = new BlockPos(p.field_70165_t, p.field_70163_u, p.field_70161_v);
                    BlockPos relPos = MapUtils.actualToRelative(pPos, RoomDetection.roomDirection, RoomDetection.roomCorner);
                    double dist1 = BlockUtils.blockDistance(relPos, (String)entry.getKey());
                    if (this.closest != null && dist1 > (dist2 = this.closest.getThree().doubleValue())) continue;
                    this.closest = new Triple(entry.getKey(), i, dist1);
                    ++i;
                }
                if (this.closest != null) {
                    this.currentSecretRoute = this.arrays.get((Integer)this.closest.getTwo());
                    this.currentSecretWaypoints = this.currentSecretRoute.get(this.currentSecretIndex).getAsJsonObject();
                }
            }
            catch (Exception e) {
                LogUtils.error(e);
            }
        }).start();
    }

    public static enum SECRET_TYPES {
        INTERACT,
        ITEM,
        BAT,
        EXITROUTE;

    }

    public static enum WAYPOINT_TYPES {
        LOCATIONS,
        ETHERWARPS,
        MINES,
        INTERACTS,
        TNTS,
        ENDERPEARLS;

    }
}

