/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Blocks
 *  net.minecraft.util.BlockPos
 *  net.minecraftforge.event.entity.player.PlayerInteractEvent
 *  net.minecraftforge.event.entity.player.PlayerInteractEvent$Action
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package xyz.yourboykyle.secretroutes.events;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import xyz.yourboykyle.secretroutes.Main;
import xyz.yourboykyle.secretroutes.config.SRMConfig;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.dungeons.catacombs.RoomDetection;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.utils.MapUtils;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.utils.Utils;
import xyz.yourboykyle.secretroutes.events.OnItemPickedUp;
import xyz.yourboykyle.secretroutes.utils.BlockUtils;
import xyz.yourboykyle.secretroutes.utils.LogUtils;
import xyz.yourboykyle.secretroutes.utils.Room;
import xyz.yourboykyle.secretroutes.utils.SecretSounds;
import xyz.yourboykyle.secretroutes.utils.SecretUtils;

public class OnPlayerInteract {
    @SubscribeEvent
    public static void onPlayerInteract(PlayerInteractEvent e) {
        try {
            if (e.action == PlayerInteractEvent.Action.RIGHT_CLICK_BLOCK) {
                EntityPlayer p = e.entityPlayer;
                BlockPos pos = e.pos;
                Block block = e.world.func_180495_p(e.pos).func_177230_c();
                Utils.checkForCatacombs();
                if (!Utils.inCatacombs) {
                    return;
                }
                if (block != Blocks.field_150486_ae && block != Blocks.field_150447_bR && block != Blocks.field_150442_at && block != Blocks.field_150465_bP) {
                    return;
                }
                if (BlockUtils.blockPos(MapUtils.actualToRelative(pos, RoomDetection.roomDirection, RoomDetection.roomCorner)).equals(BlockUtils.blockPos(SecretUtils.currentLeverPos))) {
                    SecretUtils.resetValues();
                }
                SecretUtils.lastInteract = pos;
                if (SRMConfig.allSecrets && SecretUtils.secrets != null) {
                    for (JsonElement secret : SecretUtils.secrets) {
                        try {
                            JsonObject json = secret.getAsJsonObject();
                            BlockPos spos = new BlockPos(json.get("x").getAsInt(), json.get("y").getAsInt(), json.get("z").getAsInt());
                            BlockPos rel = MapUtils.actualToRelative(pos, RoomDetection.roomDirection, RoomDetection.roomCorner);
                            if (!BlockUtils.blockPos(spos).equals(BlockUtils.blockPos(rel)) || SecretUtils.secretLocations.contains(BlockUtils.blockPos(spos))) continue;
                            SecretUtils.secretLocations.add(BlockUtils.blockPos(spos));
                        }
                        catch (Exception ex) {
                            LogUtils.error(ex);
                        }
                    }
                }
                if (Main.currentRoom.getSecretType() == Room.SECRET_TYPES.INTERACT) {
                    BlockPos interactPos = Main.currentRoom.getSecretLocation();
                    SecretSounds.secretChime();
                    if (pos.func_177958_n() == interactPos.func_177958_n() && pos.func_177956_o() == interactPos.func_177956_o() && pos.func_177952_p() == interactPos.func_177952_p()) {
                        Main.currentRoom.nextSecret();
                        LogUtils.info("Interacted with block at " + interactPos);
                    }
                }
                if (Main.routeRecording.recording) {
                    boolean created;
                    if (block == Blocks.field_150442_at) {
                        Main.routeRecording.addWaypoint(Room.WAYPOINT_TYPES.INTERACTS, e.pos);
                        Main.routeRecording.setRecordingMessage("Added interact waypoint.");
                    } else if ((block == Blocks.field_150465_bP || block == Blocks.field_150486_ae || block == Blocks.field_150447_bR) && (created = Main.routeRecording.addWaypoint(Room.SECRET_TYPES.INTERACT, e.pos))) {
                        Main.routeRecording.newSecret();
                        Main.routeRecording.setRecordingMessage("Added interact secret waypoint.");
                        OnItemPickedUp.itemSecretOnCooldown = true;
                        new Thread(() -> {
                            try {
                                Thread.sleep(2000L);
                                OnItemPickedUp.itemSecretOnCooldown = false;
                            }
                            catch (InterruptedException ex) {
                                LogUtils.error(ex);
                            }
                        }).start();
                    }
                }
            }
        }
        catch (Exception ex) {
            LogUtils.error(ex);
        }
    }
}

