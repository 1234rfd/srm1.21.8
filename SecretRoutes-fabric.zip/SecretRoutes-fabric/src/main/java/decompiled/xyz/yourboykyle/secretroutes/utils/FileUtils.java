/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.io.IOUtils
 */
package xyz.yourboykyle.secretroutes.utils;

import java.awt.FileDialog;
import java.awt.Frame;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.FileAttribute;
import java.util.ArrayList;
import java.util.List;
import javax.net.ssl.HttpsURLConnection;
import org.apache.commons.io.IOUtils;
import xyz.yourboykyle.secretroutes.Main;
import xyz.yourboykyle.secretroutes.config.SRMConfig;
import xyz.yourboykyle.secretroutes.utils.LogUtils;
import xyz.yourboykyle.secretroutes.utils.SSLUtils;

public class FileUtils {
    public static List<String> getFileNames(String path) {
        File[] files = new File(path).listFiles();
        ArrayList<String> list = new ArrayList<String>();
        for (File f : files) {
            if (!f.getName().contains(".json")) continue;
            list.add(f.getName());
        }
        return list;
    }

    public static List<String> getRouteFileNames() {
        return FileUtils.getFileNames(Main.ROUTES_PATH);
    }

    public static String[] getRouteFileNamesArray() {
        List<String> routeFileNames = FileUtils.getRouteFileNames();
        return routeFileNames.toArray(new String[0]);
    }

    public static boolean doesFileExist(String path) {
        return new File(path).exists();
    }

    public static File promptUserForFile() {
        Frame frame = new Frame();
        frame.setVisible(false);
        frame.setAlwaysOnTop(true);
        FileDialog fileDialog = new FileDialog(frame, "Select a file", 0);
        fileDialog.setVisible(true);
        String filePath = fileDialog.getFile();
        String directoryPath = fileDialog.getDirectory();
        frame.dispose();
        if (filePath != null) {
            return new File(directoryPath, filePath);
        }
        return null;
    }

    public static void copyFileToDirectory(File sourceFile, String targetDirectoryPath) {
        Path targetDirectory = new File(targetDirectoryPath).toPath();
        try {
            if (!Files.exists(targetDirectory, new LinkOption[0])) {
                Files.createDirectories(targetDirectory, new FileAttribute[0]);
            }
            Path targetFilePath = targetDirectory.resolve(sourceFile.getName());
            Files.copy(sourceFile.toPath(), targetFilePath, StandardCopyOption.REPLACE_EXISTING);
        }
        catch (IOException e) {
            LogUtils.error(e);
        }
    }

    public static void copyFileToRoutesDirectory() {
        try {
            String filename = SRMConfig.copyFileName;
            FileUtils.copyAndRename(System.getProperty("user.home") + File.separator + "Downloads" + File.separator + "routes.json", Main.ROUTES_PATH, filename);
        }
        catch (Exception e) {
            LogUtils.error(e);
        }
    }

    public static void copyAndRename(String sourceFile, String targetDirectoryPath, String targetFileName) {
        Path sourcePath = Paths.get(sourceFile, new String[0]);
        Path destinationPath = Paths.get(targetDirectoryPath, targetFileName);
        try {
            Files.createDirectories(destinationPath.getParent(), new FileAttribute[0]);
            Files.copy(sourcePath, destinationPath, StandardCopyOption.REPLACE_EXISTING);
            System.out.println("File copied successfully to: " + destinationPath);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void downloadFile(File outputFile, URL url) throws IOException {
        HttpsURLConnection connection = (HttpsURLConnection)url.openConnection();
        connection.setSSLSocketFactory(SSLUtils.getSSLSocketFactory());
        InputStream inputStream = connection.getInputStream();
        OutputStream outputStream = Files.newOutputStream(outputFile.toPath(), new OpenOption[0]);
        IOUtils.copy((InputStream)inputStream, (OutputStream)outputStream);
        outputStream.close();
        inputStream.close();
    }
}

