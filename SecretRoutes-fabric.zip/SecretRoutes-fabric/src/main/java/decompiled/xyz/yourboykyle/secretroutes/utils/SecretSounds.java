/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.util.Vec3
 */
package xyz.yourboykyle.secretroutes.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.util.Vec3;
import xyz.yourboykyle.secretroutes.config.SRMConfig;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.utils.Utils;

public class SecretSounds {
    private static boolean shouldBypassVolume = false;
    private static Minecraft mc = Minecraft.func_71410_x();
    private static long lastPlayed = System.currentTimeMillis();
    private static String[] defaultSounds = new String[]{"mob.blaze.hit", "fire.ignite", "random.orb", "random.break", "mob.guardian.land.hit", "note.pling", "secretroutesmod:zyra.meow0"};

    public static void secretChime(Boolean bypass) {
        Utils.checkForCatacombs();
        if (!(bypass.booleanValue() || SRMConfig.customSecretSound && System.currentTimeMillis() - lastPlayed > 10L && Utils.inCatacombs)) {
            return;
        }
        if (SRMConfig.customSecretSoundIndex == 6) {
            long test = System.currentTimeMillis() % 9L;
            SecretSounds.playLoudSound("secretroutesmod:zyra.meow" + test, Float.valueOf(SRMConfig.customSecretSoundVolume), Float.valueOf(SRMConfig.customSecretSoundPitch), SecretSounds.mc.field_71439_g.func_174791_d());
            lastPlayed = System.currentTimeMillis();
        } else {
            SecretSounds.playLoudSound(defaultSounds[SRMConfig.customSecretSoundIndex], Float.valueOf(SRMConfig.customSecretSoundVolume), Float.valueOf(SRMConfig.customSecretSoundPitch), SecretSounds.mc.field_71439_g.func_174791_d());
            lastPlayed = System.currentTimeMillis();
        }
    }

    public static void secretChime() {
        SecretSounds.secretChime(false);
    }

    public static void playLoudSound(String sound, Float volume, Float pitch, Vec3 pos) {
        mc.func_152344_a(() -> {
            shouldBypassVolume = true;
            SecretSounds.mc.field_71441_e.func_72980_b(pos.field_72450_a, pos.field_72448_b + 1.62, pos.field_72449_c, sound, volume.floatValue(), pitch.floatValue(), false);
            shouldBypassVolume = false;
        });
    }
}

