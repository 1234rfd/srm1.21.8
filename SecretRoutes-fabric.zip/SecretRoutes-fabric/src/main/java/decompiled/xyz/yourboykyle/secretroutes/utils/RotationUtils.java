/*
 * Decompiled with CFR 0.152.
 */
package xyz.yourboykyle.secretroutes.utils;

public class RotationUtils {
    public static float actualToRelativeYaw(float yaw, String direction) {
        switch (direction) {
            case "SW": {
                return yaw;
            }
            case "NW": {
                return yaw - 90.0f;
            }
            case "NE": {
                return yaw - 180.0f;
            }
            case "SE": {
                return yaw - 270.0f;
            }
        }
        return yaw;
    }

    public static float relativeToActualYaw(float yaw, String direction) {
        switch (direction) {
            case "SW": {
                return yaw;
            }
            case "NW": {
                return yaw + 90.0f;
            }
            case "NE": {
                return yaw + 180.0f;
            }
            case "SE": {
                return yaw + 270.0f;
            }
        }
        return yaw;
    }
}

