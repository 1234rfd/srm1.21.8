/*
 * Decompiled with CFR 0.152.
 */
package xyz.yourboykyle.secretroutes.deps.libautoupdate;

import java.io.File;
import java.util.List;
import xyz.yourboykyle.secretroutes.deps.libautoupdate.DeleteAndSaveInSameFolderUpdateTarget;
import xyz.yourboykyle.secretroutes.deps.libautoupdate.PotentialUpdate;
import xyz.yourboykyle.secretroutes.deps.libautoupdate.ReplaceJarUpdateTarget;
import xyz.yourboykyle.secretroutes.deps.libautoupdate.UpdateAction;
import xyz.yourboykyle.secretroutes.deps.libautoupdate.UpdateUtils;

public interface UpdateTarget {
    public List<UpdateAction> generateUpdateActions(PotentialUpdate var1);

    public static UpdateTarget replaceJar(Class<?> containedClass) {
        File file = UpdateUtils.getJarFileContainingClass(containedClass);
        return new ReplaceJarUpdateTarget(file);
    }

    public static UpdateTarget deleteAndSaveInTheSameFolder(Class<?> containedClass) {
        File file = UpdateUtils.getJarFileContainingClass(containedClass);
        return new DeleteAndSaveInSameFolderUpdateTarget(file);
    }
}

