/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  cc.polyfrost.oneconfig.config.core.OneColor
 *  net.minecraft.util.EnumChatFormatting
 */
package xyz.yourboykyle.secretroutes.utils;

import cc.polyfrost.oneconfig.config.core.OneColor;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.util.HashMap;
import net.minecraft.util.EnumChatFormatting;
import xyz.yourboykyle.secretroutes.Main;
import xyz.yourboykyle.secretroutes.config.SRMConfig;
import xyz.yourboykyle.secretroutes.utils.ChatUtils;
import xyz.yourboykyle.secretroutes.utils.LogUtils;

public class ConfigUtils {
    static String[] keys = new String[]{"startTextToggle", "startWaypointColorIndex", "startTextSize", "exitTextToggle", "exitWaypointColorIndex", "exitTextSize", "interactTextToggle", "interactWaypointColorIndex", "interactTextSize", "itemTextToggle", "itemWaypointColorIndex", "itemTextSize", "batTextToggle", "batWaypointColorIndex", "batTextSize", "etherwarpsTextToggle", "etherwarpsEnumToggle", "etherwarpsWaypointColorIndex", "etherwarpsTextSize", "minesTextToggle", "minesEnumToggle", "minesWaypointColorIndex", "minesTextSize", "interactsTextToggle", "interactsEnumToggle", "interactsWaypointColorIndex", "interactsTextSize", "superboomsTextToggle", "superboomsEnumToggle", "superboomsWaypointColorIndex", "superboomsTextSize", "enderpearlTextToggle", "enderpearlEnumToggle", "enderpearlWaypointColorIndex", "enderpearlTextSize", "etherwarpFullBlock", "mineFullBlock", "superboomsFullBlock", "enderpearlFullBlock", "secretsItemFullBlock", "secretsInteractFullBlock", "secretsBatFullBlock", "interactsFullBlock", "lineColor", "etherWarp", "mine", "interacts", "superbooms", "enderpearls", "secretsItem", "secretsInteract", "secretsBat", "pearlLineColor", "renderEtherwarps", "renderMines", "renderInteracts", "renderSuperboom", "renderEnderpearls", "renderSecretsItem", "renderSecretIteract", "renderSecretBat"};

    public static void writeColorConfig(String path) {
        if (!path.endsWith(".json")) {
            path = path + ".json";
        }
        HashMap<String, Object> defaultColors = new HashMap<String, Object>();
        for (String key : keys) {
            try {
                defaultColors.put(key, SRMConfig.class.getDeclaredField(key).get(null));
            }
            catch (Exception e) {
                LogUtils.error(e);
            }
        }
        try {
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            String json = gson.toJson(defaultColors);
            try (FileWriter writer = new FileWriter(Main.COLOR_PROFILE_PATH + File.separator + path);){
                writer.write(json);
                ChatUtils.sendChatMessage(EnumChatFormatting.GREEN + path + EnumChatFormatting.DARK_GREEN + " color profile created successfully.");
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }
        catch (Exception e) {
            LogUtils.error(e);
        }
    }

    public static boolean loadColorConfig(String path) {
        String finalPath;
        if (!path.endsWith(".json")) {
            path = path + ".json";
        }
        if (!new File(finalPath = Main.COLOR_PROFILE_PATH + File.separator + path).exists()) {
            ChatUtils.sendChatMessage(EnumChatFormatting.RED + "Color profile not found, please select different one or create it.");
            return false;
        }
        Gson gson = new GsonBuilder().create();
        FileReader reader = null;
        try {
            reader = new FileReader(finalPath);
        }
        catch (FileNotFoundException e) {
            LogUtils.error(e);
            ChatUtils.sendChatMessage("\u00a74 THIS SHOULD NEVER HAVE HAPPENED... (ConfigUtils 123)");
            return false;
        }
        JsonObject data = gson.fromJson((Reader)reader, JsonObject.class);
        for (String key : keys) {
            try {
                switch (key) {
                    case "startTextToggle": 
                    case "exitTextToggle": 
                    case "interactTextToggle": 
                    case "itemTextToggle": 
                    case "batTextToggle": 
                    case "etherwarpsTextToggle": 
                    case "minesTextToggle": 
                    case "interactsTextToggle": 
                    case "superboomsTextToggle": 
                    case "enderpearlTextToggle": 
                    case "etherwarpFullBlock": 
                    case "mineFullBlock": 
                    case "superboomsFullBlock": 
                    case "enderpearlFullBlock": 
                    case "interactsFullBlock": 
                    case "secretsItemFullBlock": 
                    case "secretsInteractFullBlock": 
                    case "secretsBatFullBlock": 
                    case "renderEtherwarps ": 
                    case "renderMines": 
                    case "renderInteracts": 
                    case "renderSuperboom": 
                    case "renderEnderpearls": 
                    case "renderSecretsItem": 
                    case "renderSecretIteract": 
                    case "renderSecretBat": {
                        SRMConfig.class.getDeclaredField(key).setBoolean(null, data.has(key) && data.get(key).getAsBoolean());
                        break;
                    }
                    case "startWaypointColorIndex": 
                    case "exitWaypointColorIndex": 
                    case "interactWaypointColorIndex": 
                    case "itemWaypointColorIndex": 
                    case "batWaypointColorIndex": 
                    case "etherwarpsWaypointColorIndex": 
                    case "minesWaypointColorIndex": 
                    case "interactsWaypointColorIndex": 
                    case "superboomsWaypointColorIndex": 
                    case "enderpearlWaypointColorIndex": {
                        SRMConfig.class.getDeclaredField(key).setInt(null, data.has(key) ? data.get(key).getAsInt() : 0);
                        break;
                    }
                    case "startTextSize": 
                    case "exitTextSize": 
                    case "interactTextSize": 
                    case "itemTextSize": 
                    case "batTextSize": 
                    case "etherwarpsTextSize": 
                    case "minesTextSize": 
                    case "interactsTextSize": 
                    case "superboomsTextSize": 
                    case "enderpearlTextSize": {
                        SRMConfig.class.getDeclaredField(key).setFloat(null, data.has(key) ? data.get(key).getAsFloat() : 3.0f);
                        break;
                    }
                    case "lineColor": 
                    case "etherWarp": 
                    case "mine": 
                    case "interacts": 
                    case "superbooms": 
                    case "enderpearls": 
                    case "secretsItem": 
                    case "secretsInteract": 
                    case "secretsBat": 
                    case "pearlLineColor": {
                        SRMConfig.class.getDeclaredField(key).set(null, data.has(key) ? ConfigUtils.parseOneColor(data.get(key)) : new OneColor(255, 255, 255));
                    }
                }
            }
            catch (Exception e) {
                LogUtils.error(e);
            }
        }
        return true;
    }

    public static OneColor parseOneColor(JsonElement json) {
        JsonObject jsonObject = json.getAsJsonObject();
        JsonArray hsba = jsonObject.getAsJsonArray("hsba");
        int hue = hsba.get(0).getAsInt();
        int saturation = hsba.get(1).getAsInt();
        int brightness = hsba.get(2).getAsInt();
        int alpha = hsba.get(3).getAsInt();
        int chromaSpeed = jsonObject.get("dataBit").getAsInt();
        return new OneColor(hue, saturation, brightness, alpha, chromaSpeed);
    }
}

