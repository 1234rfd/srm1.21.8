/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.BlockPos
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 *  net.minecraftforge.fml.common.gameevent.InputEvent$MouseInputEvent
 *  org.lwjgl.input.Mouse
 */
package xyz.yourboykyle.secretroutes.events;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Mouse;
import xyz.yourboykyle.secretroutes.Main;
import xyz.yourboykyle.secretroutes.config.SRMConfig;
import xyz.yourboykyle.secretroutes.utils.LogUtils;
import xyz.yourboykyle.secretroutes.utils.Room;

public class OnMouseInput {
    @SubscribeEvent
    public void onMouseInput(InputEvent.MouseInputEvent e) {
        int button = Mouse.getEventButton();
        boolean action = Mouse.getEventButtonState();
        try {
            if (action) {
                EntityPlayerSP player = Minecraft.func_71410_x().field_71439_g;
                if (player == null) {
                    return;
                }
                ItemStack item = player.func_70694_bm();
                if (item == null) {
                    return;
                }
                if (item.func_82833_r().toLowerCase().contains("ender pearl") && button == 1) {
                    LogUtils.info("\u00a7bPlayer is holding an ender pearl");
                    if (Main.routeRecording.recording) {
                        Main.routeRecording.addWaypoint(Room.WAYPOINT_TYPES.ENDERPEARLS, (EntityPlayer)player);
                    }
                }
                if (item.func_82833_r().toLowerCase().contains("boom")) {
                    LogUtils.info("\u00a7bPlayer is holding a superboom");
                    if (Main.routeRecording.recording) {
                        Main.routeRecording.addWaypoint(Room.WAYPOINT_TYPES.TNTS, (EntityPlayer)player);
                    }
                }
                if (item.func_82833_r().toLowerCase().contains("aspect of the void") && button == 1 && player.func_70093_af()) {
                    LogUtils.info("\u00a7bPlayer is holding an aspect of the void");
                    if (Main.routeRecording.recording) {
                        new Thread(() -> {
                            try {
                                BlockPos pos = new BlockPos(player.field_70165_t, player.field_70163_u, player.field_70161_v);
                                try {
                                    Thread.sleep(SRMConfig.etherwarpPing);
                                }
                                catch (InterruptedException ex) {
                                    LogUtils.error(ex);
                                }
                                BlockPos pos2 = new BlockPos(player.field_70165_t, player.field_70163_u, player.field_70161_v);
                                if (!pos.toString().equals(pos2.toString())) {
                                    LogUtils.info("\u00a7bPlayer teleported and moved");
                                    Main.routeRecording.addWaypoint(Room.WAYPOINT_TYPES.ETHERWARPS, pos2);
                                } else {
                                    LogUtils.info("\u00a7bPlayer teleported and did not move");
                                }
                            }
                            catch (Exception ex) {
                                LogUtils.error(ex);
                            }
                        }).start();
                    }
                }
            }
        }
        catch (Exception ex) {
            LogUtils.error(ex);
        }
    }
}

