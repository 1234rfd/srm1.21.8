/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.FontRenderer
 *  net.minecraft.client.gui.ScaledResolution
 *  net.minecraft.client.renderer.GlStateManager
 */
package xyz.yourboykyle.secretroutes.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import xyz.yourboykyle.secretroutes.utils.Constants;
import xyz.yourboykyle.secretroutes.utils.LogUtils;

public class GuiUitls {
    public static void displayText(String text, float posx, float posy, float scale) {
        try {
            FontRenderer fr = Minecraft.func_71410_x().field_71466_p;
            ScaledResolution scaledResolution = new ScaledResolution(Minecraft.func_71410_x());
            int screenWidth = scaledResolution.func_78326_a();
            int screenHeight = scaledResolution.func_78328_b();
            int textWidth = fr.func_78256_a(text);
            float x = (float)screenWidth / 2.0f - (float)textWidth * scale / 2.0f + posx;
            float y = (float)screenHeight / 2.0f + posy;
            GlStateManager.func_179094_E();
            GlStateManager.func_179147_l();
            GlStateManager.func_179097_i();
            GlStateManager.func_179109_b((float)x, (float)y, (float)Constants.zPos);
            GlStateManager.func_179152_a((float)scale, (float)scale, (float)1.0f);
            fr.func_175065_a(text, 0.0f, 0.0f, 0xFFFFFF, true);
            GlStateManager.func_179126_j();
            GlStateManager.func_179084_k();
            GlStateManager.func_179121_F();
        }
        catch (Exception e) {
            LogUtils.error(e);
        }
    }
}

