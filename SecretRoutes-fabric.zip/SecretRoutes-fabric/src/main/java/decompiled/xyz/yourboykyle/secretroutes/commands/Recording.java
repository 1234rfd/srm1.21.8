/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.command.CommandBase
 *  net.minecraft.command.CommandException
 *  net.minecraft.command.ICommandSender
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumChatFormatting
 */
package xyz.yourboykyle.secretroutes.commands;

import net.minecraft.client.Minecraft;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumChatFormatting;
import xyz.yourboykyle.secretroutes.Main;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.dungeons.catacombs.RoomDetection;
import xyz.yourboykyle.secretroutes.utils.ChatUtils;
import xyz.yourboykyle.secretroutes.utils.LogUtils;
import xyz.yourboykyle.secretroutes.utils.Room;

public class Recording
extends CommandBase {
    public String func_71517_b() {
        return "recording";
    }

    public String func_71518_a(ICommandSender sender) {
        return "/recording start|stop|export|getroom|setbat|setexit|import <filename.json>";
    }

    public void func_71515_b(ICommandSender sender, String[] args) throws CommandException {
        if (args.length == 0) {
            Main.config.openGui();
        }
        if (args[0].equalsIgnoreCase("start")) {
            Main.routeRecording.startRecording();
        } else if (args[0].equalsIgnoreCase("stop")) {
            Main.routeRecording.stopRecording();
        } else if (args[0].equalsIgnoreCase("export")) {
            Main.routeRecording.exportAllRoutes();
        } else if (args[0].equalsIgnoreCase("getroom")) {
            ChatUtils.sendChatMessage(EnumChatFormatting.BLUE + "Room Name: " + RoomDetection.roomName + ", Room Corner: " + RoomDetection.roomCorner + ", Room Direction: " + RoomDetection.roomDirection);
        } else if (args[0].equalsIgnoreCase("setbat")) {
            if (Main.routeRecording.recording) {
                BlockPos playerPos = Minecraft.func_71410_x().field_71439_g.func_180425_c();
                BlockPos targetPos = new BlockPos(playerPos.func_177958_n(), playerPos.func_177956_o(), playerPos.func_177952_p());
                targetPos = targetPos.func_177982_a(-1, 2, -1);
                Main.routeRecording.addWaypoint(Room.SECRET_TYPES.BAT, targetPos);
                Main.routeRecording.newSecret();
                Main.routeRecording.setRecordingMessage("Added bat secret waypoint.");
            } else {
                ChatUtils.sendChatMessage(EnumChatFormatting.RED + "Route recording is not enabled. Run /recording start");
            }
        } else if (args[0].equalsIgnoreCase("setexit")) {
            if (Main.routeRecording.recording) {
                BlockPos playerPos = Minecraft.func_71410_x().field_71439_g.func_180425_c();
                BlockPos targetPos = new BlockPos(playerPos.func_177958_n(), playerPos.func_177956_o(), playerPos.func_177952_p());
                targetPos = targetPos.func_177982_a(-1, 0, -1);
                Main.routeRecording.addWaypoint(Room.SECRET_TYPES.EXITROUTE, targetPos);
                Main.routeRecording.newSecret();
                Main.routeRecording.stopRecording();
                Main.routeRecording.setRecordingMessage("Added route exit waypoint & stopped recording.");
                LogUtils.info("Added route exit waypoint & stopped recording.");
            } else {
                ChatUtils.sendChatMessage(EnumChatFormatting.RED + "Route recording is not enabled. Run /recording start");
            }
        } else if (args[0].equalsIgnoreCase("import")) {
            if (args.length != 2) {
                ChatUtils.sendChatMessage(EnumChatFormatting.RED + "Usage: /recording import <filename.json>");
            } else {
                Main.routeRecording.importRoutes(args[1]);
                ChatUtils.sendChatMessage(EnumChatFormatting.DARK_GREEN + "Imported routes from " + EnumChatFormatting.GREEN + args[1]);
            }
        } else {
            ChatUtils.sendChatMessage(EnumChatFormatting.RED + "Usage: " + this.func_71518_a(sender));
        }
    }

    public int func_82362_a() {
        return 0;
    }
}

