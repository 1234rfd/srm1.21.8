/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package xyz.yourboykyle.secretroutes.events;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import xyz.yourboykyle.secretroutes.events.ServerTickEvent;

public class OnServerTick {
    public static int ticks = 0;

    @SubscribeEvent
    public void onServerTick(ServerTickEvent event) {
        if (!event.modid.equals("secretroutesmod")) {
            return;
        }
        ++ticks;
    }
}

