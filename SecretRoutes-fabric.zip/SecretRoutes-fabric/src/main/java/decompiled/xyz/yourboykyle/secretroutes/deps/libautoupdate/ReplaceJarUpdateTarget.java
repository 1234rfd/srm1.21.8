/*
 * Decompiled with CFR 0.152.
 */
package xyz.yourboykyle.secretroutes.deps.libautoupdate;

import java.io.File;
import java.util.Arrays;
import java.util.List;
import xyz.yourboykyle.secretroutes.deps.libautoupdate.PotentialUpdate;
import xyz.yourboykyle.secretroutes.deps.libautoupdate.UpdateAction;
import xyz.yourboykyle.secretroutes.deps.libautoupdate.UpdateTarget;

public final class ReplaceJarUpdateTarget
implements UpdateTarget {
    private final File file;

    @Override
    public List<UpdateAction> generateUpdateActions(PotentialUpdate update) {
        return Arrays.asList(new UpdateAction.DeleteFile(this.file), new UpdateAction.MoveDownloadedFile(update.getUpdateJarStorage(), this.file));
    }

    public ReplaceJarUpdateTarget(File file) {
        this.file = file;
    }

    public File getFile() {
        return this.file;
    }

    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof ReplaceJarUpdateTarget)) {
            return false;
        }
        ReplaceJarUpdateTarget other = (ReplaceJarUpdateTarget)o;
        File this$file = this.getFile();
        File other$file = other.getFile();
        return !(this$file == null ? other$file != null : !((Object)this$file).equals(other$file));
    }

    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        File $file = this.getFile();
        result = result * 59 + ($file == null ? 43 : ((Object)$file).hashCode());
        return result;
    }

    public String toString() {
        return "ReplaceJarUpdateTarget(file=" + this.getFile() + ")";
    }
}

