/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.command.CommandBase
 *  net.minecraft.command.CommandException
 *  net.minecraft.command.ICommandSender
 *  net.minecraft.util.BlockPos
 */
package xyz.yourboykyle.secretroutes.commands;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.BlockPos;
import xyz.yourboykyle.secretroutes.Main;

public class SRM
extends CommandBase {
    public String func_71517_b() {
        return "srm";
    }

    public String func_71518_a(ICommandSender sender) {
        return "/srm";
    }

    public void func_71515_b(ICommandSender sender, String[] args) throws CommandException {
        Main.config.openGui();
    }

    public int func_82362_a() {
        return 0;
    }

    public List<String> func_71514_a() {
        ArrayList<String> aliases = new ArrayList<String>();
        aliases.add("secretroutes");
        aliases.add("secretroutesmod");
        return aliases;
    }

    public List<String> func_180525_a(ICommandSender sender, String[] args, BlockPos pos) {
        ArrayList<String> completions = new ArrayList<String>();
        completions.add("General");
        completions.add("RouteRecording");
        completions.add("HUD");
        completions.add("Rendering");
        completions.add("Dev");
        completions.add("Keybinds");
        completions.removeIf(completion -> args.length > 0 && !completion.toLowerCase().startsWith(args[0].toLowerCase()));
        return completions;
    }
}

