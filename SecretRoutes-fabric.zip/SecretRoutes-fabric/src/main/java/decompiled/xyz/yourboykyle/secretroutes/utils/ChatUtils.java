/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.event.ClickEvent
 *  net.minecraft.event.ClickEvent$Action
 *  net.minecraft.event.HoverEvent
 *  net.minecraft.event.HoverEvent$Action
 *  net.minecraft.util.ChatComponentText
 *  net.minecraft.util.ChatStyle
 *  net.minecraft.util.EnumChatFormatting
 *  net.minecraft.util.IChatComponent
 */
package xyz.yourboykyle.secretroutes.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.event.ClickEvent;
import net.minecraft.event.HoverEvent;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.ChatStyle;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.IChatComponent;
import xyz.yourboykyle.secretroutes.config.SRMConfig;
import xyz.yourboykyle.secretroutes.utils.LogUtils;

public class ChatUtils {
    public static void sendChatMessage(String message, EnumChatFormatting color) {
        if (Minecraft.func_71410_x().field_71439_g == null) {
            return;
        }
        Minecraft.func_71410_x().field_71439_g.func_145747_a(new ChatComponentText(message).func_150255_a(new ChatStyle().func_150238_a(color)));
        LogUtils.info("Sent chat message: " + message);
    }

    public static void sendChatMessage(String message) {
        if (Minecraft.func_71410_x().field_71439_g == null) {
            return;
        }
        Minecraft.func_71410_x().field_71439_g.func_145747_a((IChatComponent)new ChatComponentText(message));
        LogUtils.info("Sent chat message: " + message);
    }

    public static void sendVerboseMessage(String message) {
        if (SRMConfig.verboseLogging) {
            ChatUtils.sendChatMessage(message);
        }
    }

    public static boolean sendVerboseMessage(String message, String TAG) {
        if (Minecraft.func_71410_x().field_71439_g == null) {
            return false;
        }
        switch (TAG) {
            case "Recording": {
                if (SRMConfig.verboseRecording) {
                    ChatUtils.sendVerboseMessage("\u00a7d[Recording] " + message);
                    return true;
                }
                return false;
            }
            case "Update": {
                if (SRMConfig.verboseUpdating) {
                    ChatUtils.sendVerboseMessage("\u00a7d[Update] " + message);
                    return true;
                }
                return false;
            }
            case "Info": {
                if (SRMConfig.verboseInfo && !message.contains("Sent chat message")) {
                    ChatUtils.sendVerboseMessage("\u00a7d[Info] " + message);
                    return true;
                }
                return false;
            }
            case "Rendering": {
                if (SRMConfig.verboseRendering) {
                    ChatUtils.sendVerboseMessage("\u00a75[Rendering] " + message);
                    return true;
                }
                return false;
            }
            case "Actionbar": {
                if (SRMConfig.actionbarInfo) {
                    ChatUtils.sendVerboseMessage("\u00a73[ActionBar] \u00a7a " + message);
                    return true;
                }
                return false;
            }
        }
        ChatUtils.sendChatMessage("\u00a7d[" + TAG + "] " + message);
        return true;
    }

    public static void sendClickableMessage(String text, String link) {
        if (Minecraft.func_71410_x().field_71439_g == null) {
            return;
        }
        ChatComponentText component = new ChatComponentText(text);
        component.func_150256_b().func_150241_a(new ClickEvent(ClickEvent.Action.OPEN_URL, link));
        component.func_150256_b().func_150209_a(new HoverEvent(HoverEvent.Action.SHOW_TEXT, (IChatComponent)new ChatComponentText("Click to open link")));
        Minecraft.func_71410_x().field_71439_g.func_145747_a((IChatComponent)component);
    }
}

