/*
 * Decompiled with CFR 0.152.
 */
package xyz.yourboykyle.secretroutes.utils;

import xyz.yourboykyle.secretroutes.utils.ChatUtils;

public class PrintingUtils {
    public long lastPrinted = System.currentTimeMillis();

    public void print(String message, int delay) {
        long currentTime = System.currentTimeMillis();
        if (currentTime - this.lastPrinted > (long)delay) {
            ChatUtils.sendVerboseMessage(message);
            this.lastPrinted = currentTime;
        }
    }
}

