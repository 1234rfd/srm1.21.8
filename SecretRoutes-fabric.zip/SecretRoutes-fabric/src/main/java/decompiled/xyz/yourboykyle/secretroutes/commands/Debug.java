/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.command.CommandBase
 *  net.minecraft.command.ICommandSender
 *  net.minecraft.util.BlockPos
 */
package xyz.yourboykyle.secretroutes.commands;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.IllegalFormatException;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.BlockPos;
import xyz.yourboykyle.secretroutes.Main;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.dungeons.catacombs.RoomDetection;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.utils.MapUtils;
import xyz.yourboykyle.secretroutes.events.OnGuiRender;
import xyz.yourboykyle.secretroutes.utils.APIUtils;
import xyz.yourboykyle.secretroutes.utils.BlockUtils;
import xyz.yourboykyle.secretroutes.utils.ChatUtils;
import xyz.yourboykyle.secretroutes.utils.Constants;
import xyz.yourboykyle.secretroutes.utils.LogUtils;
import xyz.yourboykyle.secretroutes.utils.SecretUtils;

public class Debug
extends CommandBase {
    public String func_71517_b() {
        return "srmdebug";
    }

    public String func_71518_a(ICommandSender sender) {
        return "/srmdebug <option> <value>";
    }

    public void func_71515_b(ICommandSender sender, String[] args) {
        if (!sender.func_70005_c_().contains("_Wyan")) {
            ChatUtils.sendChatMessage("\u00a7eAre you sure you want to do this?");
        }
        if (args.length != 0) {
            try {
                switch (args[0].toLowerCase()) {
                    case "lever": {
                        ChatUtils.sendChatMessage("Relative :" + BlockUtils.blockPos(SecretUtils.currentLeverPos));
                        BlockPos abs = MapUtils.relativeToActual(SecretUtils.currentLeverPos, RoomDetection.roomDirection, RoomDetection.roomCorner);
                        ChatUtils.sendChatMessage("Abs: " + BlockUtils.blockPos(abs));
                        ChatUtils.sendChatMessage("Chest: " + SecretUtils.chestName);
                        ChatUtils.sendChatMessage("Lever: " + SecretUtils.leverName);
                        ChatUtils.sendChatMessage("Num: " + SecretUtils.leverNumber);
                        break;
                    }
                    case "pos": {
                        EntityPlayerSP p = Minecraft.func_71410_x().field_71439_g;
                        ChatUtils.sendChatMessage("Relative: " + p.func_180425_c());
                        ChatUtils.sendChatMessage("Abs: " + BlockUtils.blockPos(p.func_180425_c()));
                    }
                    case "bloodtime": {
                        if (args.length >= 2) {
                            try {
                                OnGuiRender.spawnNotifTime = System.currentTimeMillis() + Long.parseLong(args[1]);
                            }
                            catch (NumberFormatException e) {
                                ChatUtils.sendChatMessage("Please make sure the value is a number");
                            }
                            break;
                        }
                        OnGuiRender.spawnNotifTime = System.currentTimeMillis() + 3000L;
                        break;
                    }
                    case "cr": {
                        if (args.length >= 2) {
                            switch (args[1].toLowerCase()) {
                                case "f": {
                                    Main.currentRoom.currentSecretRoute = Main.currentRoom.arrays.get((Integer)Main.currentRoom.closest.getTwo() + 1);
                                }
                                case "b": {
                                    Main.currentRoom.currentSecretRoute = Main.currentRoom.arrays.get((Integer)Main.currentRoom.closest.getTwo() - 1);
                                }
                            }
                        }
                        ChatUtils.sendChatMessage("Current index: " + Main.currentRoom.closest.getTwo());
                        break;
                    }
                    case "apicall": {
                        APIUtils.addMember();
                        break;
                    }
                    case "var": {
                        if (args.length == 1) {
                            ChatUtils.sendChatMessage("Missing argument after \"var\"");
                            break;
                        }
                        try {
                            Field field = Constants.class.getDeclaredField(args[1]);
                            String type = field.getAnnotatedType().getType().getTypeName();
                            field.setAccessible(true);
                            Object currentValue = field.get(null);
                            if (args.length == 2) {
                                ChatUtils.sendChatMessage("\u00a7b" + args[1] + ": " + currentValue);
                                break;
                            }
                            switch (type) {
                                case "int": {
                                    field.set(null, Integer.valueOf(args[2]));
                                    break;
                                }
                                case "float": {
                                    field.set(null, Float.valueOf(args[2]));
                                    break;
                                }
                                case "boolean": {
                                    field.set(null, Boolean.valueOf(args[2]));
                                    break;
                                }
                                case "double": {
                                    field.set(null, Double.valueOf(args[2]));
                                    break;
                                }
                                case "String": {
                                    field.set(null, args[2]);
                                }
                            }
                            ChatUtils.sendChatMessage("\u00a7bChanged [" + args[1] + "] from " + currentValue + " to " + args[2]);
                            break;
                        }
                        catch (NoSuchFieldException e) {
                            ChatUtils.sendChatMessage("\u00a7cInvalid argument: " + args[1]);
                            break;
                        }
                        catch (IllegalAccessException e) {
                            ChatUtils.sendChatMessage("\u00a7cIllegal access (Most likely private");
                            LogUtils.error(e);
                            break;
                        }
                        catch (IllegalFormatException e) {
                            ChatUtils.sendChatMessage("\u00a7cWrong type");
                            LogUtils.error(e);
                            break;
                        }
                        catch (Exception e) {
                            LogUtils.error(e);
                            ChatUtils.sendChatMessage("\u00a7cSomething went wrong... Command [/srmdebug " + args[1] + " " + args[2] + "]");
                        }
                    }
                }
            }
            catch (Exception e) {
                LogUtils.error(e);
            }
        }
    }

    public int func_82362_a() {
        return 0;
    }

    public List<String> func_180525_a(ICommandSender sender, String[] args, BlockPos pos) {
        ArrayList<String> completions = new ArrayList<String>();
        ArrayList<String> basicOptions = new ArrayList<String>();
        basicOptions.add("lever");
        basicOptions.add("pos");
        basicOptions.add("var");
        basicOptions.add("bloodTime");
        basicOptions.add("cr");
        switch (args.length) {
            case 0: {
                completions.addAll(basicOptions);
            }
            case 1: {
                completions.addAll(basicOptions);
                completions.removeIf(completion -> !completion.toLowerCase().startsWith(args[0].toLowerCase()));
            }
            case 2: {
                try {
                    switch (args[0].toLowerCase()) {
                        case "lever": 
                        case "pos": 
                        case "bloodtime": 
                        case "cr": {
                            break;
                        }
                        case "var": {
                            Field[] fields;
                            if (args.length == 1) {
                                return completions;
                            }
                            for (Field field : fields = Constants.class.getDeclaredFields()) {
                                if (!field.getName().toLowerCase().startsWith(args[1].toLowerCase())) continue;
                                completions.add(field.getName());
                            }
                            break;
                        }
                    }
                    break;
                }
                catch (Exception e) {
                    ChatUtils.sendChatMessage("Error happened again");
                    e.printStackTrace();
                }
            }
        }
        return completions;
    }
}

