/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.util.EnumChatFormatting
 */
package xyz.yourboykyle.secretroutes.utils;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import net.minecraft.client.Minecraft;
import net.minecraft.util.EnumChatFormatting;
import xyz.yourboykyle.secretroutes.Main;
import xyz.yourboykyle.secretroutes.utils.ChatUtils;

public class LogUtils {
    public static void info(String msg) {
        if (!ChatUtils.sendVerboseMessage(msg, "Info")) {
            LogUtils.appendToFile("====================\n[INFO] " + msg);
        }
    }

    public static void error(Exception error) {
        LogUtils.errorNoShout(error);
        if (Minecraft.func_71410_x().field_71439_g != null) {
            ChatUtils.sendChatMessage(EnumChatFormatting.DARK_RED + "Error caught by Secret Routes. Check latest logs at .minecraft/logs/SecretRoutes/LATEST-{date}.log. SEND THIS FILE IN #SUPPORT IN THE DISCORD FOR HELP. (" + error.getLocalizedMessage() + ")");
        }
    }

    public static void errorNoShout(Exception error) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        error.printStackTrace(pw);
        String stackTrace = sw.toString();
        LogUtils.appendToFile("====================\n[ERROR] " + stackTrace);
    }

    public static void appendToFile(String msg) {
        try {
            FileWriter fw = new FileWriter(Main.outputLogs, true);
            fw.write(msg + "\n");
            fw.close();
        }
        catch (Exception e) {
            System.out.println("Secret Routes Logging Exception:");
            e.printStackTrace();
        }
    }
}

