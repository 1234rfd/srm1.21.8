/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.audio.ISound
 *  net.minecraft.client.multiplayer.WorldClient
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Items
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.ChatComponentText
 *  net.minecraft.util.IChatComponent
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.world.World
 *  net.minecraftforge.client.event.sound.PlaySoundEvent
 *  net.minecraftforge.event.world.BlockEvent$BreakEvent
 *  net.minecraftforge.fml.common.eventhandler.EventPriority
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package xyz.yourboykyle.secretroutes.events;

import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.ISound;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;
import net.minecraftforge.client.event.sound.PlaySoundEvent;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import xyz.yourboykyle.secretroutes.Main;
import xyz.yourboykyle.secretroutes.events.OnBlockBreak;
import xyz.yourboykyle.secretroutes.utils.LogUtils;
import xyz.yourboykyle.secretroutes.utils.Room;

public class OnPlaySound {
    @SubscribeEvent(receiveCanceled=true, priority=EventPriority.HIGHEST)
    public void onPlaySound(PlaySoundEvent e) {
        ISound sound = e.sound;
        if (sound != null && sound.func_147650_b() != null) {
            String soundType;
            String afterColon;
            String[] subparts;
            String[] parts;
            if (sound.func_147650_b().equals((Object)new ResourceLocation("mob.enderdragon.hit")) && Main.routeRecording.recording && Minecraft.func_71410_x().field_71439_g.func_70093_af() && Minecraft.func_71410_x().field_71439_g.func_70694_bm().func_77973_b() == Items.field_151047_v) {
                new Thread(() -> {
                    try {
                        Minecraft.func_71410_x().field_71439_g.func_145747_a((IChatComponent)new ChatComponentText("Detected etherwarp! Please wait 0.5 seconds before continuing the route..."));
                        Main.routeRecording.setRecordingMessage("Detected etherwarp! Please wait 0.5 seconds before continuing the route...");
                        Thread.sleep(500L);
                        BlockPos playerPos = Minecraft.func_71410_x().field_71439_g.func_180425_c();
                        BlockPos targetPos = new BlockPos(playerPos.func_177958_n(), playerPos.func_177956_o(), playerPos.func_177952_p());
                        targetPos = targetPos.func_177982_a(-1, -1, -1);
                        Main.routeRecording.addWaypoint(Room.WAYPOINT_TYPES.ETHERWARPS, targetPos);
                        Main.routeRecording.setRecordingMessage("Etherwarp recorded! You may continue the route.");
                    }
                    catch (InterruptedException ex) {
                        LogUtils.error(ex);
                        BlockPos playerPos = Minecraft.func_71410_x().field_71439_g.func_180425_c();
                        BlockPos targetPos = new BlockPos(playerPos.func_177958_n(), playerPos.func_177956_o(), playerPos.func_177952_p());
                        targetPos = targetPos.func_177982_a(-1, -1, -1);
                        Main.routeRecording.addWaypoint(Room.WAYPOINT_TYPES.ETHERWARPS, targetPos);
                        Main.routeRecording.setRecordingMessage("Etherwarp recorded! You may continue the route.");
                    }
                }).start();
            }
            if ((parts = sound.func_147650_b().toString().split(":", 2)).length > 1 && (subparts = (afterColon = parts[1]).split("\\.", 2)).length > 0 && (soundType = subparts[0]).equals("dig")) {
                BlockPos pos = new BlockPos((double)sound.func_147649_g(), (double)sound.func_147654_h(), (double)sound.func_147651_i());
                WorldClient world = Minecraft.func_71410_x().field_71441_e;
                IBlockState blockState = world.func_180495_p(pos);
                new OnBlockBreak().onBlockBreak(new BlockEvent.BreakEvent((World)world, pos, blockState, (EntityPlayer)Minecraft.func_71410_x().field_71439_g));
            }
        }
    }
}

