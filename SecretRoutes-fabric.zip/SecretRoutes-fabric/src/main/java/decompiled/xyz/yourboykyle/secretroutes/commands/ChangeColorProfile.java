/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.command.CommandBase
 *  net.minecraft.command.CommandException
 *  net.minecraft.command.ICommandSender
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumChatFormatting
 */
package xyz.yourboykyle.secretroutes.commands;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumChatFormatting;
import xyz.yourboykyle.secretroutes.Main;
import xyz.yourboykyle.secretroutes.utils.ChatUtils;
import xyz.yourboykyle.secretroutes.utils.ConfigUtils;
import xyz.yourboykyle.secretroutes.utils.FileUtils;

public class ChangeColorProfile
extends CommandBase {
    List<String> aliases = new ArrayList<String>();
    public boolean loadDefault = false;

    public String func_71517_b() {
        return "changecolorprofile";
    }

    public String func_71518_a(ICommandSender sender) {
        return "/changecolorprofile [list|load|save] [profile]";
    }

    public void func_71515_b(ICommandSender sender, String[] args) throws CommandException {
        if (args.length == 0) {
            Main.config.openGui();
        } else if (args.length == 1) {
            if (args[0].equals("list")) {
                ChatUtils.sendChatMessage(EnumChatFormatting.DARK_AQUA + "Color Profiles:");
                for (String profile : FileUtils.getFileNames(Main.COLOR_PROFILE_PATH)) {
                    ChatUtils.sendChatMessage(EnumChatFormatting.AQUA + " - " + profile);
                }
            } else if (args[0].equals("load")) {
                if (!this.loadDefault) {
                    ChatUtils.sendChatMessage(EnumChatFormatting.RED + "Incorrect usage: /changecolorprofile load [profile]. Run again to load default");
                    this.loadDefault = true;
                } else {
                    ChatUtils.sendChatMessage(EnumChatFormatting.DARK_GREEN + "Loaded default color profile");
                }
            } else if (args[0].equals("save")) {
                ChatUtils.sendChatMessage(EnumChatFormatting.RED + "Incorrect usage: /changecolorprofile save [profile]");
            } else {
                ChatUtils.sendChatMessage(EnumChatFormatting.RED + "Incorrect usage: /changecolorprofile [list|load|save] [profile]");
            }
        } else if (args.length == 2) {
            if (args[0].equals("load")) {
                if (ConfigUtils.loadColorConfig(args[1])) {
                    ChatUtils.sendChatMessage(EnumChatFormatting.DARK_GREEN + "Loaded " + EnumChatFormatting.GREEN + args[1] + EnumChatFormatting.DARK_GREEN + " as color profile");
                }
            } else if (args[0].equals("save")) {
                ConfigUtils.writeColorConfig(args[1]);
            } else {
                ChatUtils.sendChatMessage(EnumChatFormatting.RED + "Incorrect usage: /changecolorprofile [list|load|save] [profile]");
            }
        }
    }

    public int func_82362_a() {
        return 0;
    }

    public List<String> func_71514_a() {
        ArrayList<String> aliases = new ArrayList<String>();
        aliases.add("ccp");
        aliases.add("changeclrp");
        aliases.add("changecolourprofile");
        return aliases;
    }

    public List<String> func_180525_a(ICommandSender sender, String[] args, BlockPos pos) {
        ArrayList<String> completions = new ArrayList<String>();
        ArrayList<String> basicOptions = new ArrayList<String>();
        basicOptions.add("list");
        basicOptions.add("load");
        basicOptions.add("save");
        switch (args.length) {
            case 0: {
                completions.addAll(basicOptions);
            }
            case 1: {
                completions.addAll(basicOptions);
                completions.removeIf(completion -> !completion.toLowerCase().startsWith(args[0].toLowerCase()));
            }
            case 2: {
                if (args[0].equalsIgnoreCase("load")) {
                    completions.addAll(FileUtils.getFileNames(Main.COLOR_PROFILE_PATH));
                }
            }
            case 3: {
                if (!args[0].equalsIgnoreCase("load")) break;
                completions.addAll(FileUtils.getFileNames(Main.COLOR_PROFILE_PATH));
                completions.removeIf(completion -> !completion.toLowerCase().startsWith(args[1].toLowerCase()));
            }
        }
        return completions;
    }
}

