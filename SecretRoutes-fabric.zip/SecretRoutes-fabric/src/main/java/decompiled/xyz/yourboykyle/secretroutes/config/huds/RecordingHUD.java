/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  cc.polyfrost.oneconfig.config.annotations.Color
 *  cc.polyfrost.oneconfig.config.core.OneColor
 *  cc.polyfrost.oneconfig.hud.SingleTextHud
 */
package xyz.yourboykyle.secretroutes.config.huds;

import cc.polyfrost.oneconfig.config.annotations.Color;
import cc.polyfrost.oneconfig.config.core.OneColor;
import cc.polyfrost.oneconfig.hud.SingleTextHud;
import xyz.yourboykyle.secretroutes.Main;

public class RecordingHUD
extends SingleTextHud {
    @Color(name="Default HUD colour")
    public static OneColor hudColour = new OneColor(255, 255, 255);

    public RecordingHUD() {
        super("", false);
    }

    public String getText(boolean example) {
        if (Main.routeRecording.recording) {
            return Main.routeRecording.recordingMessage;
        }
        return "";
    }

    public void enable() {
        this.enabled = true;
    }

    public void disable() {
        this.enabled = false;
    }
}

