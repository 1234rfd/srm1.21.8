package xyz.yourboykyle.secretroutes;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.File;
import xyz.yourboykyle.secretroutes.utils.ConfigUtils;
import xyz.yourboykyle.secretroutes.utils.RouteUtils;

public class MainFabric implements ClientModInitializer {
    public static final String MODID = "secretroutesmod";
    public static final String NAME = "SecretRoutes";
    public static final String VERSION = "0.4.16";

    public static final Logger LOGGER = LoggerFactory.getLogger(NAME);

    public static final File CONFIG_DIR = FabricLoader.getInstance()
            .getConfigDir()
            .resolve("SecretRoutes")
            .toFile();

    private static KeyBinding exampleKeybind;

    @Override
    public void onInitializeClient() {
        LOGGER.info("{} v{} initializing (Fabric).", NAME, VERSION);

        try {
            if (!CONFIG_DIR.exists()) {
                CONFIG_DIR.mkdirs();
            }

            ConfigUtils.loadConfigs(CONFIG_DIR);

            exampleKeybind = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                    "key.secretroutes.toggle",
                    InputUtil.Type.KEYSYM,
                    InputUtil.fromKeycode(32, 0),
                    "category.secretroutes"
            ));

            ClientTickEvents.END_CLIENT_TICK.register(client -> {
                try {
                    this.onClientTick(client);
                } catch (Throwable t) {
                    LOGGER.error("Error in client tick handler", t);
                }
            });

            HudRenderCallback.EVENT.register((matrices, tickDelta) -> {
                try {
                    this.renderHUD(MinecraftClient.getInstance(), tickDelta);
                } catch (Throwable t) {
                    LOGGER.error("Error rendering HUD", t);
                }
            });

            RouteUtils.init(CONFIG_DIR);

            LOGGER.info("{} initialized successfully.", NAME);
        } catch (Exception e) {
            LOGGER.error("Failed to initialize SecretRoutes (Fabric):", e);
        }
    }

    private void onClientTick(MinecraftClient client) {
        while (exampleKeybind.wasPressed()) {
            if (client.player != null) {
                client.player.sendMessage(Text.literal("SecretRoutes: key pressed"), false);
            }
        }
    }

    private void renderHUD(MinecraftClient client, float tickDelta) {
        // TODO: call into your HUD classes
    }
}
