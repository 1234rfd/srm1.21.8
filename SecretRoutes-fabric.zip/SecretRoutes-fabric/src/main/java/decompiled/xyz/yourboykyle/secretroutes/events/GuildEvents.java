/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.client.event.ClientChatReceivedEvent
 *  net.minecraftforge.fml.common.eventhandler.EventPriority
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package xyz.yourboykyle.secretroutes.events;

import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import xyz.yourboykyle.secretroutes.config.SRMConfig;
import xyz.yourboykyle.secretroutes.utils.ChatUtils;

public class GuildEvents {
    private static final String[] formats = new String[]{"\u00a7a", "\u00a7b", "\u00a7c", "\u00a7d", "\u00a7e", "\u00a7f", "\u00a71", "\u00a72", "\u00a73", "\u00a74", "\u00a75", "\u00a76", "\u00a77", "\u00a78", "\u00a79", "\u00a70", "\u00a7k", "\u00a7l", "\u00a7m", "\u00a7n", "\u00a7o", "\u00a7r"};
    private static String[] ranks = new String[0];
    private static final String SEARCH = "\u00a72Guild > \u00a7a[VIP\u00a76+\u00a7a] SRMBridge";

    public String cleanMessage(String message) {
        for (String format : formats) {
            message = message.replace(format, "");
        }
        return message;
    }

    @SubscribeEvent(priority=EventPriority.HIGH)
    public void OnChatReceived(ClientChatReceivedEvent e) {
        if (e.type == 2 || !SRMConfig.bridge) {
            return;
        }
        String message = e.message.func_150260_c();
        System.out.println("Message: " + message);
        if (message.contains(SEARCH)) {
            String tmp = message.split(":")[1];
            String sec1 = tmp.substring(0, tmp.indexOf("\u00bb") - 1).replaceFirst("\u00bb", ":");
            String sec2 = tmp.substring(tmp.indexOf("\u00bb") + 1);
            ChatUtils.sendChatMessage("\u00a72Bridge >\u00a7b" + sec1 + "\u00a7r:" + sec2);
            e.setCanceled(true);
        }
    }
}

