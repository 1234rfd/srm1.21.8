/*
 * Decompiled with CFR 0.152.
 */
package xyz.yourboykyle.secretroutes.events;

import xyz.yourboykyle.secretroutes.Main;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.dungeons.catacombs.RoomDetection;
import xyz.yourboykyle.secretroutes.utils.ChatUtils;
import xyz.yourboykyle.secretroutes.utils.PBUtils;
import xyz.yourboykyle.secretroutes.utils.SecretSounds;

public class OnSecretComplete {
    public static void onSecretCompleteNoKeybind() {
        SecretSounds.secretChime();
        if (Main.currentRoom.currentSecretIndex == 0) {
            ChatUtils.sendVerboseMessage("Starting timer for " + Main.currentRoom.name, "Personal Bests");
            PBUtils.pbIsValid = true;
            PBUtils.startRoute();
        } else if (Main.currentRoom.currentSecretIndex == Main.currentRoom.currentSecretRoute.size() - 1) {
            ChatUtils.sendVerboseMessage("Stopping timer for " + Main.currentRoom.name, "Personal Bests");
            PBUtils.stopRoute();
        }
        if (Main.currentRoom.currentSecretIndex <= Main.currentRoom.currentSecretRoute.size() - 1) {
            ChatUtils.sendVerboseMessage("Secret " + (Main.currentRoom.currentSecretIndex + 1) + "/" + Main.currentRoom.currentSecretRoute.size() + " in " + RoomDetection.roomName + " completed in \u00a7a" + (Main.currentRoom.currentSecretIndex > 0 ? PBUtils.formatTime(System.currentTimeMillis() - PBUtils.startTime) : "0.000s") + " \u00a7r(PB is valid: " + (PBUtils.pbIsValid ? "true" : "false") + ")", "Personal Bests");
        }
    }
}

