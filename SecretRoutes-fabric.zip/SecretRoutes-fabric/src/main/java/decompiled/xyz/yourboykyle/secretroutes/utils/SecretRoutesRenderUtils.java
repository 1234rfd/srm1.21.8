/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  cc.polyfrost.oneconfig.config.core.OneColor
 *  net.minecraft.client.Minecraft
 *  net.minecraft.util.AxisAlignedBB
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumChatFormatting
 */
package xyz.yourboykyle.secretroutes.utils;

import cc.polyfrost.oneconfig.config.core.OneColor;
import net.minecraft.client.Minecraft;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumChatFormatting;
import xyz.yourboykyle.secretroutes.config.SRMConfig;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.utils.WaypointUtils;
import xyz.yourboykyle.secretroutes.utils.Constants;
import xyz.yourboykyle.secretroutes.utils.RenderUtils;

public class SecretRoutesRenderUtils {
    public static void drawBoxAtBlock(double worldX, double worldY, double worldZ, OneColor color) {
        Minecraft mc = Minecraft.func_71410_x();
        double playerX = mc.func_175598_ae().field_78730_l;
        double playerY = mc.func_175598_ae().field_78731_m;
        double playerZ = mc.func_175598_ae().field_78728_n;
        double x = worldX - playerX;
        double y = worldY - playerY;
        double z = worldZ - playerZ;
        RenderUtils.drawBoxAtBlock(x, y, z, color, 1.0, 1.0, 1.0);
    }

    public static void drawBoxAtBlock(double worldX, double worldY, double worldZ, OneColor color, int width, int height) {
        Minecraft mc = Minecraft.func_71410_x();
        double playerX = mc.func_175598_ae().field_78730_l;
        double playerY = mc.func_175598_ae().field_78731_m;
        double playerZ = mc.func_175598_ae().field_78728_n;
        double x = worldX - playerX;
        double y = worldY - playerY;
        double z = worldZ - playerZ;
        RenderUtils.drawBoxAtBlock(x, y, z, color, width, height, 1.0);
    }

    public static void drawBoxAtBlock(double worldX, double worldY, double worldZ, OneColor color, double width, double height) {
        Minecraft mc = Minecraft.func_71410_x();
        double playerX = mc.func_175598_ae().field_78730_l;
        double playerY = mc.func_175598_ae().field_78731_m;
        double playerZ = mc.func_175598_ae().field_78728_n;
        double x = worldX - playerX;
        double y = worldY - playerY;
        double z = worldZ - playerZ;
        RenderUtils.drawBoxAtBlock(x, y, z, color, width, height, 1.0);
    }

    public static void drawBoxAtBlock(double worldX, double worldY, double worldZ, OneColor color, int width, int height, int alpha) {
        Minecraft mc = Minecraft.func_71410_x();
        double playerX = mc.func_175598_ae().field_78730_l;
        double playerY = mc.func_175598_ae().field_78731_m;
        double playerZ = mc.func_175598_ae().field_78728_n;
        double x = worldX - playerX;
        double y = worldY - playerY;
        double z = worldZ - playerZ;
        RenderUtils.drawBoxAtBlock(x, y, z, color, width, height, alpha);
    }

    public static void drawFilledBoxAtBlock(double worldX, double worldY, double worldZ, OneColor color) {
        Minecraft mc = Minecraft.func_71410_x();
        double playerX = mc.func_175598_ae().field_78730_l;
        double playerY = mc.func_175598_ae().field_78731_m;
        double playerZ = mc.func_175598_ae().field_78728_n;
        double x = worldX - playerX;
        double y = worldY - playerY;
        double z = worldZ - playerZ;
        boolean width = true;
        boolean height = true;
        WaypointUtils.drawFilledBoundingBox(new AxisAlignedBB(x - 0.01, y - 0.01, z - 0.01, x + (double)width + 0.01, y + (double)height + 0.01, z + (double)width + 0.01), color, 1.0f);
    }

    public static void drawFilledBoxAtBlock(double worldX, double worldY, double worldZ, OneColor color, int width, int height) {
        Minecraft mc = Minecraft.func_71410_x();
        double playerX = mc.func_175598_ae().field_78730_l;
        double playerY = mc.func_175598_ae().field_78731_m;
        double playerZ = mc.func_175598_ae().field_78728_n;
        double x = worldX - playerX;
        double y = worldY - playerY;
        double z = worldZ - playerZ;
        WaypointUtils.drawFilledBoundingBox(new AxisAlignedBB(x - 0.01, y - 0.01, z - 0.01, x + (double)width + 0.01, y + (double)height + 0.01, z + (double)width + 0.01), color, SRMConfig.alphaMultiplier);
    }

    public static void drawFilledBoxAtBlock(double worldX, double worldY, double worldZ, OneColor color, float width, float height) {
        Minecraft mc = Minecraft.func_71410_x();
        double playerX = mc.func_175598_ae().field_78730_l;
        double playerY = mc.func_175598_ae().field_78731_m;
        double playerZ = mc.func_175598_ae().field_78728_n;
        double x = worldX - playerX;
        double y = worldY - playerY;
        double z = worldZ - playerZ;
        WaypointUtils.drawFilledBoundingBox(new AxisAlignedBB(x - 0.01, y - 0.01, z - 0.01, x + (double)width + 0.01, y + (double)height + 0.01, z + (double)width + 0.01), color, SRMConfig.alphaMultiplier);
    }

    public static void drawFilledBoxAtBlock(double worldX, double worldY, double worldZ, OneColor color, int width, int height, float alpha) {
        Minecraft mc = Minecraft.func_71410_x();
        double playerX = mc.func_175598_ae().field_78730_l;
        double playerY = mc.func_175598_ae().field_78731_m;
        double playerZ = mc.func_175598_ae().field_78728_n;
        double x = worldX - playerX;
        double y = worldY - playerY;
        double z = worldZ - playerZ;
        WaypointUtils.drawFilledBoundingBox(new AxisAlignedBB(x - 0.01, y - 0.01, z - 0.01, x + (double)width + 0.01, y + (double)height + 0.01, z + (double)width + 0.01), color, alpha);
    }

    public static void drawBeaconBeam(double worldX, double worldY, double worldZ, int RGB, float alpha) {
        Minecraft mc = Minecraft.func_71410_x();
        double playerX = mc.func_175598_ae().field_78730_l;
        double playerY = mc.func_175598_ae().field_78731_m;
        double playerZ = mc.func_175598_ae().field_78728_n;
        double x = worldX - playerX;
        double y = worldY - playerY;
        double z = worldZ - playerZ;
        WaypointUtils.renderBeaconBeam(x, y, z, RGB, alpha, 0.0f);
    }

    public static void drawText(double worldX, double worldY, double worldZ, String text, float size, float partialTicks) {
        BlockPos pos = new BlockPos(worldX, worldY, worldZ);
        Minecraft mc = Minecraft.func_71410_x();
        double playerX = mc.func_175598_ae().field_78730_l;
        double playerY = mc.func_175598_ae().field_78731_m;
        double playerZ = mc.func_175598_ae().field_78728_n;
        double x = worldX - playerX;
        double y = worldY - playerY;
        double z = worldZ - playerZ;
        text = EnumChatFormatting.BOLD + text;
        RenderUtils.drawText(text, pos, partialTicks, false, Constants.shadows, Float.valueOf(size));
    }

    public static String getTextColor(int index) {
        switch (index) {
            case 0: {
                return EnumChatFormatting.BLACK.toString();
            }
            case 1: {
                return EnumChatFormatting.DARK_BLUE.toString();
            }
            case 2: {
                return EnumChatFormatting.DARK_GREEN.toString();
            }
            case 3: {
                return EnumChatFormatting.DARK_AQUA.toString();
            }
            case 4: {
                return EnumChatFormatting.DARK_RED.toString();
            }
            case 5: {
                return EnumChatFormatting.DARK_PURPLE.toString();
            }
            case 6: {
                return EnumChatFormatting.GOLD.toString();
            }
            case 7: {
                return EnumChatFormatting.GRAY.toString();
            }
            case 8: {
                return EnumChatFormatting.DARK_GRAY.toString();
            }
            case 9: {
                return EnumChatFormatting.BLUE.toString();
            }
            case 10: {
                return EnumChatFormatting.GREEN.toString();
            }
            case 11: {
                return EnumChatFormatting.AQUA.toString();
            }
            case 12: {
                return EnumChatFormatting.RED.toString();
            }
            case 13: {
                return EnumChatFormatting.LIGHT_PURPLE.toString();
            }
            case 14: {
                return EnumChatFormatting.YELLOW.toString();
            }
            case 15: {
                return EnumChatFormatting.WHITE.toString();
            }
        }
        return EnumChatFormatting.RED.toString();
    }
}

