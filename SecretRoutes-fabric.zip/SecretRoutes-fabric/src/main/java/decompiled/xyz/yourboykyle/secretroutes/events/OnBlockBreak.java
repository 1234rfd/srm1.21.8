/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.item.ItemPickaxe
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.BlockPos
 *  net.minecraftforge.event.world.BlockEvent$BreakEvent
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package xyz.yourboykyle.secretroutes.events;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import net.minecraft.client.Minecraft;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import xyz.yourboykyle.secretroutes.Main;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.dungeons.catacombs.RoomDetection;
import xyz.yourboykyle.secretroutes.deps.dungeonrooms.utils.MapUtils;
import xyz.yourboykyle.secretroutes.utils.LogUtils;
import xyz.yourboykyle.secretroutes.utils.Room;

public class OnBlockBreak {
    @SubscribeEvent
    public void onBlockBreak(BlockEvent.BreakEvent e) {
        try {
            if (e.getPlayer().func_110124_au() == Minecraft.func_71410_x().field_71439_g.func_110124_au() && Main.routeRecording.recording) {
                ItemStack heldItem;
                boolean shouldAddWaypoint = false;
                JsonArray waypoints = Main.routeRecording.currentSecretWaypoints.get("mines").getAsJsonArray();
                if (waypoints.size() > 1) {
                    for (JsonElement waypoint : waypoints) {
                        JsonArray waypointCoords = waypoint.getAsJsonArray();
                        Main.checkRoomData();
                        BlockPos relPos = MapUtils.actualToRelative(e.pos, RoomDetection.roomDirection, RoomDetection.roomCorner);
                        if (relPos.func_177958_n() == waypointCoords.get(0).getAsInt() && relPos.func_177956_o() == waypointCoords.get(1).getAsInt() && relPos.func_177952_p() == waypointCoords.get(2).getAsInt()) continue;
                        shouldAddWaypoint = true;
                    }
                } else {
                    shouldAddWaypoint = true;
                }
                if ((heldItem = e.getPlayer().func_70694_bm()) != null) {
                    if (!(heldItem.func_77973_b() instanceof ItemPickaxe)) {
                        shouldAddWaypoint = false;
                    }
                } else {
                    shouldAddWaypoint = false;
                }
                if (shouldAddWaypoint) {
                    Main.routeRecording.addWaypoint(Room.WAYPOINT_TYPES.MINES, e.pos);
                    Main.routeRecording.setRecordingMessage("Added mine waypoint.");
                }
            }
        }
        catch (Exception ex) {
            LogUtils.error(ex);
        }
    }
}

