/*
 * Decompiled with CFR 0.152.
 */
package xyz.yourboykyle.secretroutes.deps.libautoupdate;

import com.google.gson.JsonElement;
import java.util.Date;
import xyz.yourboykyle.secretroutes.deps.libautoupdate.UpdateData;

public class GithubReleaseUpdateData
extends UpdateData {
    String releaseDescription;
    String targetCommittish;
    Date createdAt;
    Date publishedAt;
    String htmlUrl;

    public GithubReleaseUpdateData(String versionName, JsonElement versionNumber, String sha256, String download, String releaseDescription, String targetCommittish, Date createdAt, Date publishedAt, String htmlUrl) {
        super(versionName, versionNumber, sha256, download);
        this.releaseDescription = releaseDescription;
        this.targetCommittish = targetCommittish;
        this.createdAt = createdAt;
        this.publishedAt = publishedAt;
        this.htmlUrl = htmlUrl;
    }

    public String getReleaseDescription() {
        return this.releaseDescription;
    }

    public String getTargetCommittish() {
        return this.targetCommittish;
    }

    public Date getCreatedAt() {
        return this.createdAt;
    }

    public Date getPublishedAt() {
        return this.publishedAt;
    }

    public String getHtmlUrl() {
        return this.htmlUrl;
    }

    public void setReleaseDescription(String releaseDescription) {
        this.releaseDescription = releaseDescription;
    }

    public void setTargetCommittish(String targetCommittish) {
        this.targetCommittish = targetCommittish;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public void setPublishedAt(Date publishedAt) {
        this.publishedAt = publishedAt;
    }

    public void setHtmlUrl(String htmlUrl) {
        this.htmlUrl = htmlUrl;
    }

    @Override
    public String toString() {
        return "GithubReleaseUpdateData(super=" + super.toString() + ", releaseDescription=" + this.getReleaseDescription() + ", targetCommittish=" + this.getTargetCommittish() + ", createdAt=" + this.getCreatedAt() + ", publishedAt=" + this.getPublishedAt() + ", htmlUrl=" + this.getHtmlUrl() + ")";
    }

    @Override
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof GithubReleaseUpdateData)) {
            return false;
        }
        GithubReleaseUpdateData other = (GithubReleaseUpdateData)o;
        if (!other.canEqual(this)) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }
        String this$releaseDescription = this.getReleaseDescription();
        String other$releaseDescription = other.getReleaseDescription();
        if (this$releaseDescription == null ? other$releaseDescription != null : !this$releaseDescription.equals(other$releaseDescription)) {
            return false;
        }
        String this$targetCommittish = this.getTargetCommittish();
        String other$targetCommittish = other.getTargetCommittish();
        if (this$targetCommittish == null ? other$targetCommittish != null : !this$targetCommittish.equals(other$targetCommittish)) {
            return false;
        }
        Date this$createdAt = this.getCreatedAt();
        Date other$createdAt = other.getCreatedAt();
        if (this$createdAt == null ? other$createdAt != null : !((Object)this$createdAt).equals(other$createdAt)) {
            return false;
        }
        Date this$publishedAt = this.getPublishedAt();
        Date other$publishedAt = other.getPublishedAt();
        if (this$publishedAt == null ? other$publishedAt != null : !((Object)this$publishedAt).equals(other$publishedAt)) {
            return false;
        }
        String this$htmlUrl = this.getHtmlUrl();
        String other$htmlUrl = other.getHtmlUrl();
        return !(this$htmlUrl == null ? other$htmlUrl != null : !this$htmlUrl.equals(other$htmlUrl));
    }

    @Override
    protected boolean canEqual(Object other) {
        return other instanceof GithubReleaseUpdateData;
    }

    @Override
    public int hashCode() {
        int PRIME = 59;
        int result = super.hashCode();
        String $releaseDescription = this.getReleaseDescription();
        result = result * 59 + ($releaseDescription == null ? 43 : $releaseDescription.hashCode());
        String $targetCommittish = this.getTargetCommittish();
        result = result * 59 + ($targetCommittish == null ? 43 : $targetCommittish.hashCode());
        Date $createdAt = this.getCreatedAt();
        result = result * 59 + ($createdAt == null ? 43 : ((Object)$createdAt).hashCode());
        Date $publishedAt = this.getPublishedAt();
        result = result * 59 + ($publishedAt == null ? 43 : ((Object)$publishedAt).hashCode());
        String $htmlUrl = this.getHtmlUrl();
        result = result * 59 + ($htmlUrl == null ? 43 : $htmlUrl.hashCode());
        return result;
    }
}

