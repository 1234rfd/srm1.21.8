/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  org.jetbrains.annotations.NotNull
 */
package xyz.yourboykyle.secretroutes.utils.autoupdate;

import java.util.concurrent.Executor;
import net.minecraft.client.Minecraft;
import org.jetbrains.annotations.NotNull;

public class MinecraftExecutor
implements Executor {
    public static MinecraftExecutor INSTANCE = new MinecraftExecutor();

    private MinecraftExecutor() {
    }

    @Override
    public void execute(@NotNull Runnable runnable) {
        Minecraft.func_71410_x().func_152344_a(runnable);
    }
}

