/*
 * Decompiled with CFR 0.152.
 */
package xyz.yourboykyle.secretroutes.deps.libautoupdate;

public class UpdateException
extends RuntimeException {
    public UpdateException(String message) {
        super(message);
    }
}

