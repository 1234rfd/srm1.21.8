/*
 * Decompiled with CFR 0.152.
 */
package xyz.yourboykyle.secretroutes.deps.libautoupdate;

import java.util.concurrent.CompletableFuture;
import xyz.yourboykyle.secretroutes.deps.libautoupdate.GistSource;
import xyz.yourboykyle.secretroutes.deps.libautoupdate.GithubReleaseUpdateSource;
import xyz.yourboykyle.secretroutes.deps.libautoupdate.MavenSource;
import xyz.yourboykyle.secretroutes.deps.libautoupdate.UpdateData;

public interface UpdateSource {
    public static MavenSource mavenSource(String repository, String moduleId, String artifactId) {
        return new MavenSource(repository, moduleId, artifactId, "", "jar");
    }

    public static UpdateSource gistSource(String owner, String gistId) {
        return new GistSource(owner, gistId);
    }

    public static UpdateSource githubUpdateSource(String owner, String repository) {
        return new GithubReleaseUpdateSource(owner, repository);
    }

    public CompletableFuture<UpdateData> checkUpdate(String var1);
}

