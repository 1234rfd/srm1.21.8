/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.client.Minecraft
 *  net.minecraft.init.Blocks
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraftforge.event.world.BlockEvent$PlaceEvent
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package xyz.yourboykyle.secretroutes.events;

import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import xyz.yourboykyle.secretroutes.Main;
import xyz.yourboykyle.secretroutes.utils.ChatUtils;
import xyz.yourboykyle.secretroutes.utils.Room;

public class OnBlockPlace {
    private static final String verboseTag = "Recording";

    @SubscribeEvent
    public void onBlockPlace(BlockEvent.PlaceEvent e) {
        ChatUtils.sendVerboseMessage("\u00a7d Block placed: " + e.placedBlock.func_177230_c().func_149732_F(), verboseTag);
        if (e.placedBlock.func_177230_c() == Blocks.field_150335_W && Main.routeRecording.recording) {
            ChatUtils.sendVerboseMessage("\u00a7d TNT placed at: " + e.pos, verboseTag);
            Main.routeRecording.addWaypoint(Room.WAYPOINT_TYPES.TNTS, e.pos);
            Main.routeRecording.setRecordingMessage("Added TNT waypoint.");
            return;
        }
        ItemStack heldItem = Minecraft.func_71410_x().field_71439_g.func_70694_bm();
        if (heldItem != null && heldItem.func_77973_b() == Item.func_150898_a((Block)Blocks.field_150335_W) && Main.routeRecording.recording) {
            ChatUtils.sendVerboseMessage("\u00a7d TNT held", verboseTag);
            Main.routeRecording.addWaypoint(Room.WAYPOINT_TYPES.TNTS, e.pos);
            Main.routeRecording.setRecordingMessage("Added TNT waypoint.");
        }
    }
}

